smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_ybz3l0ur.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1833.272,
        'upper limit (fb)' : 111.3925,
        'expected upper limit (fb)' : 69.23539,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 376.0), ('chi', 90.3)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 16.45778,
        'r_expected' : 26.47883,
        'Width (GeV)' : [('zp', 13.78877), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1833.2722171910984},
        'nll' : 1890.272,
        'nll_min' : 634.127,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 53.11474,
        'upper limit (fb)' : 3.503351,
        'expected upper limit (fb)' : 3.098923,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 376.0), ('chi', 90.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 15.16112,
        'r_expected' : 17.13974,
        'Width (GeV)' : [('zp', 13.78877), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 53.11473691418451},
        'nll' : 667.4006,
        'nll_min' : 89.03868,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 164720.5,
        'upper limit (fb)' : 12863.2,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 376.0), ('chi', 90.3)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 12.80556,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 13.78877), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 164720.48544}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.412143,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 376.0), ('chi', 90.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 5.707017,
        'r_expected' : 5.534305,
        'Width (GeV)' : [('zp', 13.78877), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 8.412143415032448},
        'nll' : 51.30794,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 20.68283,
        'r_expected' : 30.51943,
        'nll' : 999.0,
        'nll_min' : 723.2386,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 617.7648,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 494.4965,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 123.0184,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2499179,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 617.7648,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 494.4965,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 123.0184,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2499179,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 510189.9,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 366066.1,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 91516.53,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 52426.98,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 180.2752,
        'SMS' : 'PV > (MET,MET)'
    }
]
}