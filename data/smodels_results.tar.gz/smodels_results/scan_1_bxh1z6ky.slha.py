smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_bxh1z6ky.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 25.36665,
        'upper limit (fb)' : 37.5638,
        'expected upper limit (fb)' : 36.913,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2216.1)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6752952,
        'r_expected' : 0.6872011,
        'Width (GeV)' : [('zp', 21.067)],
        'TxNames weights (fb)' : {'TRV1jj': 25.366653045499994}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.072217,
        'upper limit (fb)' : 12.2689,
        'expected upper limit (fb)' : 13.7061,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2216.1)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4134207,
        'r_expected' : 0.37007,
        'Width (GeV)' : [('zp', 21.0666)],
        'TxNames weights (fb)' : {'TRV1tt': 5.0722166892}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 25.36665,
        'upper limit (fb)' : 67.4857,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2216.1)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.3758819,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 21.067)],
        'TxNames weights (fb)' : {'TRV1jj': 25.366653045499994}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.073331,
        'upper limit (fb)' : 20.9634,
        'expected upper limit (fb)' : 27.8072,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2216.1)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.242009,
        'r_expected' : 0.1824467,
        'Width (GeV)' : [('zp', 21.0666)],
        'TxNames weights (fb)' : {'TRV1bb': 5.073330609099999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 30.16613,
        'upper limit (fb)' : 325.306,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2216.1), ('chi', 85.9)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.09273156,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 21.0666), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 30.1661326895}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2146011,
        'upper limit (fb)' : 2.37053,
        'expected upper limit (fb)' : 2.026743,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2216.1), ('chi', 85.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.09052874,
        'r_expected' : 0.1058847,
        'Width (GeV)' : [('zp', 21.0666), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.21460109720841283},
        'nll' : 59.53089,
        'nll_min' : 59.4992,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.944494,
        'upper limit (fb)' : 27.58214,
        'expected upper limit (fb)' : 14.92307,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.07049828,
        'r_expected' : 0.1303012,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.9442989960976234,
            'TRS1' : 0.00019479059207946618
        },
        'nll' : 634.4928,
        'nll_min' : 633.2288,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.485961,
        'upper limit (fb)' : 43.065,
        'expected upper limit (fb)' : 50.3516,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2216.1)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.05772579,
        'r_expected' : 0.04937204,
        'Width (GeV)' : [('zp', 21.067)],
        'TxNames weights (fb)' : {'TRV1qq': 2.4859612974559995}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04056319,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2216.1), ('chi', 85.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0522116,
        'r_expected' : 0.05117092,
        'Width (GeV)' : [('zp', 21.0666), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.04056319198226307},
        'nll' : 9.219992,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.09591758,
        'r_expected' : 0.1604638,
        'nll' : 694.0236,
        'nll_min' : 693.0706,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 2.623629,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.237357,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6149132,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6128324,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.15852,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.565943e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 2.623629,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.237357,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6149132,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6128324,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.15852,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.565943e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}