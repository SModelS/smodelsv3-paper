smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_gqvkeu82.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.640613,
        'upper limit (fb)' : 1287.92,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1035.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.0004974013,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.1188), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.6406130497}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0004406982,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1035.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0004286948,
        'r_expected' : 0.0004926204,
        'Width (GeV)' : [('zp', 11.1188), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.00044069821650622045},
        'nll' : 9.412901,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0001508372,
        'upper limit (fb)' : 0.5047,
        'expected upper limit (fb)' : 0.5875,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2017_12',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0002988651,
        'r_expected' : 0.0002567442,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 0.0001508047961907279,
            'TRS1' : 3.243731943792053e-08
        },
        'nll' : 9.015537,
        'nll_min' : 9.015237,
        'nll_SM' : 9.015237
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0002307328,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1035.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0002969916,
        'r_expected' : 0.000291072,
        'Width (GeV)' : [('zp', 11.1188), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0002307328051756975},
        'nll' : 9.200895,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'Total xsec for missing topologies (fb)' : 150.1196,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 63.82272,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 35.39139,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.56191,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.34188,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.00173293,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 150.1196,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 63.82272,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 35.39139,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.56191,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.34188,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.00173293,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 5309.859,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3542.707,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 885.6767,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 881.4756,
        'SMS' : 'PV > (t,t)'
    }
]
}