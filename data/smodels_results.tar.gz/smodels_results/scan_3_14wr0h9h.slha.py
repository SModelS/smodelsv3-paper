smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_14wr0h9h.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 108.8604,
        'upper limit (fb)' : 35.572,
        'expected upper limit (fb)' : 56.5742,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1922.8)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 3.060282,
        'r_expected' : 1.924205,
        'Width (GeV)' : [('zp', 9.1827)],
        'TxNames weights (fb)' : {'TRV1jj': 108.86035894999998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 21.77207,
        'upper limit (fb)' : 23.0302,
        'expected upper limit (fb)' : 39.428,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 1922.8)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.9453705,
        'r_expected' : 0.5521982,
        'Width (GeV)' : [('zp', 9.182732)],
        'TxNames weights (fb)' : {'TRV1bb': 21.772071789999995}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 21.76362,
        'upper limit (fb)' : 33.3945,
        'expected upper limit (fb)' : 21.412,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 1922.8)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6517126,
        'r_expected' : 1.016422,
        'Width (GeV)' : [('zp', 9.182732)],
        'TxNames weights (fb)' : {'TRV1tt': 21.763618087999998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 108.8604,
        'upper limit (fb)' : 203.797,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1922.8)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.5341608,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 9.1827)],
        'TxNames weights (fb)' : {'TRV1jj': 108.86035894999998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.7331,
        'upper limit (fb)' : 151.467,
        'expected upper limit (fb)' : 84.4902,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1922.8)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.09066729,
        'r_expected' : 0.1625408,
        'Width (GeV)' : [('zp', 9.1827)],
        'TxNames weights (fb)' : {'TRV1qq': 13.733101704}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03603826,
        'upper limit (fb)' : 399.885,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1922.8), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 9.012157e-05,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 9.182732), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.036038262286}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.104341e-05,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1922.8), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 5.938075e-05,
        'r_expected' : 6.823542e-05,
        'Width (GeV)' : [('zp', 9.182732), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6.10434105731411e-05},
        'nll' : 9.413459,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.024429e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1922.8), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 5.180112e-05,
        'r_expected' : 5.076862e-05,
        'Width (GeV)' : [('zp', 9.182732), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4.024428787739906e-05},
        'nll' : 9.200826,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.587008e-06,
        'upper limit (fb)' : 0.124,
        'expected upper limit (fb)' : 0.1109,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2017_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 2.892748e-05,
        'r_expected' : 3.234453e-05,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 3.5869783409812956e-06,
            'TRS1' : 2.9620118247772e-11
        },
        'nll' : 4.957244,
        'nll_min' : 4.886714,
        'nll_SM' : 4.95727
    }
],
'Total xsec for missing topologies (fb)' : 6.174999,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.899061,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.431369,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.37209,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4724586,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.064412e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 6.174999,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.899061,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.431369,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.37209,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4724586,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.064412e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}