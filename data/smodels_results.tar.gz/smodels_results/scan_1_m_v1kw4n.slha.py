smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_m_v1kw4n.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 369.6129,
        'upper limit (fb)' : 101.9872,
        'expected upper limit (fb)' : 62.4385,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 3.624108,
        'r_expected' : 5.919631,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 368.96960412381327,
            'TRS1' : 0.6432513665812382
        },
        'nll' : 686.1342,
        'nll_min' : 634.0549,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.75573,
        'upper limit (fb)' : 3.46624,
        'expected upper limit (fb)' : 3.234289,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 448.2), ('chi', 107.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 3.391493,
        'r_expected' : 3.634719,
        'Width (GeV)' : [('zp', 3.531644), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 11.755730403276191},
        'nll' : 112.9985,
        'nll_min' : 89.08408,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 24079.47,
        'upper limit (fb)' : 9198.76,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 448.2), ('chi', 107.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 2.617687,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 3.531644), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 24079.474442799998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.879273,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 448.2), ('chi', 107.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.274948,
        'r_expected' : 1.236364,
        'Width (GeV)' : [('zp', 3.531644), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.8792729510985489},
        'nll' : 13.5731,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2644.924,
        'upper limit (fb)' : 7314.05,
        'expected upper limit (fb)' : 4971.75,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 448.2)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.3616224,
        'r_expected' : 0.5319905,
        'Width (GeV)' : [('zp', 3.531644)],
        'TxNames weights (fb)' : {'TRV1bb': 2644.9240093}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 4.60926,
        'r_expected' : 6.820305,
        'nll' : 999.0,
        'nll_min' : 723.2718,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 550.973,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 392.7545,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 158.1159,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1025974,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 550.973,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 392.7545,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 158.1159,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1025974,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 28562.75,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 23655.15,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4907.599,
        'SMS' : 'PV > (t,t)'
    }
]
}