smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_icr_0cgy.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.508787,
        'upper limit (fb)' : 17.1864,
        'expected upper limit (fb)' : 13.7377,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2981.7)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4369029,
        'r_expected' : 0.5465826,
        'Width (GeV)' : [('zp', 15.648)],
        'TxNames weights (fb)' : {'TRV1jj': 7.508787266}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.501657,
        'upper limit (fb)' : 7.43498,
        'expected upper limit (fb)' : 5.79093,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2981.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.201972,
        'r_expected' : 0.259312,
        'Width (GeV)' : [('zp', 15.64788)],
        'TxNames weights (fb)' : {'TRV1tt': 1.50165742583}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.508787,
        'upper limit (fb)' : 55.344,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2981.7)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1356748,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 15.648)],
        'TxNames weights (fb)' : {'TRV1jj': 7.508787266}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.501757,
        'upper limit (fb)' : 18.7706,
        'expected upper limit (fb)' : 14.5065,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2981.7)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.08000583,
        'r_expected' : 0.1035231,
        'Width (GeV)' : [('zp', 15.64788)],
        'TxNames weights (fb)' : {'TRV1bb': 1.5017574532}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3421151,
        'upper limit (fb)' : 11.1667,
        'expected upper limit (fb)' : 13.6178,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2981.7)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.03063708,
        'r_expected' : 0.02512264,
        'Width (GeV)' : [('zp', 15.648)],
        'TxNames weights (fb)' : {'TRV1qq': 0.34211507776}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00854834,
        'upper limit (fb)' : 2.068787,
        'expected upper limit (fb)' : 1.813351,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2981.7), ('chi', 1321.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.004132055,
        'r_expected' : 0.004714113,
        'Width (GeV)' : [('zp', 15.64788), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.008548340425924995},
        'nll' : 59.60181,
        'nll_min' : 59.57455,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06702212,
        'upper limit (fb)' : 28.39619,
        'expected upper limit (fb)' : 15.39021,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2981.7), ('chi', 1321.6)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.00236025,
        'r_expected' : 0.004354854,
        'Width (GeV)' : [('zp', 15.64788), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.06702211585006966},
        'nll' : 634.9138,
        'nll_min' : 633.2367,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001784354,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2981.7), ('chi', 1321.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.002296761,
        'r_expected' : 0.002250982,
        'Width (GeV)' : [('zp', 15.64788), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0017843537165055728},
        'nll' : 9.201463,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.003863898,
        'r_expected' : 0.006129818,
        'nll' : 694.5156,
        'nll_min' : 693.3863,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 0.38005,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1854854,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09225752,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.08842388,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01388263,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.36173e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.38005,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1854854,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09225752,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.08842388,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01388263,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.36173e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}