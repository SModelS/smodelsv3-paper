smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_26_cn972.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.141377,
        'upper limit (fb)' : 3.100367,
        'expected upper limit (fb)' : 3.260545,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 655.6), ('chi', 144.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 2.303397,
        'r_expected' : 2.19024,
        'Width (GeV)' : [('zp', 5.373443), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 7.1413766516693125},
        'nll' : 98.94285,
        'nll_min' : 89.10691,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 156.292,
        'upper limit (fb)' : 76.3256,
        'expected upper limit (fb)' : 42.43666,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 2.047701,
        'r_expected' : 3.682947,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 155.99308884230658,
            'TRS1' : 0.29888870999187345
        },
        'nll' : 648.1332,
        'nll_min' : 633.4178,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6139.085,
        'upper limit (fb)' : 3826.16,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 655.6), ('chi', 144.9)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.604503,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 5.373443), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6139.0853459}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.310191,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 655.6), ('chi', 144.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.8888679,
        'r_expected' : 0.861968,
        'Width (GeV)' : [('zp', 5.373443), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.3101913163512862},
        'nll' : 12.32429,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2216.126,
        'upper limit (fb)' : 9721.91,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 655.6)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.2279517,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 5.3734)],
        'TxNames weights (fb)' : {'TRV1qq': 2216.12605824}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 554.0315,
        'upper limit (fb)' : 2484.64,
        'expected upper limit (fb)' : 2066.83,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 655.6)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.2229826,
        'r_expected' : 0.2680586,
        'Width (GeV)' : [('zp', 5.373443)],
        'TxNames weights (fb)' : {'TRV1bb': 554.03151456}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 2.704428,
        'r_expected' : 4.3403,
        'nll' : 999.0,
        'nll_min' : 723.0277,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 340.8297,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 148.8289,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 124.9436,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 67.04473,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01243903,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 340.8297,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 148.8289,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 124.9436,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 67.04473,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01243903,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 1372.742,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1372.742,
        'SMS' : 'PV > (t,t)'
    }
]
}