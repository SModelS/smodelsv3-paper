smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_3fylul4f.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 47.88429,
        'upper limit (fb)' : 37.723,
        'expected upper limit (fb)' : 35.9137,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2237.1)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.269366,
        'r_expected' : 1.333315,
        'Width (GeV)' : [('zp', 10.684)],
        'TxNames weights (fb)' : {'TRV1jj': 47.884290437500006}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 47.88429,
        'upper limit (fb)' : 58.0885,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2237.1)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.8243334,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 10.684)],
        'TxNames weights (fb)' : {'TRV1jj': 47.884290437500006}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.574835,
        'upper limit (fb)' : 12.3857,
        'expected upper limit (fb)' : 13.2401,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2237.1)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.7730556,
        'r_expected' : 0.7231694,
        'Width (GeV)' : [('zp', 10.684)],
        'TxNames weights (fb)' : {'TRV1tt': 9.5748349675}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.576858,
        'upper limit (fb)' : 20.6599,
        'expected upper limit (fb)' : 27.2298,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2237.1)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.4635481,
        'r_expected' : 0.351705,
        'Width (GeV)' : [('zp', 10.684)],
        'TxNames weights (fb)' : {'TRV1bb': 9.576858087500002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.605823,
        'upper limit (fb)' : 42.715,
        'expected upper limit (fb)' : 47.8532,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2237.1)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.1078268,
        'r_expected' : 0.09624901,
        'Width (GeV)' : [('zp', 10.684)],
        'TxNames weights (fb)' : {'TRV1qq': 4.6058230624}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01588065,
        'upper limit (fb)' : 320.145,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2237.1), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 4.960455e-05,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 10.684), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0158806471175}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.128742e-05,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2237.1), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 3.043523e-05,
        'r_expected' : 3.497364e-05,
        'Width (GeV)' : [('zp', 10.684), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 3.12874157250138e-05},
        'nll' : 9.413502,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.144793e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2237.1), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 2.760706e-05,
        'r_expected' : 2.70568e-05,
        'Width (GeV)' : [('zp', 10.684), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.1447925577481974e-05},
        'nll' : 9.200819,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.010976e-06,
        'upper limit (fb)' : 0.1092,
        'expected upper limit (fb)' : 0.09753,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.841553e-05,
        'r_expected' : 2.061905e-05,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 2.0109663444890254e-06,
            'TRS1' : 1.0073595740387299e-11
        },
        'nll' : 4.731698,
        'nll_min' : 4.655234,
        'nll_SM' : 4.731716
    }
],
'Total xsec for missing topologies (fb)' : 2.4725,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.185352,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5871802,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.550584,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1493772,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.168786e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 2.4725,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.185352,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5871802,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.550584,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1493772,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.168786e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}