smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_bbwkrkfi.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 111.9432,
        'upper limit (fb)' : 36.0147,
        'expected upper limit (fb)' : 57.7889,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1912.8)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 3.108263,
        'r_expected' : 1.937105,
        'Width (GeV)' : [('zp', 9.1347)],
        'TxNames weights (fb)' : {'TRV1jj': 111.94317606}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 22.38864,
        'upper limit (fb)' : 22.7086,
        'expected upper limit (fb)' : 39.953,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 1912.8)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.98591,
        'r_expected' : 0.5603743,
        'Width (GeV)' : [('zp', 9.134724)],
        'TxNames weights (fb)' : {'TRV1bb': 22.388635212}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 22.37975,
        'upper limit (fb)' : 35.7386,
        'expected upper limit (fb)' : 21.7794,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 1912.8)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6262068,
        'r_expected' : 1.027565,
        'Width (GeV)' : [('zp', 9.134724)],
        'TxNames weights (fb)' : {'TRV1tt': 22.379754016}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 111.9432,
        'upper limit (fb)' : 205.743,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1912.8)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.5440923,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 9.1347)],
        'TxNames weights (fb)' : {'TRV1jj': 111.94317606}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 14.23235,
        'upper limit (fb)' : 158.133,
        'expected upper limit (fb)' : 86.2648,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1912.8)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.09000238,
        'r_expected' : 0.1649844,
        'Width (GeV)' : [('zp', 9.1347)],
        'TxNames weights (fb)' : {'TRV1qq': 14.232346760399999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03705615,
        'upper limit (fb)' : 403.488,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1912.8), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 9.183954e-05,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 9.134724), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.037056152099999996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.274496e-05,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1912.8), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 6.103595e-05,
        'r_expected' : 7.013745e-05,
        'Width (GeV)' : [('zp', 9.134724), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6.2744958981804e-05},
        'nll' : 9.413456,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.105118e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1912.8), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 5.283972e-05,
        'r_expected' : 5.178652e-05,
        'Width (GeV)' : [('zp', 9.134724), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4.1051175857901e-05},
        'nll' : 9.200826,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.776497e-06,
        'upper limit (fb)' : 0.124,
        'expected upper limit (fb)' : 0.1109,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2017_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 3.045562e-05,
        'r_expected' : 3.405318e-05,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 3.7764665728152e-06,
            'TRS1' : 3.0863037990597115e-11
        },
        'nll' : 4.957242,
        'nll_min' : 4.886714,
        'nll_SM' : 4.95727
    }
],
'Total xsec for missing topologies (fb)' : 6.377599,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.991796,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.47696,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.417041,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.49178,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.153833e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 6.377599,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.991796,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.47696,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.417041,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.49178,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.153833e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}