smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_c7j5vchp.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.1579,
        'upper limit (fb)' : 30.5655,
        'expected upper limit (fb)' : 20.1726,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2661.0)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4304821,
        'r_expected' : 0.652266,
        'Width (GeV)' : [('zp', 16.592)],
        'TxNames weights (fb)' : {'TRV1jj': 13.157901445499999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.631304,
        'upper limit (fb)' : 7.18732,
        'expected upper limit (fb)' : 8.01081,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2661.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3661036,
        'r_expected' : 0.3284692,
        'Width (GeV)' : [('zp', 16.59176)],
        'TxNames weights (fb)' : {'TRV1tt': 2.6313039944999996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.1579,
        'upper limit (fb)' : 61.3688,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2661.0)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.214407,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 16.592)],
        'TxNames weights (fb)' : {'TRV1jj': 13.157901445499999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.63158,
        'upper limit (fb)' : 37.9664,
        'expected upper limit (fb)' : 18.5472,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2661.0)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.0693134,
        'r_expected' : 0.1418856,
        'Width (GeV)' : [('zp', 16.59176)],
        'TxNames weights (fb)' : {'TRV1bb': 2.6315802890999995}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.844597,
        'upper limit (fb)' : 17.905,
        'expected upper limit (fb)' : 23.4143,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2661.0)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.04717101,
        'r_expected' : 0.03607185,
        'Width (GeV)' : [('zp', 16.592)],
        'TxNames weights (fb)' : {'TRV1qq': 0.84459700864}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04414138,
        'upper limit (fb)' : 2.145539,
        'expected upper limit (fb)' : 1.883001,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2661.0), ('chi', 983.2)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.02057356,
        'r_expected' : 0.02344204,
        'Width (GeV)' : [('zp', 16.59176), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0441413797660432},
        'nll' : 59.58896,
        'nll_min' : 59.53446,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3382436,
        'upper limit (fb)' : 27.89306,
        'expected upper limit (fb)' : 14.58895,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2661.0), ('chi', 983.2)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.01212644,
        'r_expected' : 0.02318492,
        'Width (GeV)' : [('zp', 16.59176), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.33824361483084825},
        'nll' : 634.8408,
        'nll_min' : 632.9675,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.008932943,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2661.0), ('chi', 983.2)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01149819,
        'r_expected' : 0.01126901,
        'Width (GeV)' : [('zp', 16.59176), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.008932942714860854},
        'nll' : 9.204251,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.01910555,
        'r_expected' : 0.03159689,
        'nll' : 694.4298,
        'nll_min' : 693.1856,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 0.8139799,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3927713,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1950966,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.189835,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.03627554,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.431779e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.8139799,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3927713,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1950966,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.189835,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.03627554,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.431779e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}