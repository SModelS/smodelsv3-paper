smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_ut20p8tv.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 22.33511,
        'upper limit (fb)' : 35.4571,
        'expected upper limit (fb)' : 22.4078,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2549.6)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6299194,
        'r_expected' : 0.9967562,
        'Width (GeV)' : [('zp', 12.176)],
        'TxNames weights (fb)' : {'TRV1jj': 22.335114079999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.466465,
        'upper limit (fb)' : 7.92674,
        'expected upper limit (fb)' : 9.0494,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2549.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5634681,
        'r_expected' : 0.4935648,
        'Width (GeV)' : [('zp', 12.17645)],
        'TxNames weights (fb)' : {'TRV1tt': 4.4664651888}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 22.33511,
        'upper limit (fb)' : 52.3691,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2549.6)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.4264941,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 12.176)],
        'TxNames weights (fb)' : {'TRV1jj': 22.335114079999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.467023,
        'upper limit (fb)' : 35.5196,
        'expected upper limit (fb)' : 20.382,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2549.6)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.1257622,
        'r_expected' : 0.2191651,
        'Width (GeV)' : [('zp', 12.17645)],
        'TxNames weights (fb)' : {'TRV1bb': 4.467022815999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.602123,
        'upper limit (fb)' : 27.5467,
        'expected upper limit (fb)' : 29.3656,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2549.6)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.05816025,
        'r_expected' : 0.05455782,
        'Width (GeV)' : [('zp', 12.176)],
        'TxNames weights (fb)' : {'TRV1qq': 1.6021230848}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.745186e-06,
        'upper limit (fb)' : 0.3867,
        'expected upper limit (fb)' : 0.3313,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2549.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-2200-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.485696e-05,
        'r_expected' : 1.734134e-05,
        'Width (GeV)' : [('zp', 12.17645), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 5.745186020104579e-06},
        'nll' : 7.251115,
        'nll_min' : 7.109128,
        'nll_SM' : 7.251134
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.124811e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2549.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.447819e-05,
        'r_expected' : 1.418961e-05,
        'Width (GeV)' : [('zp', 12.17645), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.1248105383217506e-05},
        'nll' : 9.200816,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.035252e-06,
        'upper limit (fb)' : 0.124,
        'expected upper limit (fb)' : 0.1109,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2017_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 8.348803e-06,
        'r_expected' : 9.335001e-06,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.0352472220340014e-06,
            'TRS1' : 4.361498441882911e-12
        },
        'nll' : 4.957263,
        'nll_min' : 4.886714,
        'nll_SM' : 4.95727
    }
],
'Total xsec for missing topologies (fb)' : 1.0797,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.525393,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2608187,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2410319,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05245419,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.090377e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.0797,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.525393,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2608187,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2410319,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05245419,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.090377e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}