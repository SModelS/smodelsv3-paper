smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_f8nbnab_.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 168.492,
        'upper limit (fb)' : 102.068,
        'expected upper limit (fb)' : 102.514,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1544.6)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.650782,
        'r_expected' : 1.6436,
        'Width (GeV)' : [('zp', 14.305)],
        'TxNames weights (fb)' : {'TRV1jj': 168.4920206865}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9461964,
        'upper limit (fb)' : 2.681759,
        'expected upper limit (fb)' : 2.233052,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1544.6), ('chi', 155.4)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3528268,
        'r_expected' : 0.4237234,
        'Width (GeV)' : [('zp', 14.30495), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.9461964454162226},
        'nll' : 59.49672,
        'nll_min' : 59.4552,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 190.0312,
        'upper limit (fb)' : 556.089,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1544.6), ('chi', 155.4)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.341728,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 14.30495), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 190.03119353399998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.938496,
        'upper limit (fb)' : 35.54041,
        'expected upper limit (fb)' : 18.90291,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.2796393,
        'r_expected' : 0.5257653,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 9.926147246556509,
            'TRS1' : 0.012348663855162936
        },
        'nll' : 633.4927,
        'nll_min' : 633.0948,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 28.50329,
        'upper limit (fb)' : 110.407,
        'expected upper limit (fb)' : 195.77,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1544.6)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.2581656,
        'r_expected' : 0.1455958,
        'Width (GeV)' : [('zp', 14.305)],
        'TxNames weights (fb)' : {'TRV1qq': 28.50328720176}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1559814,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1544.6), ('chi', 155.4)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.2007741,
        'r_expected' : 0.1967723,
        'Width (GeV)' : [('zp', 14.30495), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.15598140427657786},
        'nll' : 9.324527,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 28.50329,
        'upper limit (fb)' : 162.68,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1544.6)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.1752108,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 14.305)],
        'TxNames weights (fb)' : {'TRV1qq': 28.50328720176}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.3751322,
        'r_expected' : 0.6400076,
        'nll' : 692.9895,
        'nll_min' : 692.8599,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 21.15073,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.363929,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.062861,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.591435,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.132398,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0001057112,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 21.15073,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.363929,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.062861,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.591435,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.132398,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0001057112,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 33.66679,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 33.66679,
        'SMS' : 'PV > (t,t)'
    }
]
}