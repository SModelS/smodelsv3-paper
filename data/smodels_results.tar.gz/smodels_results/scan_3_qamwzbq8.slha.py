smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_qamwzbq8.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.914304,
        'upper limit (fb)' : 18.4286,
        'expected upper limit (fb)' : 14.3978,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2948.8)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4837212,
        'r_expected' : 0.6191435,
        'Width (GeV)' : [('zp', 14.083)],
        'TxNames weights (fb)' : {'TRV1jj': 8.91430375}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.782736,
        'upper limit (fb)' : 7.28921,
        'expected upper limit (fb)' : 5.98667,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2948.8)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2445718,
        'r_expected' : 0.2977842,
        'Width (GeV)' : [('zp', 14.08339)],
        'TxNames weights (fb)' : {'TRV1tt': 1.7827355599999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.914304,
        'upper limit (fb)' : 53.0682,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2948.8)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1679783,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 14.083)],
        'TxNames weights (fb)' : {'TRV1jj': 8.91430375}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.782861,
        'upper limit (fb)' : 20.7097,
        'expected upper limit (fb)' : 14.8563,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2948.8)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.0860882,
        'r_expected' : 0.1200071,
        'Width (GeV)' : [('zp', 14.08339)],
        'TxNames weights (fb)' : {'TRV1bb': 1.78286075}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.421375,
        'upper limit (fb)' : 11.1667,
        'expected upper limit (fb)' : 14.2748,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2948.8)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.03773496,
        'r_expected' : 0.0295188,
        'Width (GeV)' : [('zp', 14.083)],
        'TxNames weights (fb)' : {'TRV1qq': 0.42137497270000007}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.638395e-06,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2948.8), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 6.457582e-06,
        'r_expected' : 7.420517e-06,
        'Width (GeV)' : [('zp', 14.08339), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6.6383946284579994e-06},
        'nll' : 9.413539,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.682311e-06,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2948.8), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 6.026916e-06,
        'r_expected' : 5.906788e-06,
        'Width (GeV)' : [('zp', 14.08339), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4.6823110340634e-06},
        'nll' : 9.200813,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.725166e-06,
        'upper limit (fb)' : 0.5047,
        'expected upper limit (fb)' : 0.5875,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2017_12',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 3.418201e-06,
        'r_expected' : 2.936452e-06,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.7251530262786796e-06,
            'TRS1' : 1.2778354845121633e-11
        },
        'nll' : 9.01524,
        'nll_min' : 9.015237,
        'nll_SM' : 9.015237
    }
],
'Total xsec for missing topologies (fb)' : 0.41085,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2026222,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1007692,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09197592,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01548206,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.990793e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.41085,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2026222,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1007692,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09197592,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01548206,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.990793e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}