smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_ucbi684k.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.769686,
        'upper limit (fb)' : 17.7036,
        'expected upper limit (fb)' : 14.0126,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2968.0)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3823903,
        'r_expected' : 0.4831142,
        'Width (GeV)' : [('zp', 17.825)],
        'TxNames weights (fb)' : {'TRV1jj': 6.769685558999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.353845,
        'upper limit (fb)' : 7.37428,
        'expected upper limit (fb)' : 5.87244,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2968.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.1835901,
        'r_expected' : 0.2305422,
        'Width (GeV)' : [('zp', 17.8248)],
        'TxNames weights (fb)' : {'TRV1tt': 1.3538451498000001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.769686,
        'upper limit (fb)' : 54.3963,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2968.0)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1244512,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 17.825)],
        'TxNames weights (fb)' : {'TRV1jj': 6.769685558999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.353937,
        'upper limit (fb)' : 19.5781,
        'expected upper limit (fb)' : 14.6522,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2968.0)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.06915569,
        'r_expected' : 0.09240504,
        'Width (GeV)' : [('zp', 17.8248)],
        'TxNames weights (fb)' : {'TRV1bb': 1.3539371117999996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3132951,
        'upper limit (fb)' : 11.1667,
        'expected upper limit (fb)' : 13.8914,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2968.0)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.02805619,
        'r_expected' : 0.02255317,
        'Width (GeV)' : [('zp', 17.825)],
        'TxNames weights (fb)' : {'TRV1qq': 0.31329505843999994}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02015808,
        'upper limit (fb)' : 2.095672,
        'expected upper limit (fb)' : 1.839232,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2968.0), ('chi', 1144.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.009618909,
        'r_expected' : 0.01096005,
        'Width (GeV)' : [('zp', 17.8248), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.020158076483100914},
        'nll' : 59.59736,
        'nll_min' : 59.54715,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1564803,
        'upper limit (fb)' : 28.49181,
        'expected upper limit (fb)' : 15.39052,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2968.0), ('chi', 1144.6)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.005492114,
        'r_expected' : 0.01016732,
        'Width (GeV)' : [('zp', 17.8248), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.15648026709135301},
        'nll' : 634.8928,
        'nll_min' : 633.2041,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.004153477,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2968.0), ('chi', 1144.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.005346219,
        'r_expected' : 0.005239658,
        'Width (GeV)' : [('zp', 17.8248), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.004153477190999058},
        'nll' : 9.202355,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.00896094,
        'r_expected' : 0.01429387,
        'nll' : 694.4901,
        'nll_min' : 693.3773,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 0.39279,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1916222,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09530527,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09139622,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01446569,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.591287e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.39279,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1916222,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09530527,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09139622,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01446569,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.591287e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}