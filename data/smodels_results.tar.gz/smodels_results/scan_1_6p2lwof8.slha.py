smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_6p2lwof8.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 21.45225,
        'upper limit (fb)' : 30.5779,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2319.3)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.7015607,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 20.092)],
        'TxNames weights (fb)' : {'TRV1jj': 21.452252624}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 21.45225,
        'upper limit (fb)' : 37.6906,
        'expected upper limit (fb)' : 32.002,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2319.3)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5691672,
        'r_expected' : 0.670341,
        'Width (GeV)' : [('zp', 20.092)],
        'TxNames weights (fb)' : {'TRV1jj': 21.452252624}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.289666,
        'upper limit (fb)' : 11.7643,
        'expected upper limit (fb)' : 11.9839,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2319.3)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3646342,
        'r_expected' : 0.3579524,
        'Width (GeV)' : [('zp', 20.09205)],
        'TxNames weights (fb)' : {'TRV1tt': 4.289666331059999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.290451,
        'upper limit (fb)' : 19.647,
        'expected upper limit (fb)' : 25.0657,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2319.3)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.2183769,
        'r_expected' : 0.1711682,
        'Width (GeV)' : [('zp', 20.09205)],
        'TxNames weights (fb)' : {'TRV1bb': 4.2904505248}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1654973,
        'upper limit (fb)' : 2.277301,
        'expected upper limit (fb)' : 1.978257,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2319.3), ('chi', 414.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.07267256,
        'r_expected' : 0.08365813,
        'Width (GeV)' : [('zp', 20.09205), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.16549731324289665},
        'nll' : 59.55085,
        'nll_min' : 59.52027,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.355062,
        'upper limit (fb)' : 28.32936,
        'expected upper limit (fb)' : 15.10544,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.04783243,
        'r_expected' : 0.08970687,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.3538897065057702,
            'TRS1' : 0.0011725014072768653
        },
        'nll' : 634.6111,
        'nll_min' : 633.1144,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.915628,
        'upper limit (fb)' : 41.0233,
        'expected upper limit (fb)' : 41.3549,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2319.3)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.04669611,
        'r_expected' : 0.04632168,
        'Width (GeV)' : [('zp', 20.092)],
        'TxNames weights (fb)' : {'TRV1qq': 1.91562837888}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03250523,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2319.3), ('chi', 414.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.04183965,
        'r_expected' : 0.04100571,
        'Width (GeV)' : [('zp', 20.09205), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.03250522766598623},
        'nll' : 9.215454,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.07114759,
        'r_expected' : 0.1173778,
        'nll' : 694.1619,
        'nll_min' : 693.1403,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 1.958241,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9293442,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4606617,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4583148,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1099154,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.490058e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.958241,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9293442,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4606617,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4583148,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1099154,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.490058e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}