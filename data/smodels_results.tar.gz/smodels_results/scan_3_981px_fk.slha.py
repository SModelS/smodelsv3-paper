smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_981px_fk.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.34035,
        'upper limit (fb)' : 22.4988,
        'expected upper limit (fb)' : 16.5608,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2841.0)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5040423,
        'r_expected' : 0.6847705,
        'Width (GeV)' : [('zp', 13.568)],
        'TxNames weights (fb)' : {'TRV1jj': 11.340347767999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.267886,
        'upper limit (fb)' : 6.96895,
        'expected upper limit (fb)' : 6.63202,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2841.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3254272,
        'r_expected' : 0.34196,
        'Width (GeV)' : [('zp', 13.56848)],
        'TxNames weights (fb)' : {'TRV1tt': 2.2678857916}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.34035,
        'upper limit (fb)' : 54.9411,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2841.0)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.2064092,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 13.568)],
        'TxNames weights (fb)' : {'TRV1jj': 11.340347767999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.26807,
        'upper limit (fb)' : 25.9897,
        'expected upper limit (fb)' : 16.0753,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2841.0)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.08726802,
        'r_expected' : 0.1410903,
        'Width (GeV)' : [('zp', 13.56848)],
        'TxNames weights (fb)' : {'TRV1bb': 2.2680695535999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.602768,
        'upper limit (fb)' : 11.855,
        'expected upper limit (fb)' : 16.4935,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2841.0)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.05084504,
        'r_expected' : 0.03654579,
        'Width (GeV)' : [('zp', 13.568)],
        'TxNames weights (fb)' : {'TRV1qq': 0.602767976368}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.073181e-06,
        'upper limit (fb)' : 0.3867,
        'expected upper limit (fb)' : 0.3313,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2841.0), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-2200-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 7.947196e-06,
        'r_expected' : 9.276127e-06,
        'Width (GeV)' : [('zp', 13.56848), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 3.073180753553401e-06},
        'nll' : 7.251124,
        'nll_min' : 7.109128,
        'nll_SM' : 7.251134
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.906995e-06,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2841.0), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 7.603288e-06,
        'r_expected' : 7.451741e-06,
        'Width (GeV)' : [('zp', 13.56848), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 5.9069947665094355e-06},
        'nll' : 9.200814,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.175089e-06,
        'upper limit (fb)' : 0.2868,
        'expected upper limit (fb)' : 0.311,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_14',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 4.097241e-06,
        'r_expected' : 3.778421e-06,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.1750795989997277e-06,
            'TRS1' : 9.236457420643936e-12
        },
        'nll' : 7.341177,
        'nll_min' : 7.341175,
        'nll_SM' : 7.341175
    }
],
'Total xsec for missing topologies (fb)' : 0.52753,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2593511,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1289285,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1180141,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02123558,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.272298e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.52753,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2593511,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1289285,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1180141,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02123558,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.272298e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}