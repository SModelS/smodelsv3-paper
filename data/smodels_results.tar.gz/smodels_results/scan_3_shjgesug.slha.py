smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_shjgesug.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.110007,
        'upper limit (fb)' : 16.8768,
        'expected upper limit (fb)' : 13.5732,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2989.9)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4805418,
        'r_expected' : 0.5975015,
        'Width (GeV)' : [('zp', 14.28)],
        'TxNames weights (fb)' : {'TRV1jj': 8.110007207899999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.621894,
        'upper limit (fb)' : 7.47131,
        'expected upper limit (fb)' : 5.74215,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2989.9)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.217083,
        'r_expected' : 0.2824542,
        'Width (GeV)' : [('zp', 14.27976)],
        'TxNames weights (fb)' : {'TRV1tt': 1.6218943609799998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.110007,
        'upper limit (fb)' : 55.9112,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2989.9)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1450516,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 14.28)],
        'TxNames weights (fb)' : {'TRV1jj': 8.110007207899999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.622001,
        'upper limit (fb)' : 18.2873,
        'expected upper limit (fb)' : 14.4194,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2989.9)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.08869551,
        'r_expected' : 0.1124874,
        'Width (GeV)' : [('zp', 14.27976)],
        'TxNames weights (fb)' : {'TRV1bb': 1.62200144158}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3660625,
        'upper limit (fb)' : 11.1667,
        'expected upper limit (fb)' : 13.4541,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2989.9)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.03278162,
        'r_expected' : 0.02720825,
        'Width (GeV)' : [('zp', 14.28)],
        'TxNames weights (fb)' : {'TRV1qq': 0.366062528208}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.243763e-06,
        'upper limit (fb)' : 0.3867,
        'expected upper limit (fb)' : 0.3313,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2989.9), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-2200-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 5.802336e-06,
        'r_expected' : 6.772603e-06,
        'Width (GeV)' : [('zp', 14.27976), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.243763357743377e-06},
        'nll' : 7.251127,
        'nll_min' : 7.109128,
        'nll_SM' : 7.251134
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.310168e-06,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2989.9), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 5.547905e-06,
        'r_expected' : 5.437325e-06,
        'Width (GeV)' : [('zp', 14.27976), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4.310167521824217e-06},
        'nll' : 9.200813,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.577201e-06,
        'upper limit (fb)' : 0.5047,
        'expected upper limit (fb)' : 0.5875,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2017_12',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 3.125027e-06,
        'r_expected' : 2.684598e-06,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.577190499839865e-06,
            'TRS1' : 1.0794761032791117e-11
        },
        'nll' : 9.01524,
        'nll_min' : 9.015237,
        'nll_SM' : 9.015237
    }
],
'Total xsec for missing topologies (fb)' : 0.37255,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.183939,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09149098,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.08342311,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01369632,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.287326e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.37255,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.183939,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09149098,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.08342311,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01369632,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.287326e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}