smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_p5uko5kp.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.707303,
        'upper limit (fb)' : 3.171168,
        'expected upper limit (fb)' : 2.638439,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1047.6), ('chi', 228.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.8537242,
        'r_expected' : 1.0261,
        'Width (GeV)' : [('zp', 8.64405), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.707302881837954},
        'nll' : 60.52324,
        'nll_min' : 59.45079,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 38.74287,
        'upper limit (fb)' : 49.82299,
        'expected upper limit (fb)' : 27.26773,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.7776102,
        'r_expected' : 1.420832,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 38.66625308362846,
            'TRS1' : 0.07661286261256073
        },
        'nll' : 633.7639,
        'nll_min' : 633.3026,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 949.1483,
        'upper limit (fb)' : 1289.12,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1047.6), ('chi', 228.3)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.7362762,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 8.64405), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 949.14831124}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 261.3712,
        'upper limit (fb)' : 450.413,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1047.6)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.5802924,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 8.6441)],
        'TxNames weights (fb)' : {'TRV1qq': 261.37123631840007}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3610551,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1047.6), ('chi', 228.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.4647381,
        'r_expected' : 0.455475,
        'Width (GeV)' : [('zp', 8.64405), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.3610550684473848},
        'nll' : 9.692154,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 65.34281,
        'upper limit (fb)' : 572.546,
        'expected upper limit (fb)' : 628.568,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 1047.6)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.1141267,
        'r_expected' : 0.103955,
        'Width (GeV)' : [('zp', 8.64405)],
        'TxNames weights (fb)' : {'TRV1bb': 65.3428090796}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.9883477,
        'r_expected' : 1.665154,
        'nll' : 694.2872,
        'nll_min' : 692.9438,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 140.2538,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 57.66937,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 36.55166,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 27.64192,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.38935,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.001525658,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 140.2538,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 57.66937,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 36.55166,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 27.64192,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.38935,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.001525658,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 216.0232,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 216.0232,
        'SMS' : 'PV > (t,t)'
    }
]
}