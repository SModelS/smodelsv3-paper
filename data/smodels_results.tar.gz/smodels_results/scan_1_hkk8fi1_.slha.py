smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_hkk8fi1_.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 101758.3,
        'upper limit (fb)' : 18009.4,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 293.8), ('chi', 82.4)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 5.650291,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 1.964646), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 101758.344647}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 708.0464,
        'upper limit (fb)' : 135.5363,
        'expected upper limit (fb)' : 82.52292,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 293.8), ('chi', 82.4)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 5.224037,
        'r_expected' : 8.579997,
        'Width (GeV)' : [('zp', 1.964646), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 708.0464363368212},
        'nll' : 752.5853,
        'nll_min' : 634.0354,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 14.66499,
        'upper limit (fb)' : 3.067064,
        'expected upper limit (fb)' : 2.827731,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 293.8), ('chi', 82.4)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 4.781442,
        'r_expected' : 5.186131,
        'Width (GeV)' : [('zp', 1.964646), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 14.664986161303224},
        'nll' : 137.9632,
        'nll_min' : 89.07752,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.279244,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 293.8), ('chi', 82.4)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.546299,
        'r_expected' : 1.499503,
        'Width (GeV)' : [('zp', 1.964646), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.279244458410294},
        'nll' : 14.64698,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 6.585296,
        'r_expected' : 9.821458,
        'nll' : 999.0,
        'nll_min' : 723.2319,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 1278.6,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1278.6,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1278.6,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1278.6,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 149511.7,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 119609.3,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 29902.31,
        'SMS' : 'PV > (b,b)'
    }
]
}