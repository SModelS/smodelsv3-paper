smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_md87jerl.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 127.1207,
        'upper limit (fb)' : 118.904,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1332.6)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 1.069103,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 6.4371)],
        'TxNames weights (fb)' : {'TRV1qq': 127.12066807600002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 127.1207,
        'upper limit (fb)' : 256.533,
        'expected upper limit (fb)' : 371.66,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1332.6)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.4955334,
        'r_expected' : 0.3420348,
        'Width (GeV)' : [('zp', 6.4371)],
        'TxNames weights (fb)' : {'TRV1qq': 127.12066807600002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04260749,
        'upper limit (fb)' : 2.835813,
        'expected upper limit (fb)' : 2.34625,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1332.6), ('chi', 648.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.01502479,
        'r_expected' : 0.01815982,
        'Width (GeV)' : [('zp', 6.437128), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.04260748791559147},
        'nll' : 59.58558,
        'nll_min' : 59.46643,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4765599,
        'upper limit (fb)' : 37.67113,
        'expected upper limit (fb)' : 20.61072,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1332.6), ('chi', 648.6)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.01265053,
        'r_expected' : 0.02312194,
        'Width (GeV)' : [('zp', 6.437128), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.4765598815003778},
        'nll' : 634.8489,
        'nll_min' : 633.2945,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.006718276,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1332.6), ('chi', 648.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.008647543,
        'r_expected' : 0.008475181,
        'Width (GeV)' : [('zp', 6.437128), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.006718276095380799},
        'nll' : 9.203357,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.01657272,
        'r_expected' : 0.02778066,
        'nll' : 694.4344,
        'nll_min' : 692.9853,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 46.177,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.82386,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.27115,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.655578,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.426102,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0003073305,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 46.177,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.82386,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.27115,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.655578,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.426102,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0003073305,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 257.3233,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 128.7714,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 128.552,
        'SMS' : 'PV > (t,t)'
    }
]
}