smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_7j0_z2la.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 78.91776,
        'upper limit (fb)' : 119.377,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1342.7)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.6610801,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 10.02)],
        'TxNames weights (fb)' : {'TRV1qq': 78.917764728}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.155412,
        'upper limit (fb)' : 2.857151,
        'expected upper limit (fb)' : 2.379405,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1342.7), ('chi', 378.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.4043931,
        'r_expected' : 0.4855887,
        'Width (GeV)' : [('zp', 10.01983), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.1554119803207066},
        'nll' : 59.54062,
        'nll_min' : 59.45617,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 272.1202,
        'upper limit (fb)' : 788.648,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1342.7), ('chi', 378.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3450465,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 10.01983), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 272.12019887599996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.47897,
        'upper limit (fb)' : 39.44628,
        'expected upper limit (fb)' : 21.48662,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1342.7), ('chi', 378.6)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.3417046,
        'r_expected' : 0.6273194,
        'Width (GeV)' : [('zp', 10.01983), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 13.478974765181762},
        'nll' : 633.4499,
        'nll_min' : 633.2695,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 78.91776,
        'upper limit (fb)' : 243.067,
        'expected upper limit (fb)' : 358.265,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1342.7)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.3246749,
        'r_expected' : 0.2202776,
        'Width (GeV)' : [('zp', 10.02)],
        'TxNames weights (fb)' : {'TRV1qq': 78.917764728}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1755548,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1342.7), ('chi', 378.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.2259683,
        'r_expected' : 0.2214644,
        'Width (GeV)' : [('zp', 10.01983), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.175554808742266},
        'nll' : 9.349577,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.4480984,
        'r_expected' : 0.752711,
        'nll' : 692.9905,
        'nll_min' : 692.9664,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 44.477,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.12406,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.84249,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.318354,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.191805,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0002916856,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 44.477,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 19.12406,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.84249,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.318354,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.191805,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0002916856,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 160.9079,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 80.52048,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 80.38742,
        'SMS' : 'PV > (t,t)'
    }
]
}