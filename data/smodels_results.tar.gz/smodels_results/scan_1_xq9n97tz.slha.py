smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_xq9n97tz.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 258.394,
        'upper limit (fb)' : 88.75807,
        'expected upper limit (fb)' : 54.12666,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 510.3), ('chi', 136.6)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 2.911217,
        'r_expected' : 4.773877,
        'Width (GeV)' : [('zp', 3.866607), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 258.3939947499869},
        'nll' : 665.5071,
        'nll_min' : 634.0029,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.737128,
        'upper limit (fb)' : 3.34745,
        'expected upper limit (fb)' : 3.255966,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 510.3), ('chi', 136.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 2.90882,
        'r_expected' : 2.99055,
        'Width (GeV)' : [('zp', 3.866607), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 9.737128091411217},
        'nll' : 105.7718,
        'nll_min' : 89.10258,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 14007.46,
        'upper limit (fb)' : 6240.84,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 510.3), ('chi', 136.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 2.244482,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 3.866607), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 14007.4553199}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.639895,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 510.3), ('chi', 136.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.112547,
        'r_expected' : 1.078878,
        'Width (GeV)' : [('zp', 3.866607), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.6398948166666527},
        'nll' : 13.00784,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1666.21,
        'upper limit (fb)' : 2540.7,
        'expected upper limit (fb)' : 3305.07,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 510.3)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.6558075,
        'r_expected' : 0.5041376,
        'Width (GeV)' : [('zp', 3.866607)],
        'TxNames weights (fb)' : {'TRV1bb': 1666.2101976000001}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 3.78938,
        'r_expected' : 5.590107,
        'nll' : 999.0,
        'nll_min' : 723.3166,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 469.69,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 250.3969,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 112.9901,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 106.2599,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.043021,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 469.69,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 250.3969,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 112.9901,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 106.2599,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.043021,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 19014.22,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 15501.3,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3512.924,
        'SMS' : 'PV > (t,t)'
    }
]
}