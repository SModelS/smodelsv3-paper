smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_ldcpoeqx.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 26.76944,
        'upper limit (fb)' : 3.272157,
        'expected upper limit (fb)' : 3.240773,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 517.6), ('chi', 168.1)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 8.180976,
        'r_expected' : 8.260202,
        'Width (GeV)' : [('zp', 18.23967), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 26.769438119139586},
        'nll' : 226.4023,
        'nll_min' : 89.10611,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 693.733,
        'upper limit (fb)' : 90.81548,
        'expected upper limit (fb)' : 53.62955,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 517.6), ('chi', 168.1)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 7.638929,
        'r_expected' : 12.93565,
        'Width (GeV)' : [('zp', 18.23967), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 693.7329641373278},
        'nll' : 913.103,
        'nll_min' : 633.8202,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 36241.07,
        'upper limit (fb)' : 6329.28,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 517.6), ('chi', 168.1)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 5.725939,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 18.23967), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 36241.073968000004}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.338673,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 517.6), ('chi', 168.1)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 2.943469,
        'r_expected' : 2.85439,
        'Width (GeV)' : [('zp', 18.23967), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4.338672652227056},
        'nll' : 22.73545,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 10.10632,
        'r_expected' : 15.30057,
        'nll' : 999.0,
        'nll_min' : 723.2256,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 458.86,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 219.6846,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 145.5179,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 93.62139,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.03612897,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 458.86,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 219.6846,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 145.5179,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 93.62139,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.03612897,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 182768.9,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 123654.4,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30913.61,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 28200.84,
        'SMS' : 'PV > (t,t)'
    }
]
}