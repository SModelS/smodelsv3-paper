smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_g_1lhohr.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 320.3102,
        'upper limit (fb)' : 109.579,
        'expected upper limit (fb)' : 105.187,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1522.6)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 2.923099,
        'r_expected' : 3.04515,
        'Width (GeV)' : [('zp', 7.9432)],
        'TxNames weights (fb)' : {'TRV1jj': 320.3102113599999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 55.0803,
        'upper limit (fb)' : 105.273,
        'expected upper limit (fb)' : 205.202,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1522.6)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.5232139,
        'r_expected' : 0.2684199,
        'Width (GeV)' : [('zp', 7.9432)],
        'TxNames weights (fb)' : {'TRV1qq': 55.080298656}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 55.0803,
        'upper limit (fb)' : 157.831,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1522.6)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.3489828,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 7.9432)],
        'TxNames weights (fb)' : {'TRV1qq': 55.080298656}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1907015,
        'upper limit (fb)' : 2.632315,
        'expected upper limit (fb)' : 2.211113,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1522.6), ('chi', 678.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.0724463,
        'r_expected' : 0.08624682,
        'Width (GeV)' : [('zp', 7.94322), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.19070146001764732},
        'nll' : 59.53102,
        'nll_min' : 59.46962,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 35.65135,
        'upper limit (fb)' : 580.424,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1522.6), ('chi', 678.9)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.06142293,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 7.94322), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 35.651345110399994}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.940284,
        'upper limit (fb)' : 35.47733,
        'expected upper limit (fb)' : 18.89583,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1522.6), ('chi', 678.9)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.05469081,
        'r_expected' : 0.1026831,
        'Width (GeV)' : [('zp', 7.94322), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.9402836404085033},
        'nll' : 634.5662,
        'nll_min' : 633.0986,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03183277,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1522.6), ('chi', 678.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.04097408,
        'r_expected' : 0.04015739,
        'Width (GeV)' : [('zp', 7.94322), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.03183276518697017},
        'nll' : 9.215092,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.07524632,
        'r_expected' : 0.1272457,
        'nll' : 694.0972,
        'nll_min' : 692.923,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 23.068,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.18288,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.529921,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.990176,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.364899,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0001185112,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 23.068,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.18288,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.529921,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.990176,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.364899,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0001185112,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 63.99838,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 63.99838,
        'SMS' : 'PV > (t,t)'
    }
]
}