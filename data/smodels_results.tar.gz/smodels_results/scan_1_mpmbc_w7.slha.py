smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_mpmbc_w7.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 208.9449,
        'upper limit (fb)' : 111.116,
        'expected upper limit (fb)' : 105.733,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1518.1)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.880421,
        'r_expected' : 1.976156,
        'Width (GeV)' : [('zp', 12.316)],
        'TxNames weights (fb)' : {'TRV1jj': 208.9449108725}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 36.06064,
        'upper limit (fb)' : 104.223,
        'expected upper limit (fb)' : 207.131,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1518.1)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.345995,
        'r_expected' : 0.1740958,
        'Width (GeV)' : [('zp', 12.316)],
        'TxNames weights (fb)' : {'TRV1qq': 36.060640109119994}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8899758,
        'upper limit (fb)' : 2.717531,
        'expected upper limit (fb)' : 2.266782,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1518.1), ('chi', 349.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3274943,
        'r_expected' : 0.3926163,
        'Width (GeV)' : [('zp', 12.31639), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.8899758160594163},
        'nll' : 59.48596,
        'nll_min' : 59.4588,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 175.3581,
        'upper limit (fb)' : 611.11,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1518.1), ('chi', 349.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2869502,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 12.31639), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 175.358132525}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.369728,
        'upper limit (fb)' : 34.92071,
        'expected upper limit (fb)' : 18.98902,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.2683144,
        'r_expected' : 0.4934287,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 9.36369293090062,
            'TRS1' : 0.0060348347507665975
        },
        'nll' : 633.6313,
        'nll_min' : 633.2528,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 36.06064,
        'upper limit (fb)' : 156.839,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1518.1)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.2299214,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 12.316)],
        'TxNames weights (fb)' : {'TRV1qq': 36.060640109119994}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1448574,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1518.1), ('chi', 349.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1864556,
        'r_expected' : 0.1827392,
        'Width (GeV)' : [('zp', 12.31639), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.14485739110239668},
        'nll' : 9.311236,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.3565485,
        'r_expected' : 0.5979848,
        'nll' : 693.1173,
        'nll_min' : 692.9758,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 23.35665,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.30393,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.600902,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.048888,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.402807,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0001206907,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 23.35665,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.30393,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.600902,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.048888,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.402807,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0001206907,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 41.74694,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41.74694,
        'SMS' : 'PV > (t,t)'
    }
]
}