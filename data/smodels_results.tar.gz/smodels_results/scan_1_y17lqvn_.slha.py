smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_y17lqvn_.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 35.29403,
        'upper limit (fb)' : 37.7277,
        'expected upper limit (fb)' : 36.48,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2225.2)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.9354937,
        'r_expected' : 0.9674898,
        'Width (GeV)' : [('zp', 14.867)],
        'TxNames weights (fb)' : {'TRV1jj': 35.294026185}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.057282,
        'upper limit (fb)' : 12.3195,
        'expected upper limit (fb)' : 13.5042,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2225.2)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5728546,
        'r_expected' : 0.5225991,
        'Width (GeV)' : [('zp', 14.86734)],
        'TxNames weights (fb)' : {'TRV1tt': 7.0572821265}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 35.29403,
        'upper limit (fb)' : 63.4136,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2225.2)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.5565687,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 14.867)],
        'TxNames weights (fb)' : {'TRV1jj': 35.294026185}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.058805,
        'upper limit (fb)' : 20.8319,
        'expected upper limit (fb)' : 27.557,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2225.2)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.338846,
        'r_expected' : 0.2561529,
        'Width (GeV)' : [('zp', 14.86734)],
        'TxNames weights (fb)' : {'TRV1bb': 7.058805237}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.428151,
        'upper limit (fb)' : 42.9133,
        'expected upper limit (fb)' : 49.2672,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2225.2)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.07988551,
        'r_expected' : 0.06958282,
        'Width (GeV)' : [('zp', 14.867)],
        'TxNames weights (fb)' : {'TRV1qq': 3.428150777919999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1312749,
        'upper limit (fb)' : 2.273064,
        'expected upper limit (fb)' : 1.95651,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2225.2), ('chi', 752.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.05775239,
        'r_expected' : 0.06709643,
        'Width (GeV)' : [('zp', 14.86734), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.1312748599546123},
        'nll' : 59.55637,
        'nll_min' : 59.51023,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 16.9137,
        'upper limit (fb)' : 360.873,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2225.2), ('chi', 752.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.04686885,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 14.86734), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 16.9137035415}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.096612,
        'upper limit (fb)' : 26.75131,
        'expected upper limit (fb)' : 14.75874,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2225.2), ('chi', 752.7)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.04099283,
        'r_expected' : 0.07430252,
        'Width (GeV)' : [('zp', 14.86734), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.096611903422371},
        'nll' : 634.6826,
        'nll_min' : 633.357,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02572304,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2225.2), ('chi', 752.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.03310984,
        'r_expected' : 0.0324499,
        'Width (GeV)' : [('zp', 14.86734), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.025723036894054863},
        'nll' : 9.211914,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.05901645,
        'r_expected' : 0.09559553,
        'nll' : 694.239,
        'nll_min' : 693.2537,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 2.5575,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.20687,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.599334,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5977798,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1535093,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.350073e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 2.5575,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.20687,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.599334,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5977798,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1535093,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.350073e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}