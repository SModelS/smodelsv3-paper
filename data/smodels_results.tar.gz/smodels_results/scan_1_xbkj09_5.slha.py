smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_xbkj09_5.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1177.383,
        'upper limit (fb)' : 111.4917,
        'expected upper limit (fb)' : 69.67543,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 379.7), ('chi', 130.7)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 10.56027,
        'r_expected' : 16.89811,
        'Width (GeV)' : [('zp', 12.49048), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1177.3829593793848},
        'nll' : 1134.069,
        'nll_min' : 634.1352,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 33.97471,
        'upper limit (fb)' : 3.512713,
        'expected upper limit (fb)' : 3.127935,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 379.7), ('chi', 130.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 9.671929,
        'r_expected' : 10.86171,
        'Width (GeV)' : [('zp', 12.49048), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 33.974707972180916},
        'nll' : 321.5603,
        'nll_min' : 89.04706,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 100700.7,
        'upper limit (fb)' : 12862.7,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 379.7), ('chi', 130.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 7.828894,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 12.49048), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 100700.715456}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.432552,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 379.7), ('chi', 130.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 3.685585,
        'r_expected' : 3.574047,
        'Width (GeV)' : [('zp', 12.49048), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 5.432551847062561},
        'nll' : 28.7709,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 13.24751,
        'r_expected' : 19.47735,
        'nll' : 999.0,
        'nll_min' : 723.26,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 785.75,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 616.0118,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 169.4397,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2985192,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 785.75,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 616.0118,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 169.4397,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2985192,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 554019.2,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 395942.2,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 98985.55,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 59091.5,
        'SMS' : 'PV > (t,t)'
    }
]
}