smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_nhgqzf5x.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.427295,
        'upper limit (fb)' : 21.7059,
        'expected upper limit (fb)' : 16.1395,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2862.0)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2500378,
        'r_expected' : 0.336274,
        'Width (GeV)' : [('zp', 27.22)],
        'TxNames weights (fb)' : {'TRV1jj': 5.4272947663}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.085374,
        'upper limit (fb)' : 6.9648,
        'expected upper limit (fb)' : 6.5046,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2862.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.155837,
        'r_expected' : 0.1668625,
        'Width (GeV)' : [('zp', 27.2203)],
        'TxNames weights (fb)' : {'TRV1tt': 1.08537359092}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.427295,
        'upper limit (fb)' : 53.073,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2862.0)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1022609,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 27.22)],
        'TxNames weights (fb)' : {'TRV1jj': 5.4272947663}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.085459,
        'upper limit (fb)' : 25.1341,
        'expected upper limit (fb)' : 15.8261,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2862.0)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.0431867,
        'r_expected' : 0.06858664,
        'Width (GeV)' : [('zp', 27.2203)],
        'TxNames weights (fb)' : {'TRV1bb': 1.08545895326}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.282047,
        'upper limit (fb)' : 11.61,
        'expected upper limit (fb)' : 16.0081,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2862.0)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.02429345,
        'r_expected' : 0.01761902,
        'Width (GeV)' : [('zp', 27.22)],
        'TxNames weights (fb)' : {'TRV1qq': 0.2820469663704}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05179465,
        'upper limit (fb)' : 2.16464,
        'expected upper limit (fb)' : 1.901937,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2862.0), ('chi', 104.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.0239276,
        'r_expected' : 0.02723258,
        'Width (GeV)' : [('zp', 27.2203), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.05179464786225961},
        'nll' : 59.5867,
        'nll_min' : 59.53576,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4583297,
        'upper limit (fb)' : 28.10429,
        'expected upper limit (fb)' : 14.80389,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.01630818,
        'r_expected' : 0.0309601,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 0.45830665281659266,
            'TRS1' : 2.3070241900928936e-05
        },
        'nll' : 634.8132,
        'nll_min' : 633.0228,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01031922,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2862.0), ('chi', 104.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01328256,
        'r_expected' : 0.01301781,
        'Width (GeV)' : [('zp', 27.2203), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.010319217768526644},
        'nll' : 9.204824,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.02360616,
        'r_expected' : 0.03965162,
        'nll' : 694.3999,
        'nll_min' : 693.0854,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 0.5047022,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2453717,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1219893,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1175218,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01981859,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.709769e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.5047022,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2453717,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1219893,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1175218,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01981859,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.709769e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}