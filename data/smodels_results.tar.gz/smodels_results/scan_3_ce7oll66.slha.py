smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_ce7oll66.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 235.1943,
        'upper limit (fb)' : 206.628,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1938.4)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.13825,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 20.825)],
        'TxNames weights (fb)' : {'TRV1jj': 235.19426787499998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03460876,
        'upper limit (fb)' : 393.669,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1938.4), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 8.791335e-05,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 20.82489), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.03460876115}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.865527e-05,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1938.4), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 5.705766e-05,
        'r_expected' : 6.556592e-05,
        'Width (GeV)' : [('zp', 20.82489), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 5.86552744846315e-05},
        'nll' : 9.413462,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.912832e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1938.4), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 5.036468e-05,
        'r_expected' : 4.936082e-05,
        'Width (GeV)' : [('zp', 20.82489), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 3.9128319268578496e-05},
        'nll' : 9.200826,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.316277e-06,
        'upper limit (fb)' : 0.124,
        'expected upper limit (fb)' : 0.1109,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2017_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 2.674417e-05,
        'r_expected' : 2.990331e-05,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 3.316249563030265e-06,
            'TRS1' : 2.7826460013886376e-11
        },
        'nll' : 4.957246,
        'nll_min' : 4.886714,
        'nll_SM' : 4.95727
    }
],
'Total xsec for missing topologies (fb)' : 5.890499,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.768848,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.367354,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.308974,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4453034,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.938938e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 5.890499,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.768848,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.367354,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.308974,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4453034,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.938938e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 47.02116,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 47.02116,
        'SMS' : 'PV > (t,t)'
    }
]
}