smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_khajqbit.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 77.93249,
        'upper limit (fb)' : 34.1555,
        'expected upper limit (fb)' : 52.6871,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1954.8)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 2.281697,
        'r_expected' : 1.479157,
        'Width (GeV)' : [('zp', 11.98)],
        'TxNames weights (fb)' : {'TRV1jj': 77.93248883999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 15.5865,
        'upper limit (fb)' : 24.0594,
        'expected upper limit (fb)' : 37.748,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 1954.8)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.647834,
        'r_expected' : 0.4129092,
        'Width (GeV)' : [('zp', 11.98035)],
        'TxNames weights (fb)' : {'TRV1bb': 15.586497767999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 15.58083,
        'upper limit (fb)' : 25.8934,
        'expected upper limit (fb)' : 20.2365,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 1954.8)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6017299,
        'r_expected' : 0.7699371,
        'Width (GeV)' : [('zp', 11.98035)],
        'TxNames weights (fb)' : {'TRV1tt': 15.580831879999998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 77.93249,
        'upper limit (fb)' : 197.57,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1954.8)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.3944551,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.98)],
        'TxNames weights (fb)' : {'TRV1jj': 77.93248883999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1881294,
        'upper limit (fb)' : 2.40658,
        'expected upper limit (fb)' : 2.05539,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1954.8), ('chi', 736.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.07817295,
        'r_expected' : 0.09152978,
        'Width (GeV)' : [('zp', 11.98035), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.1881294191433781},
        'nll' : 59.53747,
        'nll_min' : 59.49686,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.566401,
        'upper limit (fb)' : 130.133,
        'expected upper limit (fb)' : 80.3758,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1954.8)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.07351249,
        'r_expected' : 0.1190209,
        'Width (GeV)' : [('zp', 11.98)],
        'TxNames weights (fb)' : {'TRV1qq': 9.5664012792}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 26.52667,
        'upper limit (fb)' : 434.419,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1954.8), ('chi', 736.8)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.0610624,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.98035), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 26.526667276}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.654702,
        'upper limit (fb)' : 29.07745,
        'expected upper limit (fb)' : 15.91732,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1954.8), ('chi', 736.8)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.05690672,
        'r_expected' : 0.1039561,
        'Width (GeV)' : [('zp', 11.98035), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.65470229605283},
        'nll' : 634.5839,
        'nll_min' : 633.3015,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0347319,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1954.8), ('chi', 736.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.04470575,
        'r_expected' : 0.04381468,
        'Width (GeV)' : [('zp', 11.98035), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.034731895997812325},
        'nll' : 9.216672,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.08034375,
        'r_expected' : 0.1319661,
        'nll' : 694.1213,
        'nll_min' : 693.1818,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 5.5962,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.588857,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.318008,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.278733,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.410584,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.781307e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 5.5962,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.588857,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.318008,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.278733,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.410584,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.781307e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}