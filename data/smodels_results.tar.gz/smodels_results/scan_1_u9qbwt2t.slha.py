smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_u9qbwt2t.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 43.09695,
        'upper limit (fb)' : 110.467,
        'expected upper limit (fb)' : 221.622,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1484.3)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.3901342,
        'r_expected' : 0.1944615,
        'Width (GeV)' : [('zp', 11.492)],
        'TxNames weights (fb)' : {'TRV1qq': 43.096954824}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8954015,
        'upper limit (fb)' : 2.7202,
        'expected upper limit (fb)' : 2.281842,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1484.3), ('chi', 386.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3291675,
        'r_expected' : 0.3924029,
        'Width (GeV)' : [('zp', 11.4922), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.8954014528583327},
        'nll' : 59.49802,
        'nll_min' : 59.4671,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 181.8061,
        'upper limit (fb)' : 620.324,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1484.3), ('chi', 386.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2930825,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.4922), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 181.80609074600002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.619935,
        'upper limit (fb)' : 33.28769,
        'expected upper limit (fb)' : 19.47385,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1484.3), ('chi', 386.7)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.2889938,
        'r_expected' : 0.4939924,
        'Width (GeV)' : [('zp', 11.4922), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 9.619935041326748},
        'nll' : 633.8989,
        'nll_min' : 633.7246,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 43.09695,
        'upper limit (fb)' : 149.389,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1484.3)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.2884881,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.492)],
        'TxNames weights (fb)' : {'TRV1qq': 43.096954824}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1420356,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1484.3), ('chi', 386.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1828236,
        'r_expected' : 0.1791796,
        'Width (GeV)' : [('zp', 11.4922), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.14203564478313102},
        'nll' : 9.307973,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.3797909,
        'r_expected' : 0.5992528,
        'nll' : 693.3969,
        'nll_min' : 693.3506,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 26.372,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.58012,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.339802,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.668946,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.78299,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0001423212,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 26.372,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 11.58012,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.339802,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.668946,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.78299,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0001423212,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 97.40884,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 48.73126,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 48.67758,
        'SMS' : 'PV > (t,t)'
    }
]
}