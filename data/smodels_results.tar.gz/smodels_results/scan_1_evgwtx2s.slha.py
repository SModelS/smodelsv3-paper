smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_evgwtx2s.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 933.291,
        'upper limit (fb)' : 112.3719,
        'expected upper limit (fb)' : 70.8289,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 369.6), ('chi', 140.9)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 8.305374,
        'r_expected' : 13.1767,
        'Width (GeV)' : [('zp', 11.48476), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 933.2909854315212},
        'nll' : 932.7017,
        'nll_min' : 634.169,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 26.41498,
        'upper limit (fb)' : 3.585555,
        'expected upper limit (fb)' : 3.211872,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 369.6), ('chi', 140.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 7.367053,
        'r_expected' : 8.224167,
        'Width (GeV)' : [('zp', 11.48476), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 26.41497507483943},
        'nll' : 220.4832,
        'nll_min' : 89.05236,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.288519,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 369.6), ('chi', 140.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 2.909443,
        'r_expected' : 2.821394,
        'Width (GeV)' : [('zp', 11.48476), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4.288519238983973},
        'nll' : 22.48763,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 83249.75,
        'upper limit (fb)' : 260964.0,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 369.6), ('chi', 140.9)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3190086,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.48476), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 83249.748883}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 10.33144,
        'r_expected' : 15.09195,
        'nll' : 999.0,
        'nll_min' : 723.2923,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 826.49,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 702.0923,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 124.0142,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3835394,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 826.49,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 702.0923,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 124.0142,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3835394,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 636380.1,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 460778.5,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 115194.6,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 60406.94,
        'SMS' : 'PV > (t,t)'
    }
]
}