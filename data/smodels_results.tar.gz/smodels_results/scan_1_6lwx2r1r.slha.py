smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_6lwx2r1r.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.479721,
        'upper limit (fb)' : 3.063797,
        'expected upper limit (fb)' : 2.561725,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1112.4), ('chi', 178.4)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.809362,
        'r_expected' : 0.9679887,
        'Width (GeV)' : [('zp', 9.821637), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.4797212233007224},
        'nll' : 60.39273,
        'nll_min' : 59.45935,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 34.35091,
        'upper limit (fb)' : 45.28829,
        'expected upper limit (fb)' : 25.6323,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.7584943,
        'r_expected' : 1.340141,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 34.237715057520255,
            'TRS1' : 0.11319235537840505
        },
        'nll' : 633.9574,
        'nll_min' : 633.524,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 800.9155,
        'upper limit (fb)' : 1135.57,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1112.4), ('chi', 178.4)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.7052983,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 9.821637), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 800.9155341599999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3361843,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1112.4), ('chi', 178.4)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.4327253,
        'r_expected' : 0.4241003,
        'Width (GeV)' : [('zp', 9.821637), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.33618429546365997},
        'nll' : 9.635194,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 180.9877,
        'upper limit (fb)' : 434.32,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1112.4)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.4167151,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 9.8216)],
        'TxNames weights (fb)' : {'TRV1qq': 180.9876974208}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 45.24692,
        'upper limit (fb)' : 647.673,
        'expected upper limit (fb)' : 584.223,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 1112.4)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.06986075,
        'r_expected' : 0.07744804,
        'Width (GeV)' : [('zp', 9.821637)],
        'TxNames weights (fb)' : {'TRV1bb': 45.2469243552}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.9608805,
        'r_expected' : 1.572895,
        'nll' : 694.3501,
        'nll_min' : 693.1373,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 107.3447,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 44.51616,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 27.36712,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 21.43862,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.02176,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.001028068,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 107.3447,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 44.51616,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 27.36712,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 21.43862,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 14.02176,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.001028068,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 156.5334,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 156.5334,
        'SMS' : 'PV > (t,t)'
    }
]
}