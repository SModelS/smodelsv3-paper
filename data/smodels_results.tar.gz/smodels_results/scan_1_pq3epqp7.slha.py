smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_pq3epqp7.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.45251,
        'upper limit (fb)' : 32.1918,
        'expected upper limit (fb)' : 20.9049,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2624.5)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4178863,
        'r_expected' : 0.64351,
        'Width (GeV)' : [('zp', 17.399)],
        'TxNames weights (fb)' : {'TRV1jj': 13.452512969}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.690204,
        'upper limit (fb)' : 7.27274,
        'expected upper limit (fb)' : 8.34986,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2624.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3699025,
        'r_expected' : 0.3221856,
        'Width (GeV)' : [('zp', 17.3989)],
        'TxNames weights (fb)' : {'TRV1tt': 2.6902044876}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.45251,
        'upper limit (fb)' : 61.0223,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2624.5)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.2204524,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 17.399)],
        'TxNames weights (fb)' : {'TRV1jj': 13.452512969}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.690503,
        'upper limit (fb)' : 38.3036,
        'expected upper limit (fb)' : 19.1173,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2624.5)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.07024151,
        'r_expected' : 0.1407365,
        'Width (GeV)' : [('zp', 17.3989)],
        'TxNames weights (fb)' : {'TRV1bb': 2.6905025938}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8956658,
        'upper limit (fb)' : 20.1558,
        'expected upper limit (fb)' : 25.3642,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2624.5)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.04443713,
        'r_expected' : 0.03531221,
        'Width (GeV)' : [('zp', 17.399)],
        'TxNames weights (fb)' : {'TRV1qq': 0.8956658407199999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05609259,
        'upper limit (fb)' : 2.17475,
        'expected upper limit (fb)' : 1.889548,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2624.5), ('chi', 897.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.02579266,
        'r_expected' : 0.02968572,
        'Width (GeV)' : [('zp', 17.3989), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.05609258761587905},
        'nll' : 59.58316,
        'nll_min' : 59.52236,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4353319,
        'upper limit (fb)' : 27.6705,
        'expected upper limit (fb)' : 14.59737,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2624.5), ('chi', 897.3)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.01573271,
        'r_expected' : 0.02982263,
        'Width (GeV)' : [('zp', 17.3989), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.43533188373417},
        'nll' : 634.8177,
        'nll_min' : 633.0318,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01120646,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2624.5), ('chi', 897.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01442459,
        'r_expected' : 0.01413708,
        'Width (GeV)' : [('zp', 17.3989), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.011206464335658901},
        'nll' : 9.205197,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.02431506,
        'r_expected' : 0.04020965,
        'nll' : 694.4009,
        'nll_min' : 693.1762,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 0.89246,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4299847,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2135418,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.208204,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04072786,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.612366e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.89246,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4299847,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2135418,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.208204,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04072786,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.612366e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}