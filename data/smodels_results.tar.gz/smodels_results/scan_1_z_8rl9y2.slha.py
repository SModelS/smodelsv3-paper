smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_z_8rl9y2.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 29.0171,
        'upper limit (fb)' : 31.6031,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2350.4)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.9181727,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 13.956)],
        'TxNames weights (fb)' : {'TRV1jj': 29.017102133500003}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 29.0171,
        'upper limit (fb)' : 37.6783,
        'expected upper limit (fb)' : 30.5221,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2350.4)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.7701277,
        'r_expected' : 0.9506915,
        'Width (GeV)' : [('zp', 13.956)],
        'TxNames weights (fb)' : {'TRV1jj': 29.017102133500003}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.802416,
        'upper limit (fb)' : 11.4533,
        'expected upper limit (fb)' : 11.5485,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2350.4)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5066152,
        'r_expected' : 0.5024389,
        'Width (GeV)' : [('zp', 13.95618)],
        'TxNames weights (fb)' : {'TRV1tt': 5.802415797099999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.80342,
        'upper limit (fb)' : 19.4793,
        'expected upper limit (fb)' : 24.366,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2350.4)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.2979276,
        'r_expected' : 0.238177,
        'Width (GeV)' : [('zp', 13.95618)],
        'TxNames weights (fb)' : {'TRV1bb': 5.8034204267}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.517572,
        'upper limit (fb)' : 39.9867,
        'expected upper limit (fb)' : 38.8963,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2350.4)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.06296023,
        'r_expected' : 0.06472523,
        'Width (GeV)' : [('zp', 13.956)],
        'TxNames weights (fb)' : {'TRV1qq': 2.5175718402799996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.07070245,
        'upper limit (fb)' : 2.227465,
        'expected upper limit (fb)' : 1.921275,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2350.4), ('chi', 917.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.03174122,
        'r_expected' : 0.03679975,
        'Width (GeV)' : [('zp', 13.95618), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.07070244856162479},
        'nll' : 59.57661,
        'nll_min' : 59.51232,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.5649348,
        'upper limit (fb)' : 27.24229,
        'expected upper limit (fb)' : 14.52088,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2350.4), ('chi', 917.8)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.02073742,
        'r_expected' : 0.038905,
        'Width (GeV)' : [('zp', 13.95618), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.5649347984167594},
        'nll' : 634.7875,
        'nll_min' : 633.113,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01421349,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2350.4), ('chi', 917.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01829513,
        'r_expected' : 0.01793048,
        'Width (GeV)' : [('zp', 13.95618), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.014213487618649373},
        'nll' : 9.206492,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.03096405,
        'r_expected' : 0.05099408,
        'nll' : 694.3641,
        'nll_min' : 693.129,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 1.8111,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8610245,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4268938,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4237137,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09946395,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.047723e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.8111,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8610245,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4268938,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4237137,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09946395,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.047723e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}