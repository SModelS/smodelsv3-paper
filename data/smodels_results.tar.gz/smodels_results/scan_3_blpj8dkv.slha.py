smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_blpj8dkv.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 18.71516,
        'upper limit (fb)' : 32.2311,
        'expected upper limit (fb)' : 20.923,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2623.6)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5806554,
        'r_expected' : 0.894478,
        'Width (GeV)' : [('zp', 12.53)],
        'TxNames weights (fb)' : {'TRV1jj': 18.715162752000005}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.742617,
        'upper limit (fb)' : 7.28059,
        'expected upper limit (fb)' : 8.35827,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2623.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5140541,
        'r_expected' : 0.4477741,
        'Width (GeV)' : [('zp', 12.52991)],
        'TxNames weights (fb)' : {'TRV1tt': 3.7426169664}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 18.71516,
        'upper limit (fb)' : 61.0138,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2623.6)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.3067366,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 12.53)],
        'TxNames weights (fb)' : {'TRV1jj': 18.715162752000005}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.743033,
        'upper limit (fb)' : 38.3119,
        'expected upper limit (fb)' : 19.1314,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2623.6)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.09769895,
        'r_expected' : 0.1956486,
        'Width (GeV)' : [('zp', 12.52991)],
        'TxNames weights (fb)' : {'TRV1bb': 3.7430325504000006}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.247344,
        'upper limit (fb)' : 20.2113,
        'expected upper limit (fb)' : 25.4123,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2623.6)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.06171519,
        'r_expected' : 0.04908427,
        'Width (GeV)' : [('zp', 12.53)],
        'TxNames weights (fb)' : {'TRV1qq': 1.2473442695999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.919703e-06,
        'upper limit (fb)' : 0.3867,
        'expected upper limit (fb)' : 0.3313,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2623.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-2200-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.272227e-05,
        'r_expected' : 1.484969e-05,
        'Width (GeV)' : [('zp', 12.52991), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4.919703251319418e-06},
        'nll' : 7.251118,
        'nll_min' : 7.109128,
        'nll_SM' : 7.251134
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.567283e-06,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2623.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.231469e-05,
        'r_expected' : 1.206924e-05,
        'Width (GeV)' : [('zp', 12.52991), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 9.567282672050689e-06},
        'nll' : 9.200815,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.141543e-06,
        'upper limit (fb)' : 0.2415,
        'expected upper limit (fb)' : 0.1504,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2018_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 4.726884e-06,
        'r_expected' : 7.590044e-06,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.141537777476595e-06,
            'TRS1' : 4.790859305682438e-12
        },
        'nll' : 7.146651,
        'nll_min' : 5.36413,
        'nll_SM' : 7.146686
    }
],
'Total xsec for missing topologies (fb)' : 0.89469,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4366244,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2168381,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1998428,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04138303,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.638429e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.89469,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4366244,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2168381,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1998428,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04138303,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.638429e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}