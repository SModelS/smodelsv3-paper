smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_yztja0wz.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 24.74537,
        'upper limit (fb)' : 37.3709,
        'expected upper limit (fb)' : 23.2887,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2505.7)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6621562,
        'r_expected' : 1.062549,
        'Width (GeV)' : [('zp', 11.967)],
        'TxNames weights (fb)' : {'TRV1jj': 24.745374793}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.948413,
        'upper limit (fb)' : 8.31006,
        'expected upper limit (fb)' : 9.4594,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2505.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5954725,
        'r_expected' : 0.5231212,
        'Width (GeV)' : [('zp', 11.96698)],
        'TxNames weights (fb)' : {'TRV1tt': 4.948412604}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 24.74537,
        'upper limit (fb)' : 45.0344,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2505.7)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.5494772,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.967)],
        'TxNames weights (fb)' : {'TRV1jj': 24.745374793}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.949075,
        'upper limit (fb)' : 32.8975,
        'expected upper limit (fb)' : 21.1503,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2505.7)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.1504392,
        'r_expected' : 0.2339955,
        'Width (GeV)' : [('zp', 11.96698)],
        'TxNames weights (fb)' : {'TRV1bb': 4.9490749586}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.853529,
        'upper limit (fb)' : 32.6683,
        'expected upper limit (fb)' : 31.1843,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2505.7)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.05673784,
        'r_expected' : 0.05943788,
        'Width (GeV)' : [('zp', 11.967)],
        'TxNames weights (fb)' : {'TRV1qq': 1.8535287132}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.272691e-06,
        'upper limit (fb)' : 0.3867,
        'expected upper limit (fb)' : 0.3313,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2505.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-2200-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.622108e-05,
        'r_expected' : 1.893357e-05,
        'Width (GeV)' : [('zp', 11.96698), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6.272691071485906e-06},
        'nll' : 7.251113,
        'nll_min' : 7.109128,
        'nll_SM' : 7.251134
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.229582e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2505.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.582677e-05,
        'r_expected' : 1.551132e-05,
        'Width (GeV)' : [('zp', 11.96698), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.2295821460724047e-05},
        'nll' : 9.200816,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.027436e-06,
        'upper limit (fb)' : 0.1092,
        'expected upper limit (fb)' : 0.09753,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 9.408754e-06,
        'r_expected' : 1.053456e-05,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.027431257005621e-06,
            'TRS1' : 4.68168589509012e-12
        },
        'nll' : 4.731707,
        'nll_min' : 4.655234,
        'nll_SM' : 4.731716
    }
],
'Total xsec for missing topologies (fb)' : 1.2005,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5831166,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2894009,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2679079,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06007217,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.403957e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.2005,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5831166,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2894009,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2679079,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06007217,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.403957e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}