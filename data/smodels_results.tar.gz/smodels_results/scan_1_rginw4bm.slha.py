smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_rginw4bm.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1617.523,
        'upper limit (fb)' : 96.61388,
        'expected upper limit (fb)' : 58.8588,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 458.3), ('chi', 143.5)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 16.74214,
        'r_expected' : 27.48142,
        'Width (GeV)' : [('zp', 19.08846), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1617.5233833641842},
        'nll' : 1968.587,
        'nll_min' : 634.0201,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 53.13815,
        'upper limit (fb)' : 3.241213,
        'expected upper limit (fb)' : 3.280205,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 458.3), ('chi', 143.5)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 16.39453,
        'r_expected' : 16.19965,
        'Width (GeV)' : [('zp', 19.08846), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 53.1381548228021},
        'nll' : 627.9708,
        'nll_min' : 89.10691,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 102545.1,
        'upper limit (fb)' : 8554.71,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 458.3), ('chi', 143.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 11.98698,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 19.08846), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 102545.107665}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.495924,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 458.3), ('chi', 143.5)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 5.763856,
        'r_expected' : 5.589423,
        'Width (GeV)' : [('zp', 19.08846), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 8.495923697109848},
        'nll' : 52.07024,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 21.85816,
        'r_expected' : 31.9912,
        'nll' : 999.0,
        'nll_min' : 723.3806,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 561.64,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 398.981,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 162.5623,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09675479,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 561.64,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 398.981,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 162.5623,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09675479,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 237144.8,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 162238.3,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 40559.56,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 34347.01,
        'SMS' : 'PV > (t,t)'
    }
]
}