smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_xfdbvw95.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 66.20384,
        'upper limit (fb)' : 34.9105,
        'expected upper limit (fb)' : 41.9573,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2110.1)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.896388,
        'r_expected' : 1.577886,
        'Width (GeV)' : [('zp', 10.077)],
        'TxNames weights (fb)' : {'TRV1jj': 66.2038435515}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.23722,
        'upper limit (fb)' : 12.1837,
        'expected upper limit (fb)' : 16.0671,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2110.1)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.08647,
        'r_expected' : 0.8238714,
        'Width (GeV)' : [('zp', 10.0774)],
        'TxNames weights (fb)' : {'TRV1tt': 13.2372246605}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.24077,
        'upper limit (fb)' : 22.1696,
        'expected upper limit (fb)' : 31.0594,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2110.1)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.5972489,
        'r_expected' : 0.4263047,
        'Width (GeV)' : [('zp', 10.0774)],
        'TxNames weights (fb)' : {'TRV1bb': 13.240768710300001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 66.20384,
        'upper limit (fb)' : 141.495,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2110.1)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.4678882,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 10.077)],
        'TxNames weights (fb)' : {'TRV1jj': 66.2038435515}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.124351,
        'upper limit (fb)' : 56.8183,
        'expected upper limit (fb)' : 62.9835,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2110.1)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.1253883,
        'r_expected' : 0.1131146,
        'Width (GeV)' : [('zp', 10.077)],
        'TxNames weights (fb)' : {'TRV1qq': 7.124351043600001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02194242,
        'upper limit (fb)' : 346.105,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2110.1), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 6.339816e-05,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 10.0774), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.021942420149400003}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.162806e-05,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2110.1), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 4.049422e-05,
        'r_expected' : 4.65326e-05,
        'Width (GeV)' : [('zp', 10.0774), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4.1628062386434216e-05},
        'nll' : 9.413487,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.830484e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2110.1), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 3.643306e-05,
        'r_expected' : 3.570688e-05,
        'Width (GeV)' : [('zp', 10.0774), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.8304844295920028e-05},
        'nll' : 9.200822,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.590964e-06,
        'upper limit (fb)' : 0.2415,
        'expected upper limit (fb)' : 0.1504,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2018_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.486942e-05,
        'r_expected' : 2.387609e-05,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 3.5909428847097593e-06,
            'TRS1' : 2.106566740187987e-11
        },
        'nll' : 7.146575,
        'nll_min' : 5.36413,
        'nll_SM' : 7.146686
    }
],
'Total xsec for missing topologies (fb)' : 3.531499,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.680226,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8313617,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7856306,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2342715,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.865673e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 3.531499,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.680226,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8313617,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7856306,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2342715,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.865673e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}