smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_o_jzpvnt.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.074261,
        'upper limit (fb)' : 18.7382,
        'expected upper limit (fb)' : 14.5624,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2940.6)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4842654,
        'r_expected' : 0.6231295,
        'Width (GeV)' : [('zp', 14.044)],
        'TxNames weights (fb)' : {'TRV1jj': 9.07426135}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.814724,
        'upper limit (fb)' : 7.25288,
        'expected upper limit (fb)' : 6.03545,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2940.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2502073,
        'r_expected' : 0.3006775,
        'Width (GeV)' : [('zp', 14.04412)],
        'TxNames weights (fb)' : {'TRV1tt': 1.8147237444}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.074261,
        'upper limit (fb)' : 52.501,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2940.6)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1728398,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 14.044)],
        'TxNames weights (fb)' : {'TRV1jj': 9.07426135}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.814852,
        'upper limit (fb)' : 21.193,
        'expected upper limit (fb)' : 14.9434,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2940.6)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.08563451,
        'r_expected' : 0.1214484,
        'Width (GeV)' : [('zp', 14.04412)],
        'TxNames weights (fb)' : {'TRV1bb': 1.8148522700000003}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4331452,
        'upper limit (fb)' : 11.1667,
        'expected upper limit (fb)' : 14.4385,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2940.6)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.03878901,
        'r_expected' : 0.02999932,
        'Width (GeV)' : [('zp', 14.044)],
        'TxNames weights (fb)' : {'TRV1qq': 0.43314518609999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.740726e-06,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2940.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 6.557126e-06,
        'r_expected' : 7.534905e-06,
        'Width (GeV)' : [('zp', 14.04412), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6.740725791564576e-06},
        'nll' : 9.413538,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.759165e-06,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2940.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 6.12584e-06,
        'r_expected' : 6.003741e-06,
        'Width (GeV)' : [('zp', 14.04412), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4.7591652703775045e-06},
        'nll' : 9.200813,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.753756e-06,
        'upper limit (fb)' : 0.5047,
        'expected upper limit (fb)' : 0.5875,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2017_12',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 3.474849e-06,
        'r_expected' : 2.985117e-06,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.7537431885894369e-06,
            'TRS1' : 1.3182661612423634e-11
        },
        'nll' : 9.01524,
        'nll_min' : 9.015237,
        'nll_SM' : 9.015237
    }
],
'Total xsec for missing topologies (fb)' : 0.41787,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2060372,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1024645,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09354262,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01582506,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.12648e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.41787,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2060372,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1024645,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09354262,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01582506,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.12648e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}