smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_b4l89a1g.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 102.0053,
        'upper limit (fb)' : 55.6699,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2466.4)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.832324,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 122.63)],
        'TxNames weights (fb)' : {'TRV1jj': 102.005286575}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.673862,
        'upper limit (fb)' : 2.214641,
        'expected upper limit (fb)' : 1.925206,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2466.4), ('chi', 515.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.304276,
        'r_expected' : 0.3500207,
        'Width (GeV)' : [('zp', 122.634), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.6738620295842929},
        'nll' : 59.56169,
        'nll_min' : 59.52222,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.31134,
        'upper limit (fb)' : 27.83812,
        'expected upper limit (fb)' : 14.52147,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1907938,
        'r_expected' : 0.3657577,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 5.308611908975212,
            'TRS1' : 0.002727595423462037
        },
        'nll' : 633.7639,
        'nll_min' : 632.9465,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1348544,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2466.4), ('chi', 515.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1735801,
        'r_expected' : 0.1701203,
        'Width (GeV)' : [('zp', 122.634), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.13485438256607746},
        'nll' : 9.29987,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.2897903,
        'r_expected' : 0.4843745,
        'nll' : 693.3256,
        'nll_min' : 693.0625,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 1.314619,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6168325,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3263427,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3060613,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06537975,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.626662e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.314619,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6168325,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3263427,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3060613,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06537975,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.626662e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 20.39814,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 20.39814,
        'SMS' : 'PV > (t,t)'
    }
]
}