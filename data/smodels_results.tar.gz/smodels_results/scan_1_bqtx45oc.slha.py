smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_bqtx45oc.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 450.0327,
        'upper limit (fb)' : 121.8358,
        'expected upper limit (fb)' : 76.62276,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 322.1), ('chi', 115.8)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 3.693765,
        'r_expected' : 5.873355,
        'Width (GeV)' : [('zp', 1.798017), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 450.03270097177676},
        'nll' : 686.4441,
        'nll_min' : 634.1654,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.19814,
        'upper limit (fb)' : 3.351959,
        'expected upper limit (fb)' : 3.085816,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 322.1), ('chi', 115.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 3.340774,
        'r_expected' : 3.628907,
        'Width (GeV)' : [('zp', 1.798017), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 11.198138305227666},
        'nll' : 112.5868,
        'nll_min' : 89.07662,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.789593,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 322.1), ('chi', 115.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.214106,
        'r_expected' : 1.177364,
        'Width (GeV)' : [('zp', 1.798017), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.789592713607517},
        'nll' : 13.35453,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 52604.29,
        'upper limit (fb)' : 209415.0,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 322.1), ('chi', 115.8)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2511964,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 1.798017), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 52604.29083}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 4.655059,
        'r_expected' : 6.755579,
        'nll' : 999.0,
        'nll_min' : 723.3401,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 1074.1,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1071.443,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.657169,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1074.1,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1071.443,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.657169,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 130585.7,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 104468.6,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 26117.14,
        'SMS' : 'PV > (b,b)'
    }
]
}