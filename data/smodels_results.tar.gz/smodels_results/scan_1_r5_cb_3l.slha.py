smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_r5_cb_3l.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1049.04,
        'upper limit (fb)' : 1158.72,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 823.7)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.9053442,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 5.2572)],
        'TxNames weights (fb)' : {'TRV1qq': 1049.04046104}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.937104,
        'upper limit (fb)' : 3.483912,
        'expected upper limit (fb)' : 2.939923,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 823.7), ('chi', 295.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.8430475,
        'r_expected' : 0.9990411,
        'Width (GeV)' : [('zp', 5.257225), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.937103759889076},
        'nll' : 60.52691,
        'nll_min' : 59.47113,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 51.14662,
        'upper limit (fb)' : 62.47357,
        'expected upper limit (fb)' : 33.30038,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 823.7), ('chi', 295.3)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.8186921,
        'r_expected' : 1.535917,
        'Width (GeV)' : [('zp', 5.257225), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 51.14662272870842},
        'nll' : 633.6795,
        'nll_min' : 633.0975,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1522.619,
        'upper limit (fb)' : 2453.07,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 823.7), ('chi', 295.3)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6206995,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 5.257225), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1522.6193926499998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 262.2601,
        'upper limit (fb)' : 582.353,
        'expected upper limit (fb)' : 823.791,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 823.7)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.4503456,
        'r_expected' : 0.3183576,
        'Width (GeV)' : [('zp', 5.257225)],
        'TxNames weights (fb)' : {'TRV1bb': 262.26011526}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3336105,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 823.7), ('chi', 295.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.4294124,
        'r_expected' : 0.4208534,
        'Width (GeV)' : [('zp', 5.257225), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.33361047678779293},
        'nll' : 9.629494,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 1.008013,
        'r_expected' : 1.75208,
        'nll' : 694.2064,
        'nll_min' : 692.762,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 335.69,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 138.8886,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 101.6451,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 64.90204,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.24785,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.006471851,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 335.69,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 138.8886,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 101.6451,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 64.90204,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 30.24785,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.006471851,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 740.0657,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 740.0657,
        'SMS' : 'PV > (t,t)'
    }
]
}