smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_ehzj4fx2.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 123.3073,
        'upper limit (fb)' : 67.67665,
        'expected upper limit (fb)' : 38.84935,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 1.822006,
        'r_expected' : 3.173986,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 122.8865132940673,
            'TRS1' : 0.4207577230335808
        },
        'nll' : 644.0533,
        'nll_min' : 633.6302,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.19361,
        'upper limit (fb)' : 3.536958,
        'expected upper limit (fb)' : 3.05977,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 721.4), ('chi', 146.5)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 1.751112,
        'r_expected' : 2.024207,
        'Width (GeV)' : [('zp', 6.059984), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6.193610315231761},
        'nll' : 65.74073,
        'nll_min' : 59.50481,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4393.849,
        'upper limit (fb)' : 2935.73,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 721.4), ('chi', 146.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.49668,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 6.059984), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4393.8491674}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.6611645,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 721.4), ('chi', 146.5)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.851029,
        'r_expected' : 0.8340664,
        'Width (GeV)' : [('zp', 6.059984), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.661164453464515},
        'nll' : 10.64773,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1438.644,
        'upper limit (fb)' : 5171.63,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 721.4)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.27818,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 6.06)],
        'TxNames weights (fb)' : {'TRV1qq': 1438.64404532}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 359.661,
        'upper limit (fb)' : 1822.64,
        'expected upper limit (fb)' : 1333.27,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 721.4)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.1973297,
        'r_expected' : 0.2697586,
        'Width (GeV)' : [('zp', 6.059984)],
        'TxNames weights (fb)' : {'TRV1bb': 359.66101133}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 2.243435,
        'r_expected' : 3.621839,
        'nll' : 709.794,
        'nll_min' : 693.2605,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 378.1688,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 164.0197,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 130.8305,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 75.16083,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.147079,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01065925,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 378.1688,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 164.0197,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 130.8305,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 75.16083,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.147079,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01065925,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 939.6609,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 939.6609,
        'SMS' : 'PV > (t,t)'
    }
]
}