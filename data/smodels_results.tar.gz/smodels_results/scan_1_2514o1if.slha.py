smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_2514o1if.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1870.996,
        'upper limit (fb)' : 120.8529,
        'expected upper limit (fb)' : 75.98011,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 331.3), ('chi', 109.6)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 15.4816,
        'r_expected' : 24.62481,
        'Width (GeV)' : [('zp', 6.666683), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1870.995513574211},
        'nll' : 1722.574,
        'nll_min' : 634.1739,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 47.12717,
        'upper limit (fb)' : 3.336561,
        'expected upper limit (fb)' : 3.076409,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 331.3), ('chi', 109.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 14.12447,
        'r_expected' : 15.31889,
        'Width (GeV)' : [('zp', 6.666683), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 47.12717430447296},
        'nll' : 561.8088,
        'nll_min' : 89.07681,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 208783.4,
        'upper limit (fb)' : 16652.4,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 331.3), ('chi', 109.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 12.53774,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 6.666683), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 208783.44455999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.498917,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 331.3), ('chi', 109.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 5.08746,
        'r_expected' : 4.933498,
        'Width (GeV)' : [('zp', 6.666683), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 7.498916734950432},
        'nll' : 43.45435,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 19.60415,
        'r_expected' : 28.383,
        'nll' : 999.0,
        'nll_min' : 723.3494,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 1020.1,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1018.875,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.225055,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1020.1,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1018.875,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.225055,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 167296.5,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 133837.2,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 33459.3,
        'SMS' : 'PV > (b,b)'
    }
]
}