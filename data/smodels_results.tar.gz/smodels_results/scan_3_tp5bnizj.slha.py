smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_tp5bnizj.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1404.734,
        'upper limit (fb)' : 1158.72,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 823.7)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 1.212315,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 3.926)],
        'TxNames weights (fb)' : {'TRV1qq': 1404.73381464}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 351.1835,
        'upper limit (fb)' : 582.353,
        'expected upper limit (fb)' : 823.791,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 823.7)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.6030422,
        'r_expected' : 0.4263016,
        'Width (GeV)' : [('zp', 3.926039)],
        'TxNames weights (fb)' : {'TRV1bb': 351.18345366}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.609888,
        'upper limit (fb)' : 2426.05,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 823.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.000663584,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 3.926039), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.6098880483499998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0006627201,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 823.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0006446693,
        'r_expected' : 0.0007408004,
        'Width (GeV)' : [('zp', 3.926039), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0006627200744315675},
        'nll' : 9.412575,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0008788644,
        'upper limit (fb)' : 1.809,
        'expected upper limit (fb)' : 1.983,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_7',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0004858288,
        'r_expected' : 0.0004431994,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 0.0008782390072402787,
            'TRS1' : 6.253684384746281e-07
        },
        'nll' : 11.89499,
        'nll_min' : 11.89441,
        'nll_SM' : 11.89441
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003363072,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 823.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0004328835,
        'r_expected' : 0.0004242554,
        'Width (GeV)' : [('zp', 3.926039), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0003363072231883633},
        'nll' : 9.200933,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'Total xsec for missing topologies (fb)' : 335.6879,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 145.9478,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 89.74733,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 68.20076,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 31.78524,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.006800794,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 335.6879,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 145.9478,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 89.74733,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 68.20076,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 31.78524,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.006800794,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 990.9963,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 990.9963,
        'SMS' : 'PV > (t,t)'
    }
]
}