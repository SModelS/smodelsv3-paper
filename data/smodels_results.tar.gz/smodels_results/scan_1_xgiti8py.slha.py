smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_xgiti8py.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 10.23958,
        'upper limit (fb)' : 26.9163,
        'expected upper limit (fb)' : 18.5774,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2740.5)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3804229,
        'r_expected' : 0.5511845,
        'Width (GeV)' : [('zp', 18.264)],
        'TxNames weights (fb)' : {'TRV1jj': 10.239575774999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.047723,
        'upper limit (fb)' : 7.00834,
        'expected upper limit (fb)' : 7.27238,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2740.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2921838,
        'r_expected' : 0.2815754,
        'Width (GeV)' : [('zp', 18.26424)],
        'TxNames weights (fb)' : {'TRV1tt': 2.0477230638}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 10.23958,
        'upper limit (fb)' : 60.4629,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2740.5)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.169353,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 18.264)],
        'TxNames weights (fb)' : {'TRV1jj': 10.239575774999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.047915,
        'upper limit (fb)' : 33.5779,
        'expected upper limit (fb)' : 17.3807,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2740.5)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.06098997,
        'r_expected' : 0.117827,
        'Width (GeV)' : [('zp', 18.26424)],
        'TxNames weights (fb)' : {'TRV1bb': 2.0479151549999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.6055266,
        'upper limit (fb)' : 14.2175,
        'expected upper limit (fb)' : 20.0199,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2740.5)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.04259023,
        'r_expected' : 0.03024624,
        'Width (GeV)' : [('zp', 18.264)],
        'TxNames weights (fb)' : {'TRV1qq': 0.6055266359999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04500381,
        'upper limit (fb)' : 2.137704,
        'expected upper limit (fb)' : 1.881276,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2740.5), ('chi', 930.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.02105241,
        'r_expected' : 0.02392195,
        'Width (GeV)' : [('zp', 18.26424), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.04500380651431274},
        'nll' : 59.58893,
        'nll_min' : 59.5368,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.34579,
        'upper limit (fb)' : 28.07764,
        'expected upper limit (fb)' : 14.66097,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2740.5), ('chi', 930.3)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.0123155,
        'r_expected' : 0.02358576,
        'Width (GeV)' : [('zp', 18.26424), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.34578998909237474},
        'nll' : 634.839,
        'nll_min' : 632.9542,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.009190693,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2740.5), ('chi', 930.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01182996,
        'r_expected' : 0.01159416,
        'Width (GeV)' : [('zp', 18.26424), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.009190692899261579},
        'nll' : 9.204356,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.01948379,
        'r_expected' : 0.03223408,
        'nll' : 694.4279,
        'nll_min' : 693.1882,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 0.67036,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.324487,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1612392,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1562383,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02839438,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.113864e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.67036,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.324487,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1612392,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1562383,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02839438,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.113864e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}