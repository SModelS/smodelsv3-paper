smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_yn2c7xy8.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 613.9815,
        'upper limit (fb)' : 133.3133,
        'expected upper limit (fb)' : 81.66324,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 297.5), ('chi', 95.3)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 4.605554,
        'r_expected' : 7.518457,
        'Width (GeV)' : [('zp', 1.826695), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 613.981520984534},
        'nll' : 723.1947,
        'nll_min' : 634.0582,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.45341,
        'upper limit (fb)' : 2.958637,
        'expected upper limit (fb)' : 2.833494,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 297.5), ('chi', 95.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 4.547165,
        'r_expected' : 4.747993,
        'Width (GeV)' : [('zp', 1.826695), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 13.453411850466878},
        'nll' : 130.941,
        'nll_min' : 89.09894,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 84478.1,
        'upper limit (fb)' : 18825.1,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 297.5), ('chi', 95.3)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 4.487525,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 1.826695), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 84478.099194}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.094634,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 297.5), ('chi', 95.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.421055,
        'r_expected' : 1.378049,
        'Width (GeV)' : [('zp', 1.826695), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.09463446951523},
        'nll' : 14.1312,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 6.004397,
        'r_expected' : 8.79075,
        'nll' : 999.0,
        'nll_min' : 723.3372,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 1248.0,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1248.0,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1248.0,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1248.0,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 155461.9,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 124369.5,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 31092.36,
        'SMS' : 'PV > (b,b)'
    }
]
}