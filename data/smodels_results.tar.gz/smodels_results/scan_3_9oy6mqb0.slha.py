smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_9oy6mqb0.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 276.045,
        'upper limit (fb)' : 83.3575,
        'expected upper limit (fb)' : 95.8579,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1599.4)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 3.311579,
        'r_expected' : 2.879731,
        'Width (GeV)' : [('zp', 7.6376)],
        'TxNames weights (fb)' : {'TRV1jj': 276.04495775}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 44.82244,
        'upper limit (fb)' : 123.193,
        'expected upper limit (fb)' : 172.276,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1599.4)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.3638391,
        'r_expected' : 0.2601781,
        'Width (GeV)' : [('zp', 7.6376)],
        'TxNames weights (fb)' : {'TRV1qq': 44.822435481999996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 44.82244,
        'upper limit (fb)' : 139.713,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1599.4)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.3208179,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 7.6376)],
        'TxNames weights (fb)' : {'TRV1qq': 44.822435481999996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09110462,
        'upper limit (fb)' : 542.02,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1599.4), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.0001680835,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 7.637602), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.09110461768999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0001279337,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1599.4), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0001244491,
        'r_expected' : 0.0001430065,
        'Width (GeV)' : [('zp', 7.637602), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0001279336593911825},
        'nll' : 9.41336,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.04206e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1599.4), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0001035147,
        'r_expected' : 0.0001014515,
        'Width (GeV)' : [('zp', 7.637602), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 8.042059696425832e-05},
        'nll' : 9.200841,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.779126e-05,
        'upper limit (fb)' : 0.5047,
        'expected upper limit (fb)' : 0.5875,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2017_12',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 7.487866e-05,
        'r_expected' : 6.432555e-05,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 3.778891995316433e-05,
            'TRS1' : 2.3391920599174843e-09
        },
        'nll' : 9.015312,
        'nll_min' : 9.015237,
        'nll_SM' : 9.015237
    }
],
'Total xsec for missing topologies (fb)' : 17.58899,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.009403,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.932425,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.910807,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.736272,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.396486e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 17.58899,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.009403,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.932425,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.910807,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.736272,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.396486e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 55.16397,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 55.16397,
        'SMS' : 'PV > (t,t)'
    }
]
}