smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_zgxpti0c.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 19.17922,
        'upper limit (fb)' : 32.6714,
        'expected upper limit (fb)' : 21.1256,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2613.5)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5870339,
        'r_expected' : 0.9078663,
        'Width (GeV)' : [('zp', 12.482)],
        'TxNames weights (fb)' : {'TRV1jj': 19.1792209885}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.835409,
        'upper limit (fb)' : 7.36878,
        'expected upper limit (fb)' : 8.4526,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2613.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5204945,
        'r_expected' : 0.453755,
        'Width (GeV)' : [('zp', 12.48191)],
        'TxNames weights (fb)' : {'TRV1tt': 3.8354091007999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 19.17922,
        'upper limit (fb)' : 60.9179,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2613.5)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.3148372,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 12.482)],
        'TxNames weights (fb)' : {'TRV1jj': 19.1792209885}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.835844,
        'upper limit (fb)' : 38.4053,
        'expected upper limit (fb)' : 19.2891,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2613.5)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.09987799,
        'r_expected' : 0.1988607,
        'Width (GeV)' : [('zp', 12.48191)],
        'TxNames weights (fb)' : {'TRV1bb': 3.8358441977}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.291734,
        'upper limit (fb)' : 20.8342,
        'expected upper limit (fb)' : 25.9519,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2613.5)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.06200063,
        'r_expected' : 0.04977414,
        'Width (GeV)' : [('zp', 12.482)],
        'TxNames weights (fb)' : {'TRV1qq': 1.29173357188}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.030013e-06,
        'upper limit (fb)' : 0.3867,
        'expected upper limit (fb)' : 0.3313,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2613.5), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-2200-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.300753e-05,
        'r_expected' : 1.518265e-05,
        'Width (GeV)' : [('zp', 12.48191), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 5.030013190573944e-06},
        'nll' : 7.251118,
        'nll_min' : 7.109128,
        'nll_SM' : 7.251134
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.782704e-06,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2613.5), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.259197e-05,
        'r_expected' : 1.234099e-05,
        'Width (GeV)' : [('zp', 12.48191), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 9.78270432482718e-06},
        'nll' : 9.200815,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.172235e-06,
        'upper limit (fb)' : 0.2415,
        'expected upper limit (fb)' : 0.1504,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2018_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 4.853976e-06,
        'r_expected' : 7.794117e-06,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.1722302684744086e-06,
            'TRS1' : 4.923007911410235e-12
        },
        'nll' : 7.14665,
        'nll_min' : 5.36413,
        'nll_SM' : 7.146686
    }
],
'Total xsec for missing topologies (fb)' : 0.9191699,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4484006,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2226749,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2052952,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04279743,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.695874e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.9191699,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4484006,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2226749,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2052952,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04279743,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.695874e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}