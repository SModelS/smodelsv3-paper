smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_a_auwwpy.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 10.09066,
        'upper limit (fb)' : 20.5316,
        'expected upper limit (fb)' : 15.5155,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2893.1)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.49147,
        'r_expected' : 0.6503603,
        'Width (GeV)' : [('zp', 13.817)],
        'TxNames weights (fb)' : {'TRV1jj': 10.090664656000001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.017982,
        'upper limit (fb)' : 7.04242,
        'expected upper limit (fb)' : 6.31805,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2893.1)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2865466,
        'r_expected' : 0.3193994,
        'Width (GeV)' : [('zp', 13.81721)],
        'TxNames weights (fb)' : {'TRV1tt': 2.0179815312000002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 10.09066,
        'upper limit (fb)' : 50.3064,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2893.1)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.2005841,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 13.817)],
        'TxNames weights (fb)' : {'TRV1jj': 10.090664656000001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.018133,
        'upper limit (fb)' : 23.8671,
        'expected upper limit (fb)' : 15.4569,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2893.1)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.08455711,
        'r_expected' : 0.1305652,
        'Width (GeV)' : [('zp', 13.81721)],
        'TxNames weights (fb)' : {'TRV1bb': 2.0181329312000003}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.5070326,
        'upper limit (fb)' : 11.2472,
        'expected upper limit (fb)' : 15.3871,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2893.1)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.04508078,
        'r_expected' : 0.0329518,
        'Width (GeV)' : [('zp', 13.817)],
        'TxNames weights (fb)' : {'TRV1qq': 0.5070325718}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.387246e-06,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2893.1), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 7.186037e-06,
        'r_expected' : 8.257597e-06,
        'Width (GeV)' : [('zp', 13.81721), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 7.387246278963791e-06},
        'nll' : 9.413537,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.25316e-06,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2893.1), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 6.761693e-06,
        'r_expected' : 6.62692e-06,
        'Width (GeV)' : [('zp', 13.81721), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 5.253159616231631e-06},
        'nll' : 9.200813,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.053171e-06,
        'upper limit (fb)' : 0.2868,
        'expected upper limit (fb)' : 0.311,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_14',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 3.672145e-06,
        'r_expected' : 3.386403e-06,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.0531637199627981e-06,
            'TRS1' : 7.570921711966213e-12
        },
        'nll' : 7.341177,
        'nll_min' : 7.341175,
        'nll_SM' : 7.341175
    }
],
'Total xsec for missing topologies (fb)' : 0.46893,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2309001,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1148086,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1049407,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01827997,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.09727e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.46893,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2309001,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1148086,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1049407,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01827997,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.09727e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}