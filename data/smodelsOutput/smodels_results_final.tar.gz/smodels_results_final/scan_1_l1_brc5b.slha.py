smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_l1_brc5b.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 40.57882,
        'upper limit (fb)' : 34.4074,
        'expected upper limit (fb)' : 42.9138,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2090.0)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.179363,
        'r_expected' : 0.945589,
        'Width (GeV)' : [('zp', 17.177)],
        'TxNames weights (fb)' : {'TRV1jj': 40.578816721799996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.113509,
        'upper limit (fb)' : 12.7522,
        'expected upper limit (fb)' : 16.5252,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2090.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6362439,
        'r_expected' : 0.490978,
        'Width (GeV)' : [('zp', 17.17702)],
        'TxNames weights (fb)' : {'TRV1tt': 8.113509478340001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.115763,
        'upper limit (fb)' : 22.6024,
        'expected upper limit (fb)' : 31.775,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2090.0)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.3590664,
        'r_expected' : 0.2554135,
        'Width (GeV)' : [('zp', 17.17702)],
        'TxNames weights (fb)' : {'TRV1bb': 8.11576334436}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 40.57882,
        'upper limit (fb)' : 152.978,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2090.0)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.2652592,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 17.177)],
        'TxNames weights (fb)' : {'TRV1jj': 40.578816721799996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2522973,
        'upper limit (fb)' : 2.306106,
        'expected upper limit (fb)' : 1.980703,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2090.0), ('chi', 462.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.109404,
        'r_expected' : 0.1273776,
        'Width (GeV)' : [('zp', 17.17702), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.2522972651635366},
        'nll' : 59.5243,
        'nll_min' : 59.50498,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 35.12568,
        'upper limit (fb)' : 376.407,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2090.0), ('chi', 462.3)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.09331834,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 17.17702), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 35.1256763144}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.199438,
        'upper limit (fb)' : 29.07455,
        'expected upper limit (fb)' : 15.57032,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.07564824,
        'r_expected' : 0.1412583,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 2.1982719781433153,
            'TRS1' : 0.0011662501633354133
        },
        'nll' : 634.4461,
        'nll_min' : 633.1414,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.444314,
        'upper limit (fb)' : 62.5,
        'expected upper limit (fb)' : 65.3788,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2090.0)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.07110903,
        'r_expected' : 0.06797791,
        'Width (GeV)' : [('zp', 17.177)],
        'TxNames weights (fb)' : {'TRV1qq': 4.444314318}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04753909,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2090.0), ('chi', 462.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.06119075,
        'r_expected' : 0.0599711,
        'Width (GeV)' : [('zp', 17.17702), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.04753909032390896},
        'nll' : 9.224212,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.1094209,
        'r_expected' : 0.1814679,
        'nll' : 693.9704,
        'nll_min' : 693.0903,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 3.737945,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.747743,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8778942,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8645942,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2477034,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.046739e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 3.737945,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.747743,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8778942,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8645942,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2477034,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.046739e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}