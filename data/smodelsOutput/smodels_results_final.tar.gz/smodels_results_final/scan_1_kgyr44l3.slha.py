smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_kgyr44l3.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 55.87411,
        'upper limit (fb)' : 32.1723,
        'expected upper limit (fb)' : 47.2452,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1999.6)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.736715,
        'r_expected' : 1.182641,
        'Width (GeV)' : [('zp', 15.089)],
        'TxNames weights (fb)' : {'TRV1jj': 55.874113095}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.17111,
        'upper limit (fb)' : 15.3918,
        'expected upper limit (fb)' : 18.5907,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 1999.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.7257834,
        'r_expected' : 0.600898,
        'Width (GeV)' : [('zp', 15.08927)],
        'TxNames weights (fb)' : {'TRV1tt': 11.171113668999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.17482,
        'upper limit (fb)' : 25.5001,
        'expected upper limit (fb)' : 35.396,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 1999.6)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.4382266,
        'r_expected' : 0.3157086,
        'Width (GeV)' : [('zp', 15.08927)],
        'TxNames weights (fb)' : {'TRV1bb': 11.174822619}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 55.87411,
        'upper limit (fb)' : 188.852,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1999.6)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.2958619,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 15.089)],
        'TxNames weights (fb)' : {'TRV1jj': 55.874113095}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2672078,
        'upper limit (fb)' : 2.360257,
        'expected upper limit (fb)' : 2.037784,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1999.6), ('chi', 551.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1132113,
        'r_expected' : 0.1311267,
        'Width (GeV)' : [('zp', 15.08927), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.2672078360142696},
        'nll' : 59.52701,
        'nll_min' : 59.51199,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 38.92475,
        'upper limit (fb)' : 390.415,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1999.6), ('chi', 551.3)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.09970096,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 15.08927), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 38.924752042}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.390318,
        'upper limit (fb)' : 28.7901,
        'expected upper limit (fb)' : 15.91695,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1999.6), ('chi', 551.3)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.08302569,
        'r_expected' : 0.1501744,
        'Width (GeV)' : [('zp', 15.08927), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.3903178640976104},
        'nll' : 634.4552,
        'nll_min' : 633.3715,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.602604,
        'upper limit (fb)' : 100.267,
        'expected upper limit (fb)' : 75.4187,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1999.6)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.06585022,
        'r_expected' : 0.08754599,
        'Width (GeV)' : [('zp', 15.089)],
        'TxNames weights (fb)' : {'TRV1qq': 6.6026044524}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05027249,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1999.6), ('chi', 551.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.06470908,
        'r_expected' : 0.06341931,
        'Width (GeV)' : [('zp', 15.08927), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.05027248500480426},
        'nll' : 9.225939,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.1176278,
        'r_expected' : 0.1906758,
        'nll' : 693.9822,
        'nll_min' : 693.2393,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 4.8677,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.260206,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.145278,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.117002,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3451994,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.483685e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 4.8677,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.260206,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.145278,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.117002,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3451994,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.483685e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}