smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_oi6ttxpa.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.24103,
        'upper limit (fb)' : 17.462,
        'expected upper limit (fb)' : 13.8842,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2974.4)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2428719,
        'r_expected' : 0.3054573,
        'Width (GeV)' : [('zp', 28.065)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8481487,
        'upper limit (fb)' : 7.40264,
        'expected upper limit (fb)' : 5.83436,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2974.4)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.1145738,
        'r_expected' : 0.1453713,
        'Width (GeV)' : [('zp', 28.06463)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.24103,
        'upper limit (fb)' : 54.839,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2974.4)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.07733602,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 28.065)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.848206,
        'upper limit (fb)' : 19.2009,
        'expected upper limit (fb)' : 14.5841,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2974.4)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.04417532,
        'r_expected' : 0.05815964,
        'Width (GeV)' : [('zp', 28.06463)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0415914,
        'upper limit (fb)' : 2.163581,
        'expected upper limit (fb)' : 1.877116,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2974.4), ('chi', 187.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.0192234,
        'r_expected' : 0.02215708,
        'Width (GeV)' : [('zp', 28.06463), ('chi', 'stable')],
        'nll' : 59.58829,
        'nll_min' : 59.52089,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.194788,
        'upper limit (fb)' : 11.1667,
        'expected upper limit (fb)' : 13.7636,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2974.4)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.01744365,
        'r_expected' : 0.0141524,
        'Width (GeV)' : [('zp', 28.065)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.360397,
        'upper limit (fb)' : 29.26692,
        'expected upper limit (fb)' : 15.60675,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.01231415,
        'r_expected' : 0.02309239,
        'Width (GeV)' : None,
        'nll' : 634.8446,
        'nll_min' : 633.1173,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00830138,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2974.4), ('chi', 187.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01068526,
        'r_expected' : 0.01047228,
        'Width (GeV)' : [('zp', 28.06463), ('chi', 'stable')],
        'nll' : 9.203993,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.01812765,
        'r_expected' : 0.03051506,
        'nll' : 694.4329,
        'nll_min' : 693.3331,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 0.3863294,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1885078,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09375835,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.08988917,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01417357,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.476374e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.3863294,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1885078,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09375835,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.08988917,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01417357,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.476374e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}