smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_pyyhy5br.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 125.0197,
        'upper limit (fb)' : 45.2319,
        'expected upper limit (fb)' : 72.4383,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1792.2)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 2.763973,
        'r_expected' : 1.725879,
        'Width (GeV)' : [('zp', 10.722)],
        'TxNames weights (fb)' : {'TRV1jj': 125.01974166}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 24.99105,
        'upper limit (fb)' : 42.7572,
        'expected upper limit (fb)' : 26.798,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 1792.2)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5844876,
        'r_expected' : 0.9325715,
        'Width (GeV)' : [('zp', 10.72249)],
        'TxNames weights (fb)' : {'TRV1tt': 24.991052218}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.245313,
        'upper limit (fb)' : 2.549886,
        'expected upper limit (fb)' : 2.113088,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1792.2), ('chi', 694.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.09620548,
        'r_expected' : 0.1160922,
        'Width (GeV)' : [('zp', 10.72249), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.24531301710844927},
        'nll' : 59.50357,
        'nll_min' : 59.44943,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 37.97922,
        'upper limit (fb)' : 489.081,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1792.2), ('chi', 694.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.07765426,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 10.72249), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 37.979224921}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 17.49199,
        'upper limit (fb)' : 232.033,
        'expected upper limit (fb)' : 107.667,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1792.2)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.07538579,
        'r_expected' : 0.1624638,
        'Width (GeV)' : [('zp', 10.722)],
        'TxNames weights (fb)' : {'TRV1qq': 17.4919902816}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.248226,
        'upper limit (fb)' : 30.86856,
        'expected upper limit (fb)' : 16.83045,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1792.2), ('chi', 694.0)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.07283223,
        'r_expected' : 0.1335809,
        'Width (GeV)' : [('zp', 10.72249), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.2482262804025783},
        'nll' : 634.4892,
        'nll_min' : 633.2734,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04475016,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1792.2), ('chi', 694.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.05760093,
        'r_expected' : 0.05645283,
        'Width (GeV)' : [('zp', 10.72249), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.04475016113991588},
        'nll' : 9.222492,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.1007705,
        'r_expected' : 0.1671046,
        'nll' : 693.9928,
        'nll_min' : 693.0286,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 9.2795,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.228404,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.195528,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.083744,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7717892,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.487759e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 9.2795,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.228404,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.195528,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.083744,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7717892,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.487759e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}