smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_ydoiqhf8.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 35.29707,
        'upper limit (fb)' : 31.9031,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2359.5)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.106384,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.269)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 35.29707,
        'upper limit (fb)' : 37.6748,
        'expected upper limit (fb)' : 30.089,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2359.5)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.9368881,
        'r_expected' : 1.173089,
        'Width (GeV)' : [('zp', 11.269)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.058211,
        'upper limit (fb)' : 11.3623,
        'expected upper limit (fb)' : 11.4212,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2359.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6211956,
        'r_expected' : 0.6179921,
        'Width (GeV)' : [('zp', 11.26877)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.059414,
        'upper limit (fb)' : 19.4303,
        'expected upper limit (fb)' : 24.1612,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2359.5)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.3633199,
        'r_expected' : 0.2921798,
        'Width (GeV)' : [('zp', 11.26877)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.038112,
        'upper limit (fb)' : 39.6833,
        'expected upper limit (fb)' : 38.1769,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2359.5)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.07655897,
        'r_expected' : 0.07957986,
        'Width (GeV)' : [('zp', 11.269)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.307366e-05,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2359.5), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 2.24452e-05,
        'r_expected' : 2.579216e-05,
        'Width (GeV)' : [('zp', 11.26877), ('chi', 'stable')],
        'nll' : 9.413514,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.643462e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2359.5), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 2.11541e-05,
        'r_expected' : 2.073246e-05,
        'Width (GeV)' : [('zp', 11.26877), ('chi', 'stable')],
        'nll' : 9.200818,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.511239e-06,
        'upper limit (fb)' : 0.1092,
        'expected upper limit (fb)' : 0.09753,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.383918e-05,
        'r_expected' : 1.549512e-05,
        'Width (GeV)' : None,
        'nll' : 4.731703,
        'nll_min' : 4.655234,
        'nll_SM' : 4.731716
    }
],
'Total xsec for missing topologies (fb)' : 1.7719,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8549433,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4239065,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3949624,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09808363,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.98722e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.7719,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8549433,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4239065,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3949624,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09808363,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.98722e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}