smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1___h0t3ue.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.821241,
        'upper limit (fb)' : 2.74429,
        'expected upper limit (fb)' : 2.287172,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1485.2), ('chi', 267.2)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 1.392433,
        'r_expected' : 1.670727,
        'Width (GeV)' : [('zp', 60.31111), ('chi', 'stable')],
        'nll' : 63.16905,
        'nll_min' : 59.45714,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 783.8018,
        'upper limit (fb)' : 634.028,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1485.2), ('chi', 267.2)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.236226,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 60.31111), ('chi', 'stable')]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 41.14646,
        'upper limit (fb)' : 36.88093,
        'expected upper limit (fb)' : 19.88524,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 1.115657,
        'r_expected' : 2.069196,
        'Width (GeV)' : None,
        'nll' : 635.4951,
        'nll_min' : 633.193,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.6223191,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1485.2), ('chi', 267.2)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.8010285,
        'r_expected' : 0.7850625,
        'Width (GeV)' : [('zp', 60.31111), ('chi', 'stable')],
        'nll' : 10.49619,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 1.49512,
        'r_expected' : 2.520362,
        'nll' : 698.6641,
        'nll_min' : 692.9374,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 25.44349,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.99879,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.418918,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.384503,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.641138,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0001349989,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 25.44349,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 10.99879,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.418918,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.384503,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.641138,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0001349989,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 2170.899,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1447.531,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 361.8828,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 361.4848,
        'SMS' : 'PV > (t,t)'
    }
]
}