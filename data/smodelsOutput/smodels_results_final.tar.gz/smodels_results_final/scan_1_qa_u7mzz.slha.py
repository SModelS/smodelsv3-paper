smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_qa_u7mzz.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 18.96289,
        'upper limit (fb)' : 37.2924,
        'expected upper limit (fb)' : 23.2525,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2507.5)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5084921,
        'r_expected' : 0.8155204,
        'Width (GeV)' : [('zp', 15.561)],
        'TxNames weights (fb)' : {'TRV1jj': 18.962889008}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.792069,
        'upper limit (fb)' : 8.29434,
        'expected upper limit (fb)' : 9.44259,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2507.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4571876,
        'r_expected' : 0.4015921,
        'Width (GeV)' : [('zp', 15.56126)],
        'TxNames weights (fb)' : {'TRV1tt': 3.7920690944000004}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 18.96289,
        'upper limit (fb)' : 45.3351,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2507.5)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.4182827,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 15.561)],
        'TxNames weights (fb)' : {'TRV1jj': 18.962889008}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.792578,
        'upper limit (fb)' : 33.005,
        'expected upper limit (fb)' : 21.1187,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2507.5)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.1149092,
        'r_expected' : 0.1795839,
        'Width (GeV)' : [('zp', 15.56126)],
        'TxNames weights (fb)' : {'TRV1bb': 3.7925778016000002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.417934,
        'upper limit (fb)' : 32.4583,
        'expected upper limit (fb)' : 31.1103,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2507.5)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.04368478,
        'r_expected' : 0.04557763,
        'Width (GeV)' : [('zp', 15.561)],
        'TxNames weights (fb)' : {'TRV1qq': 1.41793374016}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05997716,
        'upper limit (fb)' : 2.215131,
        'expected upper limit (fb)' : 1.928377,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2507.5), ('chi', 931.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.02707612,
        'r_expected' : 0.0311024,
        'Width (GeV)' : [('zp', 15.56126), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.05997716456090544},
        'nll' : 59.5824,
        'nll_min' : 59.5238,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4651562,
        'upper limit (fb)' : 27.68587,
        'expected upper limit (fb)' : 14.48127,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2507.5), ('chi', 931.6)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.01680121,
        'r_expected' : 0.03212124,
        'Width (GeV)' : [('zp', 15.56126), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.4651562295764647},
        'nll' : 634.8072,
        'nll_min' : 632.9677,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01209992,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2507.5), ('chi', 931.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01557462,
        'r_expected' : 0.01526419,
        'Width (GeV)' : [('zp', 15.56126), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.012099924925604048},
        'nll' : 9.205576,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.02567231,
        'r_expected' : 0.04262815,
        'nll' : 694.3896,
        'nll_min' : 693.097,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 1.1959,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5731632,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2844642,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2793011,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05896918,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.359397e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.1959,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5731632,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2844642,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2793011,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05896918,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.359397e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}