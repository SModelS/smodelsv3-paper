smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_o2j3msts.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 32.27882,
        'upper limit (fb)' : 31.9361,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2360.5)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.010731,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 12.3)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 32.27882,
        'upper limit (fb)' : 37.6744,
        'expected upper limit (fb)' : 30.0414,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2360.5)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.8567839,
        'r_expected' : 1.074478,
        'Width (GeV)' : [('zp', 12.3)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.454665,
        'upper limit (fb)' : 11.3523,
        'expected upper limit (fb)' : 11.4072,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2360.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5685777,
        'r_expected' : 0.5658413,
        'Width (GeV)' : [('zp', 12.30017)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.455764,
        'upper limit (fb)' : 19.4249,
        'expected upper limit (fb)' : 24.1387,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2360.5)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.3323448,
        'r_expected' : 0.2674446,
        'Width (GeV)' : [('zp', 12.30017)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.776006,
        'upper limit (fb)' : 39.65,
        'expected upper limit (fb)' : 38.0979,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2360.5)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.07001276,
        'r_expected' : 0.07286507,
        'Width (GeV)' : [('zp', 12.3)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02954924,
        'upper limit (fb)' : 2.259025,
        'expected upper limit (fb)' : 1.945407,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2360.5), ('chi', 1053.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.01308053,
        'r_expected' : 0.01518924,
        'Width (GeV)' : [('zp', 12.30017), ('chi', 'stable')],
        'nll' : 59.59265,
        'nll_min' : 59.51949,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2379892,
        'upper limit (fb)' : 27.14863,
        'expected upper limit (fb)' : 14.31207,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2360.5), ('chi', 1053.7)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.008766161,
        'r_expected' : 0.01662857,
        'Width (GeV)' : [('zp', 12.30017), ('chi', 'stable')],
        'nll' : 634.8667,
        'nll_min' : 633.0328,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.005851298,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2360.5), ('chi', 1053.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.007531597,
        'r_expected' : 0.007381478,
        'Width (GeV)' : [('zp', 12.30017), ('chi', 'stable')],
        'nll' : 9.203014,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.0128156,
        'r_expected' : 0.02148669,
        'nll' : 694.4593,
        'nll_min' : 693.0563,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 1.7679,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8409541,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4169728,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4135567,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09641239,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.918858e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.7679,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8409541,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4169728,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4135567,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09641239,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.918858e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}