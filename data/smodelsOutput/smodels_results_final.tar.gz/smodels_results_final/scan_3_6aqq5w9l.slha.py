smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_6aqq5w9l.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 27.74716,
        'upper limit (fb)' : 37.6358,
        'expected upper limit (fb)' : 25.3922,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2458.2)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.7372545,
        'r_expected' : 1.092744,
        'Width (GeV)' : [('zp', 11.74)],
        'TxNames weights (fb)' : {'TRV1jj': 27.747161515000002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 27.74716,
        'upper limit (fb)' : 39.5493,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2458.2)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.7015841,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.74)],
        'TxNames weights (fb)' : {'TRV1jj': 27.747161515000002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.54863,
        'upper limit (fb)' : 9.31202,
        'expected upper limit (fb)' : 10.0783,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2458.2)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5958567,
        'r_expected' : 0.5505521,
        'Width (GeV)' : [('zp', 11.74006)],
        'TxNames weights (fb)' : {'TRV1tt': 5.548629652500001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.549432,
        'upper limit (fb)' : 26.9788,
        'expected upper limit (fb)' : 22.086,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2458.2)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.205696,
        'r_expected' : 0.2512647,
        'Width (GeV)' : [('zp', 11.74006)],
        'TxNames weights (fb)' : {'TRV1bb': 5.549432303000001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.175584,
        'upper limit (fb)' : 35.4233,
        'expected upper limit (fb)' : 33.135,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2458.2)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.06141675,
        'r_expected' : 0.06565819,
        'Width (GeV)' : [('zp', 11.74)],
        'TxNames weights (fb)' : {'TRV1qq': 2.17558407728}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.815709e-06,
        'upper limit (fb)' : 0.3867,
        'expected upper limit (fb)' : 0.3313,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2458.2), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-2200-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.762532e-05,
        'r_expected' : 2.057262e-05,
        'Width (GeV)' : [('zp', 11.74006), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6.815709451043943e-06},
        'nll' : 7.251112,
        'nll_min' : 7.109128,
        'nll_SM' : 7.251134
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.337342e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2458.2), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.721382e-05,
        'r_expected' : 1.687072e-05,
        'Width (GeV)' : [('zp', 11.74006), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.3373420503222675e-05},
        'nll' : 9.200816,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.163605e-06,
        'upper limit (fb)' : 0.1092,
        'expected upper limit (fb)' : 0.09753,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.065572e-05,
        'r_expected' : 1.193073e-05,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.1635993044921473e-06,
            'TRS1' : 5.2768733987071254e-12
        },
        'nll' : 4.731706,
        'nll_min' : 4.655234,
        'nll_SM' : 4.731716
    }
],
'Total xsec for missing topologies (fb)' : 1.3678,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6630129,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3289581,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3051287,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.07069736,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.84271e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.3678,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6630129,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3289581,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3051287,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.07069736,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.84271e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}