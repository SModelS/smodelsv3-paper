smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_en7hx5ng.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 37.88733,
        'upper limit (fb)' : 30.9405,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2330.3)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 1.224522,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.129)],
        'TxNames weights (fb)' : {'TRV1jj': 37.887328928}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 37.88733,
        'upper limit (fb)' : 37.6863,
        'expected upper limit (fb)' : 31.4786,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2330.3)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.005334,
        'r_expected' : 1.20359,
        'Width (GeV)' : [('zp', 11.129)],
        'TxNames weights (fb)' : {'TRV1jj': 37.887328928}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.576106,
        'upper limit (fb)' : 11.6543,
        'expected upper limit (fb)' : 11.8299,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2330.3)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6500696,
        'r_expected' : 0.6404201,
        'Width (GeV)' : [('zp', 11.12912)],
        'TxNames weights (fb)' : {'TRV1tt': 7.576106053200001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.577466,
        'upper limit (fb)' : 19.5877,
        'expected upper limit (fb)' : 24.8182,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2330.3)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.3868482,
        'r_expected' : 0.3053189,
        'Width (GeV)' : [('zp', 11.12912)],
        'TxNames weights (fb)' : {'TRV1bb': 7.577465785600001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.349308,
        'upper limit (fb)' : 40.6567,
        'expected upper limit (fb)' : 40.4853,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2330.3)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.08238022,
        'r_expected' : 0.08272899,
        'Width (GeV)' : [('zp', 11.129)],
        'TxNames weights (fb)' : {'TRV1qq': 3.34930786048}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.486788e-05,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2330.3), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 2.419054e-05,
        'r_expected' : 2.779776e-05,
        'Width (GeV)' : [('zp', 11.12912), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.486787512896445e-05},
        'nll' : 9.413512,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.742632e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2330.3), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 2.243058e-05,
        'r_expected' : 2.19835e-05,
        'Width (GeV)' : [('zp', 11.12912), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.7426317607255646e-05},
        'nll' : 9.200818,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.631971e-06,
        'upper limit (fb)' : 0.1092,
        'expected upper limit (fb)' : 0.09753,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.494479e-05,
        'r_expected' : 1.673302e-05,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.6319637329871791e-06,
            'TRS1' : 7.27791648119144e-12
        },
        'nll' : 4.731702,
        'nll_min' : 4.655234,
        'nll_SM' : 4.731716
    }
],
'Total xsec for missing topologies (fb)' : 1.9093,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9198967,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4560159,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4254887,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1078944,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.401517e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.9093,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9198967,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4560159,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4254887,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1078944,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.401517e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}