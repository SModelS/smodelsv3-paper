smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_5w1y_m40.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2164.567,
        'upper limit (fb)' : 3106.18,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 747.9)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.6968583,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 3.561)],
        'TxNames weights (fb)' : {'TRV1qq': 2164.56723384}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 541.1418,
        'upper limit (fb)' : 937.544,
        'expected upper limit (fb)' : 1156.03,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 747.9)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.5771908,
        'r_expected' : 0.4681036,
        'Width (GeV)' : [('zp', 3.561032)],
        'TxNames weights (fb)' : {'TRV1bb': 541.14180846}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.340128,
        'upper limit (fb)' : 2859.83,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 747.9), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.0008182751,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 3.561032), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.3401275863700004}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0008195712,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 747.9), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0007972482,
        'r_expected' : 0.0009161314,
        'Width (GeV)' : [('zp', 3.561032), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0008195711839364334},
        'nll' : 9.412345,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001153306,
        'upper limit (fb)' : 1.809,
        'expected upper limit (fb)' : 1.983,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_7',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0006375381,
        'r_expected' : 0.0005815968,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 0.0011522811636561743,
            'TRS1' : 1.0253161224641925e-06
        },
        'nll' : 11.89516,
        'nll_min' : 11.89441,
        'nll_SM' : 11.89441
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003784618,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 747.9), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0004871435,
        'r_expected' : 0.0004774339,
        'Width (GeV)' : [('zp', 3.561032), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.000378461814160861},
        'nll' : 9.200948,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'Total xsec for missing topologies (fb)' : 398.7361,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 180.7876,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 116.4606,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 83.32418,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.15306,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01071417,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 398.7361,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 180.7876,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 116.4606,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 83.32418,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 18.15306,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01071417,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 1443.543,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1443.543,
        'SMS' : 'PV > (t,t)'
    }
]
}