smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_w3gglyd7.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 12.54059,
        'upper limit (fb)' : 3.254596,
        'expected upper limit (fb)' : 2.778399,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 940.7), ('chi', 151.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 3.853194,
        'r_expected' : 4.513604,
        'Width (GeV)' : [('zp', 31.25119), ('chi', 'stable')],
        'nll' : 93.41613,
        'nll_min' : 59.48717,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 200.1259,
        'upper limit (fb)' : 53.55356,
        'expected upper limit (fb)' : 30.45477,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 3.73693,
        'r_expected' : 6.571249,
        'Width (GeV)' : None,
        'nll' : 694.6538,
        'nll_min' : 633.5582,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5370.024,
        'upper limit (fb)' : 1710.28,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 940.7), ('chi', 151.8)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 3.139851,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 31.25119), ('chi', 'stable')]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.548307,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 940.7), ('chi', 151.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.992929,
        'r_expected' : 1.953207,
        'Width (GeV)' : [('zp', 31.25119), ('chi', 'stable')],
        'nll' : 16.3418,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 32.68196,
        'upper limit (fb)' : 7157.4,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRS1'],
        'Mass (GeV)' : [('sd', 470.3), ('chi', 151.8)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.004566178,
        'r_expected' : None,
        'Width (GeV)' : [('sd', 5.473305), ('chi', 'stable')]
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 4.688986,
        'r_expected' : 7.632432,
        'nll' : 999.0,
        'nll_min' : 693.1957,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 187.008,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 72.08345,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 58.91816,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 34.20795,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 21.796,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.002445027,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 187.008,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 72.08345,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 58.91816,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 34.20795,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 21.796,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.002445027,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 2561.876,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1709.921,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 427.4803,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 424.4748,
        'SMS' : 'PV > (t,t)'
    }
]
}