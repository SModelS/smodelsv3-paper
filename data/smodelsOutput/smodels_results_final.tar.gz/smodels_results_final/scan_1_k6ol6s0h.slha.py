smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_k6ol6s0h.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 69.77658,
        'upper limit (fb)' : 38.4404,
        'expected upper limit (fb)' : 64.4455,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1858.0)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.815189,
        'r_expected' : 1.082722,
        'Width (GeV)' : [('zp', 16.565)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.95532,
        'upper limit (fb)' : 30.017,
        'expected upper limit (fb)' : 45.0875,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 1858.0)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.4649138,
        'r_expected' : 0.3095163,
        'Width (GeV)' : [('zp', 16.56468)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 69.77658,
        'upper limit (fb)' : 212.435,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1858.0)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.3284609,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 16.565)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.9491,
        'upper limit (fb)' : 44.2211,
        'expected upper limit (fb)' : 23.9133,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 1858.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3154398,
        'r_expected' : 0.5833195,
        'Width (GeV)' : [('zp', 16.56468)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4553486,
        'upper limit (fb)' : 2.505805,
        'expected upper limit (fb)' : 2.126716,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1858.0), ('chi', 279.5)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1817175,
        'r_expected' : 0.2141088,
        'Width (GeV)' : [('zp', 16.56468), ('chi', 'stable')],
        'nll' : 59.4894,
        'nll_min' : 59.4874,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 72.62432,
        'upper limit (fb)' : 442.253,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1858.0), ('chi', 279.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.1642144,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 16.56468), ('chi', 'stable')]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.246689,
        'upper limit (fb)' : 30.97154,
        'expected upper limit (fb)' : 16.67076,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1371158,
        'r_expected' : 0.2547388,
        'Width (GeV)' : None,
        'nll' : 634.1203,
        'nll_min' : 633.1688,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.08100227,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1858.0), ('chi', 279.5)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1042634,
        'r_expected' : 0.1021853,
        'Width (GeV)' : [('zp', 16.56468), ('chi', 'stable')],
        'nll' : 9.248209,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.26201,
        'upper limit (fb)' : 194.667,
        'expected upper limit (fb)' : 95.99,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1858.0)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.04757874,
        'r_expected' : 0.09648932,
        'Width (GeV)' : [('zp', 16.565)]
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.1892116,
        'r_expected' : 0.3168379,
        'nll' : 693.6097,
        'nll_min' : 693.0126,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 7.469848,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.425794,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.763739,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.689923,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5903652,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.620499e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 7.469848,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.425794,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.763739,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.689923,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5903652,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.620499e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}