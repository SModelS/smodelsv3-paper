smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_tvfaxsni.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 68.22284,
        'upper limit (fb)' : 39.0297,
        'expected upper limit (fb)' : 66.0003,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1845.2)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.747972,
        'r_expected' : 1.033675,
        'Width (GeV)' : [('zp', 17.421)],
        'TxNames weights (fb)' : {'TRV1jj': 68.22284197200001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.64457,
        'upper limit (fb)' : 32.3698,
        'expected upper limit (fb)' : 46.4475,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 1845.2)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.4215216,
        'r_expected' : 0.2937632,
        'Width (GeV)' : [('zp', 17.42147)],
        'TxNames weights (fb)' : {'TRV1bb': 13.644568394400002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 68.22284,
        'upper limit (fb)' : 213.715,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1845.2)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.3192235,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 17.421)],
        'TxNames weights (fb)' : {'TRV1jj': 68.22284197200001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 13.63831,
        'upper limit (fb)' : 43.9363,
        'expected upper limit (fb)' : 24.4744,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 1845.2)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3104111,
        'r_expected' : 0.5572482,
        'Width (GeV)' : [('zp', 17.42147)],
        'TxNames weights (fb)' : {'TRV1tt': 13.638314583700001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4753857,
        'upper limit (fb)' : 2.488723,
        'expected upper limit (fb)' : 2.090496,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1845.2), ('chi', 113.1)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1910159,
        'r_expected' : 0.2274033,
        'Width (GeV)' : [('zp', 17.42147), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.47538567526861253},
        'nll' : 59.47431,
        'nll_min' : 59.47202,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 80.02885,
        'upper limit (fb)' : 437.038,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1845.2), ('chi', 113.1)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.1831165,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 17.42147), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 80.028848301}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.524314,
        'upper limit (fb)' : 32.17783,
        'expected upper limit (fb)' : 16.63424,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1406035,
        'r_expected' : 0.271988,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 4.522620310012883,
            'TRS1' : 0.0016938162318756887
        },
        'nll' : 633.9917,
        'nll_min' : 632.8632,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.08637514,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1845.2), ('chi', 113.1)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1111792,
        'r_expected' : 0.1089632,
        'Width (GeV)' : [('zp', 17.42147), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0863751359712693},
        'nll' : 9.252641,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.15077,
        'upper limit (fb)' : 203.2,
        'expected upper limit (fb)' : 98.2616,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1845.2)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.04503331,
        'r_expected' : 0.09312661,
        'Width (GeV)' : [('zp', 17.421)],
        'TxNames weights (fb)' : {'TRV1qq': 9.15076953312}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.1939582,
        'r_expected' : 0.3366688,
        'nll' : 693.466,
        'nll_min' : 692.7564,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 7.839916,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.591143,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.851813,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.771157,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6257752,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.786912e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 7.839916,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.591143,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.851813,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.771157,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6257752,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.786912e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}