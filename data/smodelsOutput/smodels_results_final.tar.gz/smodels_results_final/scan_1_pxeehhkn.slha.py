smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_pxeehhkn.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 275.4494,
        'upper limit (fb)' : 67.05137,
        'expected upper limit (fb)' : 41.22603,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 375.1), ('chi', 177.4)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 4.108035,
        'r_expected' : 6.681444,
        'Width (GeV)' : [('zp', 10.72507), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 275.44942028617714},
        'nll' : 701.4504,
        'nll_min' : 634.0103,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.694261,
        'upper limit (fb)' : 3.365618,
        'expected upper limit (fb)' : 3.158547,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 375.1), ('chi', 177.4)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 2.286136,
        'r_expected' : 2.436013,
        'Width (GeV)' : [('zp', 10.72507), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 7.6942609700004345},
        'nll' : 99.56786,
        'nll_min' : 89.08768,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.179459,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 375.1), ('chi', 177.4)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.8001756,
        'r_expected' : 0.7759597,
        'Width (GeV)' : [('zp', 10.72507), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.1794587630233626},
        'nll' : 12.08375,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 4.572133,
        'r_expected' : 7.031668,
        'nll' : 999.0,
        'nll_min' : 723.1384,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 801.12,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 645.2945,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 155.4959,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3296598,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 801.12,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 645.2945,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 155.4959,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3296598,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 658194.9,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 472971.1,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 118242.8,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 66981.0,
        'SMS' : 'PV > (t,t)'
    }
]
}