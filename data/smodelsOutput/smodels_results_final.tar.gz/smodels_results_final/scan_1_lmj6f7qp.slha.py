smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_lmj6f7qp.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.359257,
        'upper limit (fb)' : 3.191819,
        'expected upper limit (fb)' : 2.64579,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 967.2), ('chi', 194.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 1.052458,
        'r_expected' : 1.269661,
        'Width (GeV)' : [('zp', 8.153201), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 3.3592568414882655},
        'nll' : 61.30768,
        'nll_min' : 59.44571,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 51.41726,
        'upper limit (fb)' : 51.18257,
        'expected upper limit (fb)' : 28.77881,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 1.004585,
        'r_expected' : 1.786636,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 51.25512812511178,
            'TRS1' : 0.16212721766636726
        },
        'nll' : 635.0416,
        'nll_min' : 633.4744,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 376.5083,
        'upper limit (fb)' : 396.651,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 967.2)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.949218,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 8.1532)],
        'TxNames weights (fb)' : {'TRV1qq': 376.5082578624}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1361.336,
        'upper limit (fb)' : 1569.08,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 967.2), ('chi', 194.8)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.8676011,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 8.153201), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1361.33550552}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4365572,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 967.2), ('chi', 194.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.5619219,
        'r_expected' : 0.5507218,
        'Width (GeV)' : [('zp', 8.153201), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.43655715391667016},
        'nll' : 9.885952,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 94.12706,
        'upper limit (fb)' : 573.53,
        'expected upper limit (fb)' : 684.625,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 967.2)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.1641188,
        'r_expected' : 0.137487,
        'Width (GeV)' : [('zp', 8.153201)],
        'TxNames weights (fb)' : {'TRV1bb': 94.1270644656}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 1.259234,
        'r_expected' : 2.081932,
        'nll' : 696.3493,
        'nll_min' : 693.065,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 193.8429,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 79.16639,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 52.44144,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 37.67355,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 24.55904,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.002516716,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 193.8429,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 79.16639,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 52.44144,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 37.67355,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 24.55904,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.002516716,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 294.0966,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 294.0966,
        'SMS' : 'PV > (t,t)'
    }
]
}