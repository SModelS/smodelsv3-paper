smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_ea8hpnxx.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 53.39087,
        'upper limit (fb)' : 130.6,
        'expected upper limit (fb)' : 249.002,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1454.1)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.4088122,
        'r_expected' : 0.2144194,
        'Width (GeV)' : [('zp', 10.246)],
        'TxNames weights (fb)' : {'TRV1qq': 53.39086694400001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 53.39087,
        'upper limit (fb)' : 142.733,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1454.1)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.3740611,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 10.246)],
        'TxNames weights (fb)' : {'TRV1qq': 53.39086694400001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.8078656,
        'upper limit (fb)' : 2.710902,
        'expected upper limit (fb)' : 2.298484,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1454.1), ('chi', 454.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2980062,
        'r_expected' : 0.3514777,
        'Width (GeV)' : [('zp', 10.24627), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.8078656305904844},
        'nll' : 59.50263,
        'nll_min' : 59.48282,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 168.673,
        'upper limit (fb)' : 664.414,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1454.1), ('chi', 454.3)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2538674,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 10.24627), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 168.673043427}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.739355,
        'upper limit (fb)' : 38.44616,
        'expected upper limit (fb)' : 19.62504,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1454.1), ('chi', 454.3)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.2273141,
        'r_expected' : 0.4453166,
        'Width (GeV)' : [('zp', 10.24627), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 8.739355245859008},
        'nll' : 633.4976,
        'nll_min' : 632.7577,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.127422,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1454.1), ('chi', 454.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1640134,
        'r_expected' : 0.1607443,
        'Width (GeV)' : [('zp', 10.24627), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.12742202658040602},
        'nll' : 9.291783,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.3067603,
        'r_expected' : 0.540562,
        'nll' : 693.0002,
        'nll_min' : 692.6587,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 29.624,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.95258,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.13912,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.335229,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.196904,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.000166341,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 29.624,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 12.95258,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.13912,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.335229,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.196904,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.000166341,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 118.0519,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 59.0613,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 58.9906,
        'SMS' : 'PV > (t,t)'
    }
]
}