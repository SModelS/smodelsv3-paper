smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_0e0ilsp8.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 15.46009,
        'upper limit (fb)' : 36.9698,
        'expected upper limit (fb)' : 23.1041,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2514.9)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4181816,
        'r_expected' : 0.6691492,
        'Width (GeV)' : [('zp', 18.817)],
        'TxNames weights (fb)' : {'TRV1jj': 15.460091064}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.091611,
        'upper limit (fb)' : 8.22973,
        'expected upper limit (fb)' : 9.37348,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2514.9)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3756637,
        'r_expected' : 0.3298253,
        'Width (GeV)' : [('zp', 18.81704)],
        'TxNames weights (fb)' : {'TRV1tt': 3.0916111908000006}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 15.46009,
        'upper limit (fb)' : 46.5715,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2514.9)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.3319646,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 18.817)],
        'TxNames weights (fb)' : {'TRV1jj': 15.460091064}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.092018,
        'upper limit (fb)' : 33.447,
        'expected upper limit (fb)' : 20.9893,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2514.9)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.09244531,
        'r_expected' : 0.147314,
        'Width (GeV)' : [('zp', 18.81704)],
        'TxNames weights (fb)' : {'TRV1bb': 3.0920182128}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09034448,
        'upper limit (fb)' : 2.232913,
        'expected upper limit (fb)' : 1.949652,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2514.9), ('chi', 705.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.04046036,
        'r_expected' : 0.04633877,
        'Width (GeV)' : [('zp', 18.81704), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.09034447822579779},
        'nll' : 59.57339,
        'nll_min' : 59.5274,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.147726,
        'upper limit (fb)' : 31.595,
        'expected upper limit (fb)' : 30.8064,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2514.9)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.03632618,
        'r_expected' : 0.03725607,
        'Width (GeV)' : [('zp', 18.817)],
        'TxNames weights (fb)' : {'TRV1qq': 1.14772550976}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.7092511,
        'upper limit (fb)' : 27.26787,
        'expected upper limit (fb)' : 14.5493,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2514.9), ('chi', 705.6)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.02601051,
        'r_expected' : 0.04874814,
        'Width (GeV)' : [('zp', 18.81704), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.7092510907759212},
        'nll' : 634.7527,
        'nll_min' : 633.1148,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01784633,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2514.9), ('chi', 705.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.02297121,
        'r_expected' : 0.02251335,
        'Width (GeV)' : [('zp', 18.81704), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.017846330448385694},
        'nll' : 9.208124,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.03914065,
        'r_expected' : 0.06442511,
        'nll' : 694.3261,
        'nll_min' : 693.1875,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 1.1775,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5645399,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2801964,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2749837,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05777763,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.310084e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.1775,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5645399,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2801964,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2749837,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05777763,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.310084e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}