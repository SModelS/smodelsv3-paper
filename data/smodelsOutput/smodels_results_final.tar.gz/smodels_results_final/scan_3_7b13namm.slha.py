smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_7b13namm.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 48.91758,
        'upper limit (fb)' : 14739.5,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 317.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.003318809,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 1.263848), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 48.917583103999995}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.004894547,
        'upper limit (fb)' : 1.809,
        'expected upper limit (fb)' : 1.983,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 317.6), ('chi', 65.0)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_7',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.002705664,
        'r_expected' : 0.002468253,
        'Width (GeV)' : [('zp', 1.263848), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.004894546612636928},
        'nll' : 11.89761,
        'nll_min' : 11.89441,
        'nll_SM' : 11.89441
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001956107,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 317.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.001902827,
        'r_expected' : 0.002186571,
        'Width (GeV)' : [('zp', 1.263848), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0019561065296461308},
        'nll' : 9.410683,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001489986,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 317.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.001010845,
        'r_expected' : 0.0009802537,
        'Width (GeV)' : [('zp', 1.263848), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0014899855555230463},
        'nll' : 10.69786,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'Total xsec for missing topologies (fb)' : 758.7733,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 758.7733,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 758.7733,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 758.7733,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 193577.9,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 154584.9,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 38646.2,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 346.8267,
        'SMS' : 'PV > (MET,MET)'
    }
]
}