smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_tbbtc1qy.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 206.3402,
        'upper limit (fb)' : 56.3492,
        'expected upper limit (fb)' : 83.978,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1697.2)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 3.661813,
        'r_expected' : 2.457075,
        'Width (GeV)' : [('zp', 8.1047)],
        'TxNames weights (fb)' : {'TRV1jj': 206.34024645000002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31.08743,
        'upper limit (fb)' : 122.519,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1697.2)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.2537356,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 8.1047)],
        'TxNames weights (fb)' : {'TRV1qq': 31.0874306616}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31.08743,
        'upper limit (fb)' : 214.053,
        'expected upper limit (fb)' : 136.23,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1697.2)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.1452324,
        'r_expected' : 0.2281981,
        'Width (GeV)' : [('zp', 8.1047)],
        'TxNames weights (fb)' : {'TRV1qq': 31.0874306616}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06817564,
        'upper limit (fb)' : 490.158,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1697.2), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.0001390891,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 8.10467), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.068175642795}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0001018251,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1697.2), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 9.905165e-05,
        'r_expected' : 0.0001138219,
        'Width (GeV)' : [('zp', 8.10467), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.00010182509480932818},
        'nll' : 9.413399,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.365369e-05,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1697.2), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 8.193292e-05,
        'r_expected' : 8.029985e-05,
        'Width (GeV)' : [('zp', 8.10467), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6.365368875969325e-05},
        'nll' : 9.200835,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.016568e-05,
        'upper limit (fb)' : 0.1837,
        'expected upper limit (fb)' : 0.1871,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2018_18',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 5.533846e-05,
        'r_expected' : 5.433285e-05,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.0165465570234066e-05,
            'TRS1' : 2.10154916712719e-10
        },
        'nll' : 6.096366,
        'nll_min' : 6.09636,
        'nll_SM' : 6.09636
    }
],
'Total xsec for missing topologies (fb)' : 12.668,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.828661,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.86756,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.81429,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.157431,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.390557e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 12.668,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.828661,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.86756,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.81429,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.157431,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 5.390557e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 41.24158,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41.24158,
        'SMS' : 'PV > (t,t)'
    }
]
}