smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_2t66hji0.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 21.43985,
        'upper limit (fb)' : 37.0526,
        'expected upper limit (fb)' : 23.1422,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2513.0)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5786327,
        'r_expected' : 0.9264395,
        'Width (GeV)' : [('zp', 13.618)],
        'TxNames weights (fb)' : {'TRV1jj': 21.4398475335}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.287403,
        'upper limit (fb)' : 8.24632,
        'expected upper limit (fb)' : 9.39123,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2513.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5199171,
        'r_expected' : 0.4565326,
        'Width (GeV)' : [('zp', 13.61771)],
        'TxNames weights (fb)' : {'TRV1tt': 4.287403046099999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 21.43985,
        'upper limit (fb)' : 46.254,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2513.0)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.4635242,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 13.618)],
        'TxNames weights (fb)' : {'TRV1jj': 21.4398475335}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.28797,
        'upper limit (fb)' : 33.3335,
        'expected upper limit (fb)' : 21.0225,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2513.0)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.1286384,
        'r_expected' : 0.2039705,
        'Width (GeV)' : [('zp', 13.61771)],
        'TxNames weights (fb)' : {'TRV1bb': 4.2879695067}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.594533,
        'upper limit (fb)' : 31.8167,
        'expected upper limit (fb)' : 30.8845,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2513.0)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.05011623,
        'r_expected' : 0.05162891,
        'Width (GeV)' : [('zp', 13.618)],
        'TxNames weights (fb)' : {'TRV1qq': 1.5945331313999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.03044471,
        'upper limit (fb)' : 2.170086,
        'expected upper limit (fb)' : 1.894923,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2513.0), ('chi', 1078.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.01402926,
        'r_expected' : 0.01606646,
        'Width (GeV)' : [('zp', 13.61771), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.030444710467486483},
        'nll' : 59.59325,
        'nll_min' : 59.5303,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2387703,
        'upper limit (fb)' : 27.62689,
        'expected upper limit (fb)' : 14.34566,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2513.0), ('chi', 1078.6)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.008642675,
        'r_expected' : 0.01664408,
        'Width (GeV)' : [('zp', 13.61771), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.23877027744958257},
        'nll' : 634.8647,
        'nll_min' : 632.9128,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.006141237,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2513.0), ('chi', 1078.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.007904797,
        'r_expected' : 0.007747239,
        'Width (GeV)' : [('zp', 13.61771), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0061412366545949525},
        'nll' : 9.203128,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.01319106,
        'r_expected' : 0.02215082,
        'nll' : 694.4579,
        'nll_min' : 693.0905,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 1.1821,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5666964,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2812637,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.276063,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0580745,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.322364e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.1821,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5666964,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2812637,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.276063,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0580745,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.322364e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}