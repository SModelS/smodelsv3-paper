smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_yp67oftv.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.436699,
        'upper limit (fb)' : 2.922061,
        'expected upper limit (fb)' : 3.02197,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 422.6), ('chi', 180.1)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 1.518346,
        'r_expected' : 1.468148,
        'Width (GeV)' : [('zp', 2.22984), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4.436699221897403},
        'nll' : 93.52512,
        'nll_min' : 89.10691,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 132.2026,
        'upper limit (fb)' : 111.8908,
        'expected upper limit (fb)' : 63.85504,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 422.6), ('chi', 180.1)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 1.181532,
        'r_expected' : 2.070355,
        'Width (GeV)' : [('zp', 2.22984), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 132.2026126612059},
        'nll' : 636.62,
        'nll_min' : 633.6481,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4925.2,
        'upper limit (fb)' : 10462.8,
        'expected upper limit (fb)' : 7009.59,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 422.6)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.4707344,
        'r_expected' : 0.7026374,
        'Width (GeV)' : [('zp', 2.22984)],
        'TxNames weights (fb)' : {'TRV1bb': 4925.2001715}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.669544,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 422.6), ('chi', 180.1)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.4542361,
        'r_expected' : 0.4404895,
        'Width (GeV)' : [('zp', 2.22984), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.669544029200053},
        'nll' : 11.31106,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9282.347,
        'upper limit (fb)' : 779281.0,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 422.6), ('chi', 180.1)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.01191142,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 2.22984), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 9282.3468056}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 1.68742,
        'r_expected' : 2.56343,
        'nll' : 730.1452,
        'nll_min' : 723.2575,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 645.08,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 465.9319,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 178.9988,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1492697,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 645.08,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 465.9319,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 178.9988,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1492697,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 51712.17,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 43333.92,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8378.248,
        'SMS' : 'PV > (t,t)'
    }
]
}