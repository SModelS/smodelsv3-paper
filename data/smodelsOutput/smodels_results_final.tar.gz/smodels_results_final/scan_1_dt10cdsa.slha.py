smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_dt10cdsa.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.75977,
        'upper limit (fb)' : 2.875431,
        'expected upper limit (fb)' : 3.004222,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 431.8), ('chi', 186.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 4.089743,
        'r_expected' : 3.914415,
        'Width (GeV)' : [('zp', 13.17253), ('chi', 'stable')],
        'nll' : 119.3705,
        'nll_min' : 89.10691,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 23016.45,
        'upper limit (fb)' : 6872.8,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 431.8), ('chi', 186.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 3.348919,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 13.17253), ('chi', 'stable')]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 339.1867,
        'upper limit (fb)' : 110.6602,
        'expected upper limit (fb)' : 62.43557,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 431.8), ('chi', 186.7)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 3.065118,
        'r_expected' : 5.432587,
        'Width (GeV)' : [('zp', 13.17253), ('chi', 'stable')],
        'nll' : 673.5265,
        'nll_min' : 633.5752,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.746115,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 431.8), ('chi', 186.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.18461,
        'r_expected' : 1.14876,
        'Width (GeV)' : [('zp', 13.17253), ('chi', 'stable')],
        'nll' : 13.2515,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 4.440254,
        'r_expected' : 6.786026,
        'nll' : 999.0,
        'nll_min' : 723.2446,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 621.66,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 446.4607,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 175.0667,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1326205,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 621.66,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 446.4607,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 175.0667,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1326205,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 394713.5,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 272397.4,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 68099.35,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 54216.8,
        'SMS' : 'PV > (t,t)'
    }
]
}