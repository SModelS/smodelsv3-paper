smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_n04ivt0y.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 183.9274,
        'upper limit (fb)' : 88.3424,
        'expected upper limit (fb)' : 97.6314,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1584.8)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 2.081984,
        'r_expected' : 1.883896,
        'Width (GeV)' : [('zp', 11.876)],
        'TxNames weights (fb)' : {'TRV1jj': 183.92742873}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.692556,
        'upper limit (fb)' : 2.732014,
        'expected upper limit (fb)' : 2.282633,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1584.8), ('chi', 443.2)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2534965,
        'r_expected' : 0.3034022,
        'Width (GeV)' : [('zp', 11.87604), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.6925559532558578},
        'nll' : 59.46215,
        'nll_min' : 59.46031,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 30.19933,
        'upper limit (fb)' : 119.787,
        'expected upper limit (fb)' : 178.535,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1584.8)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.2521086,
        'r_expected' : 0.1691508,
        'Width (GeV)' : [('zp', 11.876)],
        'TxNames weights (fb)' : {'TRV1qq': 30.1993323528}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 125.7283,
        'upper limit (fb)' : 574.09,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1584.8), ('chi', 443.2)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2190044,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.87604), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 125.72826242400001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 30.19933,
        'upper limit (fb)' : 146.83,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1584.8)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.2056755,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 11.876)],
        'TxNames weights (fb)' : {'TRV1qq': 30.1993323528}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.929183,
        'upper limit (fb)' : 35.23285,
        'expected upper limit (fb)' : 18.91373,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1584.8), ('chi', 443.2)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1966683,
        'r_expected' : 0.3663573,
        'Width (GeV)' : [('zp', 11.87604), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6.9291829707903325},
        'nll' : 633.8374,
        'nll_min' : 633.1505,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1156407,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1584.8), ('chi', 443.2)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1488489,
        'r_expected' : 0.1458821,
        'Width (GeV)' : [('zp', 11.87604), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.11564070674493522},
        'nll' : 9.279593,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.2672508,
        'r_expected' : 0.4508429,
        'nll' : 693.2995,
        'nll_min' : 692.9301,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 18.49,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.22869,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.415079,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.03873,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.807413,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.795974e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 18.49,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.22869,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.415079,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.03873,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.807413,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 8.795974e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 36.75434,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 36.75434,
        'SMS' : 'PV > (t,t)'
    }
]
}