smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_r6j_dwbf.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 14.52385,
        'upper limit (fb)' : 32.2703,
        'expected upper limit (fb)' : 20.941,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2622.7)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4500687,
        'r_expected' : 0.6935606,
        'Width (GeV)' : [('zp', 16.177)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.904446,
        'upper limit (fb)' : 7.28845,
        'expected upper limit (fb)' : 8.36667,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2622.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3984999,
        'r_expected' : 0.3471448,
        'Width (GeV)' : [('zp', 16.17683)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 14.52385,
        'upper limit (fb)' : 61.0053,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2622.7)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.2380753,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 16.177)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.90477,
        'upper limit (fb)' : 38.3203,
        'expected upper limit (fb)' : 19.1454,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2622.7)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.07580239,
        'r_expected' : 0.1517216,
        'Width (GeV)' : [('zp', 16.17683)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9689019,
        'upper limit (fb)' : 20.2668,
        'expected upper limit (fb)' : 25.4604,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2622.7)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.04780734,
        'r_expected' : 0.03805525,
        'Width (GeV)' : [('zp', 16.177)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04604246,
        'upper limit (fb)' : 2.192,
        'expected upper limit (fb)' : 1.894634,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2622.7), ('chi', 981.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.02100478,
        'r_expected' : 0.02430151,
        'Width (GeV)' : [('zp', 16.17683), ('chi', 'stable')],
        'nll' : 59.58604,
        'nll_min' : 59.51481,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3540375,
        'upper limit (fb)' : 27.88841,
        'expected upper limit (fb)' : 14.56481,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2622.7), ('chi', 981.3)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.01269479,
        'r_expected' : 0.02430773,
        'Width (GeV)' : [('zp', 16.17683), ('chi', 'stable')],
        'nll' : 634.8363,
        'nll_min' : 632.9559,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.009259412,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2622.7), ('chi', 981.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01191841,
        'r_expected' : 0.01168085,
        'Width (GeV)' : [('zp', 16.17683), ('chi', 'stable')],
        'nll' : 9.204385,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.01813339,
        'r_expected' : 0.03266535,
        'nll' : 694.4223,
        'nll_min' : 693.6651,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 0.89692,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4321,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2145903,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2092479,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04098022,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.622605e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.89692,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4321,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2145903,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2092479,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.04098022,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.622605e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}