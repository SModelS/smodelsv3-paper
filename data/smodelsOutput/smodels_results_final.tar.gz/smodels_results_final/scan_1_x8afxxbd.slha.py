smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_x8afxxbd.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 73.32462,
        'upper limit (fb)' : 39.568,
        'expected upper limit (fb)' : 66.5591,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1840.6)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.853129,
        'r_expected' : 1.101647,
        'Width (GeV)' : [('zp', 16.385)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 14.66492,
        'upper limit (fb)' : 33.2153,
        'expected upper limit (fb)' : 46.9362,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 1840.6)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.4415111,
        'r_expected' : 0.3124438,
        'Width (GeV)' : [('zp', 16.38492)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 73.32462,
        'upper limit (fb)' : 214.175,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1840.6)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.3423585,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 16.385)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 14.65814,
        'upper limit (fb)' : 43.834,
        'expected upper limit (fb)' : 24.6761,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 1840.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3344011,
        'r_expected' : 0.5940216,
        'Width (GeV)' : [('zp', 16.38492)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4709995,
        'upper limit (fb)' : 2.520847,
        'expected upper limit (fb)' : 2.144285,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1840.6), ('chi', 279.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1868418,
        'r_expected' : 0.2196534,
        'Width (GeV)' : [('zp', 16.38492), ('chi', 'stable')],
        'nll' : 59.49176,
        'nll_min' : 59.49073,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 76.06723,
        'upper limit (fb)' : 449.804,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1840.6), ('chi', 279.9)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.1691119,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 16.38492), ('chi', 'stable')]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.424879,
        'upper limit (fb)' : 30.93436,
        'expected upper limit (fb)' : 16.63382,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1430409,
        'r_expected' : 0.266017,
        'Width (GeV)' : None,
        'nll' : 634.0882,
        'nll_min' : 633.1623,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.08362603,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1840.6), ('chi', 279.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1076407,
        'r_expected' : 0.1054952,
        'Width (GeV)' : [('zp', 16.38492), ('chi', 'stable')],
        'nll' : 9.250353,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.872208,
        'upper limit (fb)' : 206.267,
        'expected upper limit (fb)' : 99.0779,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1840.6)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.0478613,
        'r_expected' : 0.09964086,
        'Width (GeV)' : [('zp', 16.385)]
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.1958795,
        'r_expected' : 0.328911,
        'nll' : 693.58,
        'nll_min' : 693.0029,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 7.909066,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.621229,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.868402,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.785874,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6335321,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.824857e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 7.909066,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.621229,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.868402,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.785874,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6335321,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.824857e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}