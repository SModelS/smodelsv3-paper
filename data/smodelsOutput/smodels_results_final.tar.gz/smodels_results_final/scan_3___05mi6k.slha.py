smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3___05mi6k.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.619956,
        'upper limit (fb)' : 19.7387,
        'expected upper limit (fb)' : 15.0941,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2914.1)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4873652,
        'r_expected' : 0.6373322,
        'Width (GeV)' : [('zp', 13.918)],
        'TxNames weights (fb)' : {'TRV1jj': 9.619955811}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.92385,
        'upper limit (fb)' : 7.13547,
        'expected upper limit (fb)' : 6.19311,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2914.1)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2696179,
        'r_expected' : 0.3106436,
        'Width (GeV)' : [('zp', 13.91757)],
        'TxNames weights (fb)' : {'TRV1tt': 1.9238502888}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 9.619956,
        'upper limit (fb)' : 50.6679,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2914.1)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1898629,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 13.918)],
        'TxNames weights (fb)' : {'TRV1jj': 9.619955811}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.923991,
        'upper limit (fb)' : 22.7549,
        'expected upper limit (fb)' : 15.2251,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2914.1)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.08455283,
        'r_expected' : 0.1263697,
        'Width (GeV)' : [('zp', 13.91757)],
        'TxNames weights (fb)' : {'TRV1bb': 1.9239911622}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4728416,
        'upper limit (fb)' : 11.1667,
        'expected upper limit (fb)' : 14.9677,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2914.1)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.0423439,
        'r_expected' : 0.0315908,
        'Width (GeV)' : [('zp', 13.918)],
        'TxNames weights (fb)' : {'TRV1qq': 0.47284161428000004}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.08867e-06,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2914.1), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 6.895593e-06,
        'r_expected' : 7.923843e-06,
        'Width (GeV)' : [('zp', 13.91757), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 7.088669909667118e-06},
        'nll' : 9.413538,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.020796e-06,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2914.1), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 6.462603e-06,
        'r_expected' : 6.333791e-06,
        'Width (GeV)' : [('zp', 13.91757), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 5.020796167397398e-06},
        'nll' : 9.200813,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.006951e-06,
        'upper limit (fb)' : 0.2868,
        'expected upper limit (fb)' : 0.311,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_14',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 3.510986e-06,
        'r_expected' : 3.237784e-06,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.0069438933890604e-06,
            'TRS1' : 6.939044371670368e-12
        },
        'nll' : 7.341177,
        'nll_min' : 7.341175,
        'nll_SM' : 7.341175
    }
],
'Total xsec for missing topologies (fb)' : 0.44394,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2187276,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1087649,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09936172,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01708504,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.62477e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.44394,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2187276,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1087649,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.09936172,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01708504,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.62477e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}