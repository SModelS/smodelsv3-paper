smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_21w4_qzp.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2347.89,
        'upper limit (fb)' : 110.8386,
        'expected upper limit (fb)' : 69.72388,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 369.6), ('chi', 120.1)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 21.18297,
        'r_expected' : 33.67412,
        'Width (GeV)' : [('zp', 14.46273), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2347.8899442663037},
        'nll' : 2685.431,
        'nll_min' : 634.1654,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 67.00892,
        'upper limit (fb)' : 3.607052,
        'expected upper limit (fb)' : 3.133362,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 369.6), ('chi', 120.1)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 18.5772,
        'r_expected' : 21.38563,
        'Width (GeV)' : [('zp', 14.46273), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 67.00891797741788},
        'nll' : 972.6596,
        'nll_min' : 89.0182,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 214284.6,
        'upper limit (fb)' : 13772.3,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 369.6), ('chi', 120.1)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 15.5591,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 14.46273), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 214284.58491499998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 10.59785,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 369.6), ('chi', 120.1)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 7.189858,
        'r_expected' : 6.972271,
        'Width (GeV)' : [('zp', 14.46273), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 10.597851287682662},
        'nll' : 73.48949,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 26.08948,
        'r_expected' : 38.44698,
        'nll' : 999.0,
        'nll_min' : 723.2319,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 826.49,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 702.0923,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 124.0142,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3835394,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 826.49,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 702.0923,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 124.0142,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3835394,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 505345.4,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 365901.3,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 91475.34,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 47968.76,
        'SMS' : 'PV > (t,t)'
    }
]
}