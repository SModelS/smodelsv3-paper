smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_u6c9mo2v.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.706002,
        'upper limit (fb)' : 19.4971,
        'expected upper limit (fb)' : 14.9657,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2920.5)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.446528,
        'r_expected' : 0.5817303,
        'Width (GeV)' : [('zp', 15.184)],
        'TxNames weights (fb)' : {'TRV1jj': 8.706001608000001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.741074,
        'upper limit (fb)' : 7.16382,
        'expected upper limit (fb)' : 6.15503,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2920.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2430371,
        'r_expected' : 0.2828701,
        'Width (GeV)' : [('zp', 15.18414)],
        'TxNames weights (fb)' : {'TRV1tt': 1.741074048}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.706002,
        'upper limit (fb)' : 51.1106,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2920.5)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1703365,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 15.184)],
        'TxNames weights (fb)' : {'TRV1jj': 8.706001608000001}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.7412,
        'upper limit (fb)' : 22.3777,
        'expected upper limit (fb)' : 15.1571,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2920.5)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.07780962,
        'r_expected' : 0.1148769,
        'Width (GeV)' : [('zp', 15.18414)],
        'TxNames weights (fb)' : {'TRV1bb': 1.7412003216}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.42499,
        'upper limit (fb)' : 11.1667,
        'expected upper limit (fb)' : 14.8399,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2920.5)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.03805869,
        'r_expected' : 0.02863833,
        'Width (GeV)' : [('zp', 15.184)],
        'TxNames weights (fb)' : {'TRV1qq': 0.42499001942399994}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.008809216,
        'upper limit (fb)' : 2.024703,
        'expected upper limit (fb)' : 1.793424,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2920.5), ('chi', 1306.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.004350869,
        'r_expected' : 0.004911954,
        'Width (GeV)' : [('zp', 15.18414), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.008809216323162858},
        'nll' : 59.60194,
        'nll_min' : 59.57621,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06915959,
        'upper limit (fb)' : 28.37746,
        'expected upper limit (fb)' : 15.22908,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2920.5), ('chi', 1306.7)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.002437132,
        'r_expected' : 0.004541286,
        'Width (GeV)' : [('zp', 15.18414), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.06915959203563299},
        'nll' : 634.9128,
        'nll_min' : 633.1666,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001862484,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2920.5), ('chi', 1306.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.002397328,
        'r_expected' : 0.002349545,
        'Width (GeV)' : [('zp', 15.18414), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.00186248402047656},
        'nll' : 9.201492,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.004024173,
        'r_expected' : 0.006414752,
        'nll' : 694.5148,
        'nll_min' : 693.3835,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 0.43645,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2126016,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1057212,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1015876,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01653898,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.410551e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.43645,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2126016,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1057212,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1015876,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01653898,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6.410551e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}