smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_f3ni0f48.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 79.35718,
        'upper limit (fb)' : 19015.5,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 263.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.004173289,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 2.360588), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 79.3571807072}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00493097,
        'upper limit (fb)' : 1.809,
        'expected upper limit (fb)' : 1.983,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 263.7), ('chi', 65.0)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_7',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.002725799,
        'r_expected' : 0.002486621,
        'Width (GeV)' : [('zp', 2.360588), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.004930969523294863},
        'nll' : 11.89763,
        'nll_min' : 11.89441,
        'nll_SM' : 11.89441
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001611427,
        'upper limit (fb)' : 0.7214,
        'expected upper limit (fb)' : 0.8238,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 263.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-SSd-2-1000-16',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.00223375,
        'r_expected' : 0.00195609,
        'Width (GeV)' : [('zp', 2.360588), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0016114269114404032},
        'nll' : 9.462999,
        'nll_min' : 9.461167,
        'nll_SM' : 9.461167
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001347953,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 263.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0009144865,
        'r_expected' : 0.0008868113,
        'Width (GeV)' : [('zp', 2.360588), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0013479531357744284},
        'nll' : 10.69778,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'Total xsec for missing topologies (fb)' : 1542.605,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1542.605,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1542.605,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1542.605,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 813505.3,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 650784.5,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 162696.1,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 24.69457,
        'SMS' : 'PV > (MET,MET)'
    }
]
}