smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_42hpqwje.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 22.26578,
        'upper limit (fb)' : 35.5399,
        'expected upper limit (fb)' : 22.4459,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2547.7)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.626501,
        'r_expected' : 0.9919755,
        'Width (GeV)' : [('zp', 12.259)],
        'TxNames weights (fb)' : {'TRV1jj': 22.265782549999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.452599,
        'upper limit (fb)' : 7.94333,
        'expected upper limit (fb)' : 9.06714,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2547.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5605457,
        'r_expected' : 0.4910699,
        'Width (GeV)' : [('zp', 12.25888)],
        'TxNames weights (fb)' : {'TRV1tt': 4.4525991417999995}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 22.26578,
        'upper limit (fb)' : 52.0516,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2547.7)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.4277637,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 12.259)],
        'TxNames weights (fb)' : {'TRV1jj': 22.265782549999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.453157,
        'upper limit (fb)' : 35.4061,
        'expected upper limit (fb)' : 20.4153,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2547.7)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.1257737,
        'r_expected' : 0.2181284,
        'Width (GeV)' : [('zp', 12.25888)],
        'TxNames weights (fb)' : {'TRV1bb': 4.4531565099999995}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.600133,
        'upper limit (fb)' : 27.7683,
        'expected upper limit (fb)' : 29.4594,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2547.7)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.05762445,
        'r_expected' : 0.05431655,
        'Width (GeV)' : [('zp', 12.259)],
        'TxNames weights (fb)' : {'TRV1qq': 1.600132952}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001887991,
        'upper limit (fb)' : 2.159074,
        'expected upper limit (fb)' : 1.897042,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2547.7), ('chi', 1248.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.0008744447,
        'r_expected' : 0.0009952287,
        'Width (GeV)' : [('zp', 12.25888), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0018879907761668359},
        'nll' : 59.60454,
        'nll_min' : 59.59814,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.0003771415,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2547.7), ('chi', 1248.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0004854441,
        'r_expected' : 0.0004757683,
        'Width (GeV)' : [('zp', 12.25888), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.0003771415323283075},
        'nll' : 9.200948,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'r' : 0.0008744447,
        'r_expected' : 0.0009952287,
        'nll' : 59.60454,
        'nll_min' : 59.59814,
        'nll_SM' : 59.60527
    }
],
'Total xsec for missing topologies (fb)' : 1.085,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5209866,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2586286,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2533008,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05208186,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.075889e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.085,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.5209866,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2586286,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2533008,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05208186,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.075889e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}