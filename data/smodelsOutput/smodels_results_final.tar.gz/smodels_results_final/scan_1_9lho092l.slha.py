smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_9lho092l.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 209.7697,
        'upper limit (fb)' : 247.575,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1839.7)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.8472977,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 29.055)],
        'TxNames weights (fb)' : {'TRV1jj': 209.76973866000003}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.7976405,
        'upper limit (fb)' : 2.477697,
        'expected upper limit (fb)' : 2.090906,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1839.7), ('chi', 752.4)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3219281,
        'r_expected' : 0.3814808,
        'Width (GeV)' : [('zp', 29.05534), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.7976405062129899},
        'nll' : 59.50914,
        'nll_min' : 59.47838,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 118.3657,
        'upper limit (fb)' : 475.368,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1839.7), ('chi', 752.4)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2489981,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 29.05534), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 118.36574228299999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.016411,
        'upper limit (fb)' : 29.02726,
        'expected upper limit (fb)' : 16.01243,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1839.7), ('chi', 752.4)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.241718,
        'r_expected' : 0.4381852,
        'Width (GeV)' : [('zp', 29.05534), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 7.016411368369242},
        'nll' : 633.7799,
        'nll_min' : 633.3573,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1449033,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1839.7), ('chi', 752.4)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1865148,
        'r_expected' : 0.1827972,
        'Width (GeV)' : [('zp', 29.05534), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.1449033417028486},
        'nll' : 9.311289,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.3374561,
        'r_expected' : 0.5517976,
        'nll' : 693.2891,
        'nll_min' : 693.1505,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 8.0002,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.569054,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.046098,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.760119,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6249012,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.787047e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 8.0002,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.569054,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.046098,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.760119,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6249012,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.787047e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 41.93448,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41.93448,
        'SMS' : 'PV > (t,t)'
    }
]
}