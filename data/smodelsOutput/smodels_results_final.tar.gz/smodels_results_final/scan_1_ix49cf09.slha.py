smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_ix49cf09.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 42.51954,
        'upper limit (fb)' : 33.3111,
        'expected upper limit (fb)' : 44.9981,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2046.2)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.276438,
        'r_expected' : 0.9449186,
        'Width (GeV)' : [('zp', 17.987)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.501337,
        'upper limit (fb)' : 13.9912,
        'expected upper limit (fb)' : 17.5232,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2046.2)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6076203,
        'r_expected' : 0.4851475,
        'Width (GeV)' : [('zp', 17.98657)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.503908,
        'upper limit (fb)' : 24.0189,
        'expected upper limit (fb)' : 33.527,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2046.2)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.3540507,
        'r_expected' : 0.2536436,
        'Width (GeV)' : [('zp', 17.98657)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 42.51954,
        'upper limit (fb)' : 170.398,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2046.2)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.2495307,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 17.987)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3012473,
        'upper limit (fb)' : 2.373624,
        'expected upper limit (fb)' : 2.043832,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2046.2), ('chi', 337.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1269145,
        'r_expected' : 0.1473934,
        'Width (GeV)' : [('zp', 17.98657), ('chi', 'stable')],
        'nll' : 59.519,
        'nll_min' : 59.50757,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 42.91612,
        'upper limit (fb)' : 376.695,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2046.2), ('chi', 337.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.113928,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 17.98657), ('chi', 'stable')]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.636948,
        'upper limit (fb)' : 29.93601,
        'expected upper limit (fb)' : 15.95173,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.08808616,
        'r_expected' : 0.165308,
        'Width (GeV)' : None,
        'nll' : 634.3658,
        'nll_min' : 633.1074,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.05594074,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2046.2), ('chi', 337.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.07200507,
        'r_expected' : 0.07056987,
        'Width (GeV)' : [('zp', 17.98657), ('chi', 'stable')],
        'nll' : 9.229652,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.83708,
        'upper limit (fb)' : 80.75,
        'expected upper limit (fb)' : 70.2625,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2046.2)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.05990192,
        'r_expected' : 0.06884299,
        'Width (GeV)' : [('zp', 17.987)]
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.1266842,
        'r_expected' : 0.2114827,
        'nll' : 693.8848,
        'nll_min' : 693.0807,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 4.247054,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.97927,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9982925,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9786762,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2908025,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.238635e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 4.247054,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.97927,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9982925,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9786762,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2908025,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.238635e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}