smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_ixs1cq5i.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 101.6776,
        'upper limit (fb)' : 43.6287,
        'expected upper limit (fb)' : 70.7742,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1805.9)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 2.330521,
        'r_expected' : 1.436648,
        'Width (GeV)' : [('zp', 12.787)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 20.33552,
        'upper limit (fb)' : 39.5935,
        'expected upper limit (fb)' : 50.6231,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 1805.9)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.5136076,
        'r_expected' : 0.4017044,
        'Width (GeV)' : [('zp', 12.78737)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 20.32535,
        'upper limit (fb)' : 43.062,
        'expected upper limit (fb)' : 26.1973,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 1805.9)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4720021,
        'r_expected' : 0.7758568,
        'Width (GeV)' : [('zp', 12.78737)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 101.6776,
        'upper limit (fb)' : 217.646,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1805.9)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.4671697,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 12.787)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.3689081,
        'upper limit (fb)' : 2.452706,
        'expected upper limit (fb)' : 2.097997,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1805.9), ('chi', 559.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.1504086,
        'r_expected' : 0.1758382,
        'Width (GeV)' : [('zp', 12.78737), ('chi', 'stable')],
        'nll' : 59.50477,
        'nll_min' : 59.49803,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 58.94701,
        'upper limit (fb)' : 475.493,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1805.9), ('chi', 559.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.1239703,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 12.78737), ('chi', 'stable')]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.501927,
        'upper limit (fb)' : 31.80987,
        'expected upper limit (fb)' : 17.0599,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1805.9), ('chi', 559.7)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1100893,
        'r_expected' : 0.2052724,
        'Width (GeV)' : [('zp', 12.78737), ('chi', 'stable')],
        'nll' : 634.2546,
        'nll_min' : 633.1519,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06701627,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1805.9), ('chi', 559.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.08626113,
        'r_expected' : 0.08454178,
        'Width (GeV)' : [('zp', 12.78737), ('chi', 'stable')],
        'nll' : 9.237423,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 14.07247,
        'upper limit (fb)' : 229.4,
        'expected upper limit (fb)' : 105.236,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 1805.9)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.0613447,
        'r_expected' : 0.133723,
        'Width (GeV)' : [('zp', 12.787)]
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.1544059,
        'r_expected' : 0.2578705,
        'nll' : 693.7594,
        'nll_min' : 693.0409,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 8.8707,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.047711,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.097853,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.995137,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7299663,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.285871e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 8.8707,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 4.047711,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.097853,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.995137,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7299663,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3.285871e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}