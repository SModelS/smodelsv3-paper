smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_i8nhzggq.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 19.36549,
        'upper limit (fb)' : 37.625,
        'expected upper limit (fb)' : 24.0883,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2485.6)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.5146973,
        'r_expected' : 0.8039374,
        'Width (GeV)' : [('zp', 15.909)],
        'TxNames weights (fb)' : {'TRV1jj': 19.36548504}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 19.36549,
        'upper limit (fb)' : 42.5205,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2485.6)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.4554388,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 15.909)],
        'TxNames weights (fb)' : {'TRV1jj': 19.36548504}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.872561,
        'upper limit (fb)' : 8.68786,
        'expected upper limit (fb)' : 9.70751,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2485.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.445744,
        'r_expected' : 0.3989243,
        'Width (GeV)' : [('zp', 15.90936)],
        'TxNames weights (fb)' : {'TRV1tt': 3.8725611935999997}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.873097,
        'upper limit (fb)' : 30.6353,
        'expected upper limit (fb)' : 21.538,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2485.6)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.126426,
        'r_expected' : 0.1798262,
        'Width (GeV)' : [('zp', 15.90936)],
        'TxNames weights (fb)' : {'TRV1bb': 3.873097008}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.479167,
        'upper limit (fb)' : 34.0533,
        'expected upper limit (fb)' : 32.0097,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2485.6)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.04343682,
        'r_expected' : 0.04620996,
        'Width (GeV)' : [('zp', 15.909)],
        'TxNames weights (fb)' : {'TRV1qq': 1.4791669788}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.06902795,
        'upper limit (fb)' : 2.231349,
        'expected upper limit (fb)' : 1.932433,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2485.6), ('chi', 889.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.03093552,
        'r_expected' : 0.03572075,
        'Width (GeV)' : [('zp', 15.90936), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.06902794546758703},
        'nll' : 59.57819,
        'nll_min' : 59.51724,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.5370291,
        'upper limit (fb)' : 27.57053,
        'expected upper limit (fb)' : 14.51029,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2485.6), ('chi', 889.6)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.01947838,
        'r_expected' : 0.03701022,
        'Width (GeV)' : [('zp', 15.90936), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.5370291157253646},
        'nll' : 634.7907,
        'nll_min' : 633.0144,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01395207,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2485.6), ('chi', 889.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.01795865,
        'r_expected' : 0.0176007,
        'Width (GeV)' : [('zp', 15.90936), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.013952074055558492},
        'nll' : 9.206377,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.02935094,
        'r_expected' : 0.04903422,
        'nll' : 694.3688,
        'nll_min' : 693.15,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 1.266,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6061216,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3007821,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2957386,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06335516,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.540377e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.266,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.6061216,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.3007821,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2957386,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.06335516,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.540377e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}