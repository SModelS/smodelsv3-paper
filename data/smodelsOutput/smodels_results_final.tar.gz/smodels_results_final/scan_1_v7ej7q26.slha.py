smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_v7ej7q26.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 731.7949,
        'upper limit (fb)' : 79.78207,
        'expected upper limit (fb)' : 47.32352,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 9.172423,
        'r_expected' : 15.46366,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 730.8615144573616,
            'TRS1' : 0.9333653876112635
        },
        'nll' : 1039.39,
        'nll_min' : 633.849,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 30.72146,
        'upper limit (fb)' : 3.595503,
        'expected upper limit (fb)' : 3.121374,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 597.1), ('chi', 131.5)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 8.544411,
        'r_expected' : 9.842286,
        'Width (GeV)' : [('zp', 23.41049), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 30.721455527829505},
        'nll' : 231.4564,
        'nll_min' : 59.50772,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 31705.15,
        'upper limit (fb)' : 4833.92,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 597.1), ('chi', 131.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 6.55889,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 23.41049), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 31705.148992000002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.636922,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 597.1), ('chi', 131.5)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 3.824235,
        'r_expected' : 3.708501,
        'Width (GeV)' : [('zp', 23.41049), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 5.636921849585664},
        'nll' : 30.03202,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 11.31378,
        'r_expected' : 17.65769,
        'nll' : 999.0,
        'nll_min' : 693.4486,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 333.9309,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 137.6541,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 135.4417,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 60.82016,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01488078,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 333.9309,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 137.6541,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 135.4417,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 60.82016,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.01488078,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 97814.83,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 65724.46,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 16431.11,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 15659.25,
        'SMS' : 'PV > (t,t)'
    }
]
}