smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_5yqwjh_5.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 179.5117,
        'upper limit (fb)' : 242.231,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 1905.5)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.7410766,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 29.304)],
        'TxNames weights (fb)' : {'TRV1jj': 179.51173646999996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.6471444,
        'upper limit (fb)' : 2.412383,
        'expected upper limit (fb)' : 2.035549,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1905.5), ('chi', 789.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.2682594,
        'r_expected' : 0.3179214,
        'Width (GeV)' : [('zp', 29.30368), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.6471443991421122},
        'nll' : 59.48696,
        'nll_min' : 59.47923,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 92.97035,
        'upper limit (fb)' : 442.336,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1905.5), ('chi', 789.9)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2101804,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 29.30368), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 92.970347952}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 5.698767,
        'upper limit (fb)' : 29.74329,
        'expected upper limit (fb)' : 15.45322,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1905.5), ('chi', 789.9)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.1915984,
        'r_expected' : 0.3687753,
        'Width (GeV)' : [('zp', 29.30368), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 5.698767150681007},
        'nll' : 633.7456,
        'nll_min' : 632.9167,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1194762,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 1905.5), ('chi', 789.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.1537858,
        'r_expected' : 0.1507206,
        'Width (GeV)' : [('zp', 29.30368), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.1194761941531152},
        'nll' : 9.283477,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.2692595,
        'r_expected' : 0.4625326,
        'nll' : 693.2326,
        'nll_min' : 692.8371,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 6.5249,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.93142,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.661562,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.447013,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4848835,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.127272e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 6.5249,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.93142,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.661562,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.447013,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4848835,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 2.127272e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 35.88788,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 35.88788,
        'SMS' : 'PV > (t,t)'
    }
]
}