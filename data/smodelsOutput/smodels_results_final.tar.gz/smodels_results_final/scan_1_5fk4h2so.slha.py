smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_5fk4h2so.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1703.074,
        'upper limit (fb)' : 88.48675,
        'expected upper limit (fb)' : 54.30746,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 19.24666,
        'r_expected' : 31.35986,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1699.759143861826,
            'TRS1' : 3.315309307555946
        },
        'nll' : 2379.602,
        'nll_min' : 634.0369,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 62.88709,
        'upper limit (fb)' : 3.76467,
        'expected upper limit (fb)' : 3.324919,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 509.4), ('chi', 109.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 16.70455,
        'r_expected' : 18.91387,
        'Width (GeV)' : [('zp', 24.88557), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 62.887093913501985},
        'nll' : 713.246,
        'nll_min' : 59.53023,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 92523.56,
        'upper limit (fb)' : 5964.4,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 509.4), ('chi', 109.9)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 15.51263,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 24.88557), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 92523.556125}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.06415,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 509.4), ('chi', 109.9)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 7.506209,
        'r_expected' : 7.279047,
        'Width (GeV)' : [('zp', 24.88557), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 11.06415188853975},
        'nll' : 78.83826,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 23.51171,
        'r_expected' : 35.46314,
        'nll' : 999.0,
        'nll_min' : 693.6349,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 296.0039,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 146.2067,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 87.76057,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 62.01138,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02525948,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 296.0039,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 146.2067,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 87.76057,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 62.01138,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02525948,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 139526.4,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 94502.36,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 23625.59,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 21398.43,
        'SMS' : 'PV > (t,t)'
    }
]
}