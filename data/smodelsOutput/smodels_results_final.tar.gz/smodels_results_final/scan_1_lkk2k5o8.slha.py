smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_lkk2k5o8.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.72874,
        'upper limit (fb)' : 34.5023,
        'expected upper limit (fb)' : 21.9684,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2571.5)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3399409,
        'r_expected' : 0.5338915,
        'Width (GeV)' : [('zp', 22.147)],
        'TxNames weights (fb)' : {'TRV1jj': 11.72874195665}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.345465,
        'upper limit (fb)' : 7.73551,
        'expected upper limit (fb)' : 8.84486,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2571.5)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3032075,
        'r_expected' : 0.2651783,
        'Width (GeV)' : [('zp', 22.14661)],
        'TxNames weights (fb)' : {'TRV1tt': 2.34546481854}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 11.72874,
        'upper limit (fb)' : 56.0281,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2571.5)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.2093368,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 22.147)],
        'TxNames weights (fb)' : {'TRV1jj': 11.72874195665}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.345748,
        'upper limit (fb)' : 36.8277,
        'expected upper limit (fb)' : 19.9988,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2571.5)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.06369522,
        'r_expected' : 0.1172945,
        'Width (GeV)' : [('zp', 22.14661)],
        'TxNames weights (fb)' : {'TRV1bb': 2.34574839133}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.09425623,
        'upper limit (fb)' : 2.153806,
        'expected upper limit (fb)' : 1.883583,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2571.5), ('chi', 473.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.04376265,
        'r_expected' : 0.05004091,
        'Width (GeV)' : [('zp', 22.14661), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.09425623002967003},
        'nll' : 59.57176,
        'nll_min' : 59.52962,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.823576,
        'upper limit (fb)' : 24.9917,
        'expected upper limit (fb)' : 28.1956,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2571.5)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.03295398,
        'r_expected' : 0.02920938,
        'Width (GeV)' : [('zp', 22.147)],
        'TxNames weights (fb)' : {'TRV1qq': 0.8235760255879999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.7482084,
        'upper limit (fb)' : 27.73024,
        'expected upper limit (fb)' : 14.64143,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.02698168,
        'r_expected' : 0.05110215,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 0.7476815170794678,
            'TRS1' : 0.00052688258909567
        },
        'nll' : 634.7405,
        'nll_min' : 633.0406,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.01940924,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2571.5), ('chi', 473.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.02498294,
        'r_expected' : 0.02448498,
        'Width (GeV)' : [('zp', 22.14661), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.019409244901187606},
        'nll' : 9.208849,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.04147248,
        'r_expected' : 0.06852424,
        'nll' : 694.3122,
        'nll_min' : 693.1808,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 1.017637,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4891651,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2428639,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.237521,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0480848,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.912423e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 1.017637,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.4891651,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2428639,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.237521,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.0480848,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.912423e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}