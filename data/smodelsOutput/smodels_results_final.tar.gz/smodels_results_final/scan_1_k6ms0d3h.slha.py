smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_k6ms0d3h.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.918865,
        'upper limit (fb)' : 22.0834,
        'expected upper limit (fb)' : 16.3401,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2852.0)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.4038719,
        'r_expected' : 0.5458268,
        'Width (GeV)' : [('zp', 16.87)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.783631,
        'upper limit (fb)' : 6.96678,
        'expected upper limit (fb)' : 6.56528,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2852.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.2560194,
        'r_expected' : 0.2716763,
        'Width (GeV)' : [('zp', 16.86978)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.918865,
        'upper limit (fb)' : 53.9625,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2852.0)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.1652789,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 16.87)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.783773,
        'upper limit (fb)' : 25.5415,
        'expected upper limit (fb)' : 15.9448,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2852.0)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.06983823,
        'r_expected' : 0.1118718,
        'Width (GeV)' : [('zp', 16.86978)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.46846,
        'upper limit (fb)' : 11.7267,
        'expected upper limit (fb)' : 16.2078,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2852.0)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.03994816,
        'r_expected' : 0.02890337,
        'Width (GeV)' : [('zp', 16.87)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.02388468,
        'upper limit (fb)' : 2.079368,
        'expected upper limit (fb)' : 1.82059,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2852.0), ('chi', 1118.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.01148651,
        'r_expected' : 0.01311919,
        'Width (GeV)' : [('zp', 16.86978), ('chi', 'stable')],
        'nll' : 59.59568,
        'nll_min' : 59.53952,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1881886,
        'upper limit (fb)' : 28.36306,
        'expected upper limit (fb)' : 15.00637,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2852.0), ('chi', 1118.3)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.006634989,
        'r_expected' : 0.01254059,
        'Width (GeV)' : [('zp', 16.86978), ('chi', 'stable')],
        'nll' : 634.8824,
        'nll_min' : 633.0581,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.004947522,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2852.0), ('chi', 1118.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.006368287,
        'r_expected' : 0.006241355,
        'Width (GeV)' : [('zp', 16.86978), ('chi', 'stable')],
        'nll' : 9.202661,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.01064857,
        'r_expected' : 0.01736169,
        'nll' : 694.478,
        'nll_min' : 693.2645,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 0.51556,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2505643,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1245659,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1200587,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02037033,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.929555e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.51556,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2505643,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1245659,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1200587,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02037033,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 7.929555e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}