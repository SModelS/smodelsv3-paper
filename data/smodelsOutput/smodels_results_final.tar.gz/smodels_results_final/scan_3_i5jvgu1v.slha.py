smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_i5jvgu1v.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 12.40841,
        'upper limit (fb)' : 24.1071,
        'expected upper limit (fb)' : 17.3494,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2801.7)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.51472,
        'r_expected' : 0.7152067,
        'Width (GeV)' : [('zp', 13.381)],
        'TxNames weights (fb)' : {'TRV1jj': 12.408407362999998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.481468,
        'upper limit (fb)' : 6.97673,
        'expected upper limit (fb)' : 6.87046,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2801.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3556779,
        'r_expected' : 0.3611794,
        'Width (GeV)' : [('zp', 13.38084)],
        'TxNames weights (fb)' : {'TRV1tt': 2.4814684883999996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 12.40841,
        'upper limit (fb)' : 58.4371,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2801.7)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.2123378,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 13.381)],
        'TxNames weights (fb)' : {'TRV1jj': 12.408407362999998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.481681,
        'upper limit (fb)' : 27.5907,
        'expected upper limit (fb)' : 16.5418,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2801.7)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.0899463,
        'r_expected' : 0.1500249,
        'Width (GeV)' : [('zp', 13.38084)],
        'TxNames weights (fb)' : {'TRV1bb': 2.4816814725999996}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.6878193,
        'upper limit (fb)' : 12.3135,
        'expected upper limit (fb)' : 17.8725,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2801.7)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.05585896,
        'r_expected' : 0.03848479,
        'Width (GeV)' : [('zp', 13.381)],
        'TxNames weights (fb)' : {'TRV1qq': 0.6878193311999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.310308e-06,
        'upper limit (fb)' : 0.3867,
        'expected upper limit (fb)' : 0.3313,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2801.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-2200-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 8.560404e-06,
        'r_expected' : 9.991876e-06,
        'Width (GeV)' : [('zp', 13.38084), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 3.3103084015910695e-06},
        'nll' : 7.251123,
        'nll_min' : 7.109128,
        'nll_SM' : 7.251134
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.404047e-06,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2801.7), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 8.243077e-06,
        'r_expected' : 8.078777e-06,
        'Width (GeV)' : [('zp', 13.38084), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6.404046865160669e-06},
        'nll' : 9.200814,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.278734e-06,
        'upper limit (fb)' : 0.2868,
        'expected upper limit (fb)' : 0.311,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_14',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 4.458627e-06,
        'r_expected' : 4.111685e-06,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 1.27872324341784e-06,
            'TRS1' : 1.0841875050458631e-11
        },
        'nll' : 7.341177,
        'nll_min' : 7.341175,
        'nll_SM' : 7.341175
    }
],
'Total xsec for missing topologies (fb)' : 0.5820399,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2858001,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1420536,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1301738,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02401146,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.378376e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 0.5820399,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2858001,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1420536,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1301738,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.02401146,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.378376e-07,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}