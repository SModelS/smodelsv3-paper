smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 30,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_jxw3p3es.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.759359,
        'upper limit (fb)' : 3.279749,
        'expected upper limit (fb)' : 2.761322,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 938.8), ('chi', 165.2)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 1.146234,
        'r_expected' : 1.361434,
        'Width (GeV)' : [('zp', 8.153524), ('chi', 'stable')],
        'nll' : 61.78955,
        'nll_min' : 59.46835,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 59.33615,
        'upper limit (fb)' : 53.53975,
        'expected upper limit (fb)' : 30.25764,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 1.108263,
        'r_expected' : 1.96103,
        'Width (GeV)' : None,
        'nll' : 635.7923,
        'nll_min' : 633.5145,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1602.591,
        'upper limit (fb)' : 1736.69,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 938.8), ('chi', 165.2)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.9227846,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 8.153524), ('chi', 'stable')]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 422.3365,
        'upper limit (fb)' : 468.222,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 938.8)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.9020006,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 8.1535)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4694678,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 938.8), ('chi', 165.2)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.6042834,
        'r_expected' : 0.5922389,
        'Width (GeV)' : [('zp', 8.153524), ('chi', 'stable')],
        'nll' : 9.980247,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 105.5841,
        'upper limit (fb)' : 598.159,
        'expected upper limit (fb)' : 696.641,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 938.8)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.1765152,
        'r_expected' : 0.1515618,
        'Width (GeV)' : [('zp', 8.153524)]
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.863709,
        'upper limit (fb)' : 7194.4,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRS1'],
        'Mass (GeV)' : [('sd', 469.4), ('chi', 165.2)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.0009540349,
        'r_expected' : None,
        'Width (GeV)' : [('sd', 4.511808), ('chi', 'stable')]
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 1.387561,
        'r_expected' : 2.277882,
        'nll' : 697.5818,
        'nll_min' : 693.1291,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 214.4563,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 87.52281,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 58.99716,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41.52658,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 26.40677,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.00298228,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 214.4563,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 87.52281,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 58.99716,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41.52658,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 26.40677,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.00298228,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 323.3781,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 323.3781,
        'SMS' : 'PV > (t,t)'
    }
]
}