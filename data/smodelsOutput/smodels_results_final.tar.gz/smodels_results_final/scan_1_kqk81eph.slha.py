smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_kqk81eph.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 442.5435,
        'upper limit (fb)' : 114.3813,
        'expected upper limit (fb)' : 72.0881,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 358.7), ('chi', 115.3)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 3.869021,
        'r_expected' : 6.138926,
        'Width (GeV)' : [('zp', 2.314019), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 442.543512245107},
        'nll' : 691.9928,
        'nll_min' : 634.1848,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 12.03461,
        'upper limit (fb)' : 3.537526,
        'expected upper limit (fb)' : 3.136368,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 358.7), ('chi', 115.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 3.401985,
        'r_expected' : 3.837117,
        'Width (GeV)' : [('zp', 2.314019), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 12.034611781412933},
        'nll' : 114.65,
        'nll_min' : 89.04262,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 42527.23,
        'upper limit (fb)' : 14626.7,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 358.7), ('chi', 115.3)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 2.907507,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 2.314019), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 42527.229282}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.913883,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 358.7), ('chi', 115.3)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.298428,
        'r_expected' : 1.259133,
        'Width (GeV)' : [('zp', 2.314019), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.9138826684383432},
        'nll' : 13.65962,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7483.717,
        'upper limit (fb)' : 10620.6,
        'expected upper limit (fb)' : 10849.8,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 358.7)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.7046417,
        'r_expected' : 0.6897562,
        'Width (GeV)' : [('zp', 2.314019)],
        'TxNames weights (fb)' : {'TRV1bb': 7483.7172523}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 4.803413,
        'r_expected' : 7.015531,
        'nll' : 999.0,
        'nll_min' : 723.2871,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 877.55,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 876.9932,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.556809,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 877.55,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 876.9932,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.556809,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 69667.08,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 63142.82,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 6524.26,
        'SMS' : 'PV > (t,t)'
    }
]
}