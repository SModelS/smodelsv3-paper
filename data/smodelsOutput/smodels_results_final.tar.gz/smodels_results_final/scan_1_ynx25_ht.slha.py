smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_ynx25_ht.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 353.4143,
        'upper limit (fb)' : 91.2991,
        'expected upper limit (fb)' : 56.40401,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 3.87095,
        'r_expected' : 6.265765,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 351.3937927731442,
            'TRS1' : 2.0204914170067187
        },
        'nll' : 693.3999,
        'nll_min' : 634.0713,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 12.54947,
        'upper limit (fb)' : 3.472689,
        'expected upper limit (fb)' : 3.371105,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 489.3), ('chi', 68.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 3.613762,
        'r_expected' : 3.722658,
        'Width (GeV)' : [('zp', 4.358771), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 12.549471348100727},
        'nll' : 115.1698,
        'nll_min' : 89.10197,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 20383.11,
        'upper limit (fb)' : 7085.26,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 489.3), ('chi', 68.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 2.876833,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 4.358771), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 20383.1071486}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2.138861,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 489.3), ('chi', 68.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 1.451059,
        'r_expected' : 1.407145,
        'Width (GeV)' : [('zp', 4.358771), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2.138860582424044},
        'nll' : 14.25162,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1673.781,
        'upper limit (fb)' : 3587.55,
        'expected upper limit (fb)' : 3606.98,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 489.3)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.4665526,
        'r_expected' : 0.4640394,
        'Width (GeV)' : [('zp', 4.358771)],
        'TxNames weights (fb)' : {'TRV1bb': 1673.78093472}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 4.939182,
        'r_expected' : 7.227332,
        'nll' : 999.0,
        'nll_min' : 723.3466,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 381.0084,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 268.5402,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 112.4156,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05263077,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 381.0084,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 268.5402,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 112.4156,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.05263077,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 18770.02,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 15363.48,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 3406.542,
        'SMS' : 'PV > (t,t)'
    }
]
}