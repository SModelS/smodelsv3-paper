smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_5o4w6vv3.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.9439829,
        'upper limit (fb)' : 2.367311,
        'expected upper limit (fb)' : 2.014165,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2069.0), ('chi', 113.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.3987574,
        'r_expected' : 0.4686721,
        'Width (GeV)' : [('zp', 76.11434), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.9439828693694238},
        'nll' : 59.5889,
        'nll_min' : 59.49032,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 141.0387,
        'upper limit (fb)' : 360.621,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2069.0), ('chi', 113.8)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.3910995,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 76.11434), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 141.038707821}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 8.861577,
        'upper limit (fb)' : 28.90916,
        'expected upper limit (fb)' : 15.56379,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.3065318,
        'r_expected' : 0.5693714,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 8.858281504908843,
            'TRS1' : 0.0032953514278891123
        },
        'nll' : 633.4687,
        'nll_min' : 633.178,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.1814096,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2069.0), ('chi', 113.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.2335045,
        'r_expected' : 0.2288503,
        'Width (GeV)' : [('zp', 76.11434), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.18140962754768303},
        'nll' : 9.357483,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 48.47842,
        'upper limit (fb)' : 215.707,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2069.0)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.224742,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 76.114)],
        'TxNames weights (fb)' : {'TRV1jj': 48.4784208535}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.4192517,
        'r_expected' : 0.7032005,
        'nll' : 693.0576,
        'nll_min' : 693.012,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 3.960726,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.807064,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9993528,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8937449,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2605535,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.105151e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 3.960726,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.807064,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.9993528,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8937449,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2605535,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.105151e-05,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 9.692879,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.692879,
        'SMS' : 'PV > (t,t)'
    }
]
}