smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : False,
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_NWA/scan_3_um6q6sf6.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.00396326,
        'upper limit (fb)' : 1.809,
        'expected upper limit (fb)' : 1.983,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : 'SR_2016_7',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.002190857,
        'r_expected' : 0.001998618,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 0.00393499663162172,
            'TRS1' : 2.826299439688893e-05
        },
        'nll' : 11.897,
        'nll_min' : 11.89441,
        'nll_SM' : 11.89441
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 25.67095,
        'upper limit (fb)' : 12329.7,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 380.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.002082041,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 3.818413), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 25.670946020000002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001529413,
        'upper limit (fb)' : 1.028,
        'expected upper limit (fb)' : 0.8946,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 380.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : 'MB-C-2-1600-22',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.001487756,
        'r_expected' : 0.001709606,
        'Width (GeV)' : [('zp', 3.818413), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.001529413353601152},
        'nll' : 9.411306,
        'nll_min' : 9.227586,
        'nll_SM' : 9.413548
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.001379439,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 380.6), ('chi', 65.0)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.0009358471,
        'r_expected' : 0.0009075254,
        'Width (GeV)' : [('zp', 3.818413), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.001379438552763108},
        'nll' : 10.6978,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'Total xsec for missing topologies (fb)' : 782.4782,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 610.7782,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 171.407,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.29296,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 782.4782,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 610.7782,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 171.407,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.29296,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 233874.3,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 166974.0,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 41743.5,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 25156.79,
        'SMS' : 'PV > (t,t)'
    }
]
}