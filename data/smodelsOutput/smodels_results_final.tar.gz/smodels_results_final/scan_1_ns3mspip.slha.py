smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_ns3mspip.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.640848,
        'upper limit (fb)' : 3.336202,
        'expected upper limit (fb)' : 2.785853,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 902.3), ('chi', 232.2)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 1.091316,
        'r_expected' : 1.306906,
        'Width (GeV)' : [('zp', 7.017488), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 3.64084843379227},
        'nll' : 61.50612,
        'nll_min' : 59.45543,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 57.45226,
        'upper limit (fb)' : 54.0408,
        'expected upper limit (fb)' : 30.43296,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 902.3), ('chi', 232.2)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 1.063128,
        'r_expected' : 1.88783,
        'Width (GeV)' : [('zp', 7.017488), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 57.452262380154565},
        'nll' : 635.436,
        'nll_min' : 633.485,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 567.4573,
        'upper limit (fb)' : 610.294,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 902.3)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.9298097,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 7.0175)],
        'TxNames weights (fb)' : {'TRV1qq': 567.4572918}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1615.335,
        'upper limit (fb)' : 1925.95,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 902.3), ('chi', 232.2)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.8387212,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 7.017488), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1615.33517002}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4522874,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 902.3), ('chi', 232.2)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.5821694,
        'r_expected' : 0.5705656,
        'Width (GeV)' : [('zp', 7.017488), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.45228738626491993},
        'nll' : 9.930279,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 141.8643,
        'upper limit (fb)' : 613.684,
        'expected upper limit (fb)' : 707.485,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 902.3)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.2311684,
        'r_expected' : 0.2005192,
        'Width (GeV)' : [('zp', 7.017488)],
        'TxNames weights (fb)' : {'TRV1bb': 141.86432295}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 1.324165,
        'r_expected' : 2.186009,
        'nll' : 696.9422,
        'nll_min' : 693.08,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 253.97,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 103.7518,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 71.64265,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 49.01847,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 29.55319,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.003882279,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 253.97,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 103.7518,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 71.64265,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 49.01847,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 29.55319,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.003882279,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 423.575,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 423.575,
        'SMS' : 'PV > (t,t)'
    }
]
}