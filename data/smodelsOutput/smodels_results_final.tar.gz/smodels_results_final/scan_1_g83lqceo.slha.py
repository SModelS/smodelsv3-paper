smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_g83lqceo.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.945352,
        'upper limit (fb)' : 3.439773,
        'expected upper limit (fb)' : 2.923231,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 816.4), ('chi', 177.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 1.437697,
        'r_expected' : 1.691742,
        'Width (GeV)' : [('zp', 6.7328), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 4.945351900827484},
        'nll' : 63.48353,
        'nll_min' : 59.4814,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 86.13184,
        'upper limit (fb)' : 59.99972,
        'expected upper limit (fb)' : 33.97426,
        'TxNames' : ['TRS1', 'TRV1'],
        'Mass (GeV)' : None,
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 1.435537,
        'r_expected' : 2.535209,
        'Width (GeV)' : None,
        'TxNames weights (fb)' : {
            'TRV1' : 85.91280117874531,
            'TRS1' : 0.21904329075651274
        },
        'nll' : 638.8613,
        'nll_min' : 633.537,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 2633.922,
        'upper limit (fb)' : 2421.45,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 816.4), ('chi', 177.8)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.087746,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 6.7328), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 2633.92227804}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.5592028,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 816.4), ('chi', 177.8)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.7197873,
        'r_expected' : 0.7054406,
        'Width (GeV)' : [('zp', 6.7328), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.5592027710061164},
        'nll' : 10.2676,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 847.4489,
        'upper limit (fb)' : 1200.7,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 816.4)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.7057957,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 6.7328)],
        'TxNames weights (fb)' : {'TRV1qq': 847.4489056}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 211.8622,
        'upper limit (fb)' : 581.078,
        'expected upper limit (fb)' : 847.132,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 816.4)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.364602,
        'r_expected' : 0.2500935,
        'Width (GeV)' : [('zp', 6.7328)],
        'TxNames weights (fb)' : {'TRV1bb': 211.86222640000003}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 1.781462,
        'r_expected' : 2.918359,
        'nll' : 702.3449,
        'nll_min' : 693.156,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 335.2565,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 139.0065,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 102.3267,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 64.8808,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 29.03586,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.006620291,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 335.2565,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 139.0065,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 102.3267,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 64.8808,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 29.03586,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.006620291,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 594.3265,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 594.3265,
        'SMS' : 'PV > (t,t)'
    }
]
}