smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_5eizn4nu.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 39.52327,
        'upper limit (fb)' : 35.1859,
        'expected upper limit (fb)' : 41.4338,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2121.1)],
        'AnalysisID' : 'ATLAS-EXOT-2019-03',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 1.12327,
        'r_expected' : 0.9538895,
        'Width (GeV)' : [('zp', 16.469)],
        'TxNames weights (fb)' : {'TRV1jj': 39.523268388}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.902587,
        'upper limit (fb)' : 11.8725,
        'expected upper limit (fb)' : 15.8165,
        'TxNames' : ['TRV1tt'],
        'Mass (GeV)' : [('zp', 2121.1)],
        'AnalysisID' : 'ATLAS-EXOT-2018-48',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.6656211,
        'r_expected' : 0.4996419,
        'Width (GeV)' : [('zp', 16.46914)],
        'TxNames weights (fb)' : {'TRV1tt': 7.902586673999999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 7.904654,
        'upper limit (fb)' : 22.0505,
        'expected upper limit (fb)' : 30.7156,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 2121.1)],
        'AnalysisID' : 'CMS-EXO-20-008',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 138.0,
        'dataType' : 'upperLimit',
        'r' : 0.3584796,
        'r_expected' : 0.2573498,
        'Width (GeV)' : [('zp', 16.46914)],
        'TxNames weights (fb)' : {'TRV1bb': 7.9046536776}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 39.52327,
        'upper limit (fb)' : 133.321,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1jj'],
        'Mass (GeV)' : [('zp', 2121.1)],
        'AnalysisID' : 'CMS-EXO-19-012',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'upperLimit',
        'r' : 0.2964519,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 16.469)],
        'TxNames weights (fb)' : {'TRV1jj': 39.523268388}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.2176437,
        'upper limit (fb)' : 2.303327,
        'expected upper limit (fb)' : 1.974865,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2121.1), ('chi', 549.1)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 0.094491,
        'r_expected' : 0.1102069,
        'Width (GeV)' : [('zp', 16.46914), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.21764366384662495},
        'nll' : 59.53034,
        'nll_min' : 59.50254,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 29.70115,
        'upper limit (fb)' : 363.392,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2121.1), ('chi', 549.1)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.08173309,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 16.46914), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 29.7011526507}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 4.21188,
        'upper limit (fb)' : 55.1683,
        'expected upper limit (fb)' : 61.6727,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 2121.1)],
        'AnalysisID' : 'CMS-EXO-12-059',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.07634601,
        'r_expected' : 0.06829407,
        'Width (GeV)' : [('zp', 16.469)],
        'TxNames weights (fb)' : {'TRV1qq': 4.2118797248}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1.865353,
        'upper limit (fb)' : 28.2514,
        'expected upper limit (fb)' : 15.10953,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2121.1), ('chi', 549.1)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 0.06602692,
        'r_expected' : 0.1234554,
        'Width (GeV)' : [('zp', 16.46914), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1.8653528988908403},
        'nll' : 634.5024,
        'nll_min' : 633.1376,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.04154152,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 2121.1), ('chi', 549.1)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.05347087,
        'r_expected' : 0.05240509,
        'Width (GeV)' : [('zp', 16.46914), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.04154151715490155},
        'nll' : 9.220567,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 0.09492937,
        'r_expected' : 0.1578529,
        'nll' : 694.0327,
        'nll_min' : 693.0738,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 3.422,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.603598,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8032488,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7935331,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2216108,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.315362e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 3.422,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 1.603598,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.8032488,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.7935331,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.2216108,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 9.315362e-06,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 0.0,
'topologies outside the grid' : []
}