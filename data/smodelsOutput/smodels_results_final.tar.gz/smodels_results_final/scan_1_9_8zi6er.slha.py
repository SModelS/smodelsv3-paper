smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_9_8zi6er.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 3.483732,
        'upper limit (fb)' : 3.297244,
        'expected upper limit (fb)' : 2.753797,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 903.2), ('chi', 243.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 1.056559,
        'r_expected' : 1.265065,
        'Width (GeV)' : [('zp', 6.880914), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 3.4837324845304187},
        'nll' : 61.34444,
        'nll_min' : 59.45583,
        'nll_SM' : 59.60527
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 55.50404,
        'upper limit (fb)' : 53.3777,
        'expected upper limit (fb)' : 30.29035,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 903.2), ('chi', 243.6)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 1.039836,
        'r_expected' : 1.8324,
        'Width (GeV)' : [('zp', 6.880914), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 55.504043711105226},
        'nll' : 635.3389,
        'nll_min' : 633.5369,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 576.7576,
        'upper limit (fb)' : 606.791,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1qq'],
        'Mass (GeV)' : [('zp', 903.2)],
        'AnalysisID' : 'ATLAS-EXOT-2013-11',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 20.3,
        'dataType' : 'upperLimit',
        'r' : 0.9505046,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 6.8809)],
        'TxNames weights (fb)' : {'TRV1qq': 576.75762368}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1555.894,
        'upper limit (fb)' : 1925.27,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 903.2), ('chi', 243.6)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 0.8081431,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 6.880914), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1555.8936136799998}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 0.4423732,
        'upper limit (fb)' : 0.7769,
        'expected upper limit (fb)' : 0.7927,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 903.2), ('chi', 243.6)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_2200',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 0.5694082,
        'r_expected' : 0.5580588,
        'Width (GeV)' : [('zp', 6.880914), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 0.4423732281351112},
        'nll' : 9.902183,
        'nll_min' : 9.200812,
        'nll_SM' : 9.200812
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 144.1894,
        'upper limit (fb)' : 613.301,
        'expected upper limit (fb)' : 706.692,
        'TxNames' : ['TRV1bb'],
        'Mass (GeV)' : [('zp', 903.2)],
        'AnalysisID' : 'CMS-EXO-16-057',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 8.0,
        'lumi (fb-1)' : 19.7,
        'dataType' : 'upperLimit',
        'r' : 0.2351038,
        'r_expected' : 0.2040343,
        'Width (GeV)' : [('zp', 6.880914)],
        'TxNames weights (fb)' : {'TRV1bb': 144.18940592}
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 1.292509,
        'r_expected' : 2.120323,
        'nll' : 696.6834,
        'nll_min' : 693.1222,
        'nll_SM' : 694.5347
    }
],
'Total xsec for missing topologies (fb)' : 253.15,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 103.4111,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 71.36276,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 48.86296,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 29.50939,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.003860251,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 253.15,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 103.4111,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 71.36276,
        'SMS' : 'PV > (higgs,higgs)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 48.86296,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 29.50939,
        'SMS' : 'PV > (t,t)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.003860251,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 430.7773,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 430.7773,
        'SMS' : 'PV > (t,t)'
    }
]
}