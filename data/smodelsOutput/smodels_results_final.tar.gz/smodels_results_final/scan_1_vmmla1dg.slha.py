smodelsOutput = {
'OutputStatus' : {
    'sigmacut' : 0.0,
    'minmassgap' : 5.0,
    'maxcond' : 0.2,
    'ncpus' : 38,
    'model' : '2mdm_example.slha',
    'promptwidth' : 1e-11,
    'stablewidth' : 1e-25,
    'eraseprompt' : 'eCharge,colordim',
    'checkinput' : True,
    'doinvisible' : True,
    'docompress' : True,
    'computestatistics' : True,
    'testcoverage' : True,
    'combinesrs' : True,
    'combineanas' : 'ATLAS-SUSY-2018-22-multibin, CMS-EXO-20-004',
    'reportallsrs' : False,
    'experimentalfeatures' : False,
    'file status' : 1,
    'decomposition status' : 1,
    'warnings' : 'Input file ok',
    'input file' : '../smodelsv3-paper/slha_files_scan_gq_gx_m/scan_1_vmmla1dg.slha',
    'database version' : '3.0.0',
    'smodels version' : '3.0.0'
},
'ExptRes' : [
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 1297.075,
        'upper limit (fb)' : 106.4548,
        'expected upper limit (fb)' : 65.21773,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 413.5), ('chi', 120.7)],
        'AnalysisID' : 'CMS-EXO-20-004',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 137.0,
        'dataType' : 'combined',
        'r' : 12.18428,
        'r_expected' : 19.88838,
        'Width (GeV)' : [('zp', 14.75286), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 1297.0751829400635},
        'nll' : 1329.473,
        'nll_min' : 634.0491,
        'nll_SM' : 634.9294
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 39.53498,
        'upper limit (fb)' : 3.31976,
        'expected upper limit (fb)' : 3.092629,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 413.5), ('chi', 120.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin',
        'DataSetID' : '(combined)',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'combined',
        'r' : 11.90899,
        'r_expected' : 12.78361,
        'Width (GeV)' : [('zp', 14.75286), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 39.53497594745375},
        'nll' : 416.02,
        'nll_min' : 89.08297,
        'nll_SM' : 89.10691
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 96882.96,
        'upper limit (fb)' : 11022.6,
        'expected upper limit (fb)' : None,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 413.5), ('chi', 120.7)],
        'AnalysisID' : 'ATLAS-EXOT-2018-06',
        'DataSetID' : None,
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'upperLimit',
        'r' : 8.789483,
        'r_expected' : None,
        'Width (GeV)' : [('zp', 14.75286), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 96882.95581599999}
    },
    {
        'maxcond' : 0.0,
        'theory prediction (fb)' : 6.32574,
        'upper limit (fb)' : 1.474,
        'expected upper limit (fb)' : 1.52,
        'TxNames' : ['TRV1'],
        'Mass (GeV)' : [('zp', 413.5), ('chi', 120.7)],
        'AnalysisID' : 'ATLAS-SUSY-2018-22',
        'DataSetID' : 'SR2j_1600',
        'AnalysisSqrts (TeV)' : 13.0,
        'lumi (fb-1)' : 139.0,
        'dataType' : 'efficiencyMap',
        'r' : 4.291547,
        'r_expected' : 4.161671,
        'Width (GeV)' : [('zp', 14.75286), ('chi', 'stable')],
        'TxNames weights (fb)' : {'TRV1': 6.3257400809117605},
        'nll' : 34.59178,
        'nll_min' : 10.697,
        'nll_SM' : 10.697
    }
],
'CombinedRes' : [
    {
        'AnalysisID' : 'ATLAS-SUSY-2018-22-multibin,CMS-EXO-20-004',
        'r' : 15.71541,
        'r_expected' : 23.19088,
        'nll' : 999.0,
        'nll_min' : 723.2773,
        'nll_SM' : 724.0363
    }
],
'Total xsec for missing topologies (fb)' : 674.29,
'missing topologies' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 490.7135,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 183.4063,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1701409,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for missing topologies with displaced decays (fb)' : 0.0,
'missing topologies with displaced decays' : [],
'Total xsec for missing topologies with prompt decays (fb)' : 674.29,
'missing topologies with prompt decays' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 490.7135,
        'SMS' : 'PV > (W,W)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 183.4063,
        'SMS' : 'PV > (Z,Z)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 0.1701409,
        'SMS' : 'PV > (ta,ta)'
    }
],
'Total xsec for topologies outside the grid (fb)' : 390237.1,
'topologies outside the grid' : [
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 271616.6,
        'SMS' : 'PV > (jet,jet)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 67904.14,
        'SMS' : 'PV > (b,b)'
    },
    {
        'sqrts (TeV)' : 13.0,
        'weight (fb)' : 50716.45,
        'SMS' : 'PV > (t,t)'
    }
]
}